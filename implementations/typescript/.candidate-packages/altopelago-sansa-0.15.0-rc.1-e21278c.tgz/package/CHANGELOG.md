# Changelog

All notable changes to this package are documented here.

This project follows Semantic Versioning while it remains pre-1.0. Minor
versions may still include breaking changes when the SANSA specifications move.

## Unreleased

- Integrate declared identities in the Query workbench's AEON/Telex/Film adapters with whole-query inspection limits; preserve opaque JSON identity and trusted activation guards. Document the separate website candidate and AEOS composer integration.

- Document the separate Titonic child identity dispatcher integration, per-call inspections, binding/head metadata and live proxy/path boundaries.

- Document the separate AEON AEOS selector integration, validation-local inspection budget/cache and retained structural path boundary.

- Add explicit constrained child identity activation in read-only Query, with pre-inspection canonical scope checks, post-resolution checks and shared inspection budgets. Trusted/default activation and mutation stay guarded.

- Admit read-only child identity selectors in JavaScript and shared Rust Query sources/expressions with one inspection budget per invocation; retain activation, reference and mutation guards.

### Added

- Repository source playground based on the website UI, with direct SANSA imports, the SDK identity namespace, scoped roots, inspection budgets and identity/reorder examples. Run `npm run playground` with a built AEON checkout. No official release is created by source pushes.

- TypeScript Resolve diagnostics now declare optional `identity`, matching runtime identity-related failures and allowing typed SDK consumers to inspect the selected identity.

- Local experimental Rust child-identity Address/Resolve candidate with default-off structural metadata capabilities, lazy identity-child iteration, a 10,000 default inspection budget and caller-AST validation. Core/SDK integration and 464 Rust cost controls are verified locally; final registry/version and native platform qualification remain release work. Python/bridge support is tracked separately by AEON. Query, activation and mutation do not gain identity admission.

## 0.15.0-rc.1 - 2026-10-19

### Added

- Supported `@altopelago/sansa/parsing/selector-cursor` for synchronous host-token adapters. Native SANSA and AEON share step grammar and original-spelling positional-index validation; cursor transport does not grant reference eligibility.

## 0.14.2 - 2026-10-16

### Fixed

- Preserved scalar value families in JavaScript Query when a host namespace
  exposes portable PascalCase representation kinds such as `DateTimeLiteral`
  or `WTCDateTimeLiteral`. Temporal bindings now reach temporal functions rather
  than being mistaken for strings; other portable scalar families retain their
  distinct comparison domains without changing representation-kind filters.

## 0.14.1 - 2026-10-16

### Fixed

- Aligned JavaScript and Rust temporal literals and AEON target validation with
  AEON 0.14.0's year/month date ticks composed with clocks. Exact authored
  fractional seconds, second 60, offset anchors and opaque WTC contexts remain
  intact; GP/schema limits are not imposed by the parser.
- Rejected malformed clock/date fields, noncanonical `Local` case variants,
  and comment-looking suffixes inside WTC contexts, including nested expressions.
  Rust target validation checks the complete payload rather than parsing away
  trailing trivia. Temporal relation helpers fail closed on malformed descriptors
  and unsupported disjoint date/clock completion sets without panicking or
  inventing omitted calendar fields.
- Updated AEON mutation target validation for the recent reserved `base64`
  decodability rule, while retaining opaque `encoding`, `inline` and `embed`
  payload semantics. Clone/pointer reference addresses are validated as addresses,
  including native Rust descriptors, not decoded as literal Base64URL data.
- Protected decoded multiline prose/trimtick gutters when the mutation
  workbench writes AEON source. AEON target validation rejects payloads whose
  trailing newlines or whitespace-only content lines cannot survive trimtick
  normalization; ordinary string and Telex payloads are not narrowed.

### Tests

- Added one shared JavaScript/Rust value fixture and a 1,109-case valid
  calendar/clock matrix, plus malformed boundaries, Base64URL and symbol probes.
  Tests exercise Query, JavaScript Instruction, native Rust scalar descriptors,
  target validation and round trips through an available AEON Core runtime.

## 0.14.0 - 2026-10-15

### Added

- Added a proposal-stage Rust SANSA.Mutate type shell and a side-effect-free
  planner covering all 28 cases assigned to the pinned experimental plan
  surface. The planner retains opaque exact bindings, evaluates Query
  preconditions, enforces conservative container/conflict/budget rules, and
  preserves provenance and portability warnings.
- Added post-plan Rust SANSA.Mutate target-surface validation covering all 36
  pinned experimental AEON and JSON cases. Built-in validation remains
  representability-only, and a host-neutral trait permits separate custom
  validators without granting authority or exposing mutation hooks. Apply and
  policy remain independent unimplemented surfaces.

### Fixed

- JSON mutation target validation in Rust and JavaScript now distinguishes
  actual attribute-space selectors from quoted property names containing
  `.@`, including contextual aliases and attribute descendants.
- Corrected Rust target-validator dispatch so JSON's container and attribute
  restrictions run in the JSON validator, while AEON accepts those targets.
  Public API regression coverage now exercises every mutation operation across
  AEON, JSON, and their default/alias spellings.
- Hardened the Rust mutation planner so every resolved alias of the namespace
  root is protected from removal, pre-parsed targets are revalidated under the
  planner's Address ceiling, and non-portable Address warnings inside Query
  preconditions are retained on the plan. Precondition resolution now has a
  finite default binding ceiling and reports exhaustion through the normalized
  mutation budget diagnostic.

## 0.13.0 - 2026-10-06

### Added

- Added bounded Rust SANSA Query clause and expression parsing, covering all 57
  stable parser cases from the pinned Query CTS. The syntax surface includes
  canonical AST rendering, AEON scalar literal families, projections, dynamic
  `path(...)` sources, and explicit input, token, AST-node, nesting, and literal
  ceilings.
- Added host-neutral Rust SANSA Query evaluation over opaque namespace handles,
  covering all 169 stable evaluator cases from the pinned Query CTS. The
  evaluator implements From, Where, Order, Offset, Limit, Select, stable
  functions and value families, short-circuiting, deterministic ordering,
  phase-specific budgets, and constrained dynamic-address activation. Together
  with parsing, the Rust runtime now claims the complete 226-case stable core
  `SANSA.Query` lane; experimental Transform cases remain excluded.

## 0.12.0 - 2026-10-01

### Added

- Added the publishable `altopelago-sansa-runtime` Rust crate. The initial
  Rust surface implements the pinned stable Address, Resolve, and shared AEON
  minimum value-semantics CTS lanes while reporting Query as unimplemented.

### Changed

- Added AEON symbolic literals to Query, Instruction, mutation target
  validation, and the AEON/Telex workbench adapters. Pipe-delimited source
  such as `|approved|` and `|in review\|blocked|` preserves a distinct
  `symbol` value family, compares by exact decoded payload, does not coerce to
  strings, and has no intrinsic ordering.
- Added year- and month-granularity AEON date literals (`YYYY-` and `YYYY-MM`)
  to Query parsing and temporal completion-set comparison. Calendar years and
  months now contain compatible finer-grained dates through
  `temporalRelation(...)` and `compareTemporalClaims(...)`.
- Added conservative temporal completion-set relations through the exported
  `compareTemporalClaims(...)` helper, the public `temporalRelation`
  value-semantics operation, and the SANSA.Query `temporalRelation(...)`
  function. Relations distinguish equality, ordering, containment, overlap,
  and claims that cannot be compared without inventing missing context.
- Cross-type query comparison diagnostics now identify both evaluator
  categories, such as `string vs finiteNumber`, while retaining the candidate
  address as structured diagnostic context.
- Clarified that namespace addresses are current structural locators rather
  than durable identities and that SANSA is a bounded in-process evaluator
  rather than a persistent database.
- Finite-number equality and ordering now compare canonical numeric lexemes
  exactly, including large integers, long fractions, and exponent forms.
  Namespace adapters can expose `numericLexeme` independently of their host
  materialization value, and projected query-number literals retain their
  canonical text. Radix-family `decimal` values remain
  representation-preserving and profile-defined for numeric interpretation.
- Added the explicit `aeon.value.radix.numeric.same-base.v1` (`radix-numeric`)
  profile and `compareExactRadixValues(...)` for exact base-2-through-base-64
  equality and ordering without host-number conversion. Default radix
  comparison remains representation-preserving, and cross-base comparison
  fails closed. The value-semantics runner now targets the 0.2 development CTS
  manifest, and the query workbench includes a `decimal` equality example that
  demonstrates the opt-in behavior.
- Added `aeon.value.radix.numeric.cross-base.v1`
  (`radix-numeric-cross-base`),
  `createCrossBaseRadixNumericValueSemanticsProfile(...)`, and
  `compareExactCrossBaseRadixValues(...)` for exact rational equality and
  ordering across independently resolved bases. The same-base profile remains
  fail-closed for mixed bases. Both radix profiles are now selectable in the
  query workbench instead of being available only through example metadata or
  programmatic options.
- Added profile-independent radix fractional scale through `radixScaleOf(...)`,
  the `radixScale` value-semantics operation and query function, and optional
  namespace `radixScale` metadata. Trailing zeroes remain significant to scale
  without changing either representation equality or numeric-profile equality.

### Fixed

- Allowed namespace `parent` callbacks to return `null` as well as `undefined`
  for root bindings, matching the nullable parent field on resolver bindings
  and common tree-adapter conventions.
- Added a targeted projection diagnostic explaining that fields use AEON
  `name = expression` syntax and that `:` remains reserved for datatype
  annotations.
- Limited native structural-equality dispatch to bindings with an explicit
  container representation, so adapters that expose empty child lists on
  scalars do not route scalar comparisons through the container hook.
- Preserved scalar value-family descriptors while materializing containers for
  generic structural equality, preventing symbol-valued children from
  comparing equal to string-valued children with the same payload.
- Rejected symbols and other lexical scalar families from string-only query
  functions, member keys, transform keys, field names, and null reasons.
- Required temporal descriptors for the public `temporalRelation` operation
  instead of accepting arbitrary descriptor payloads.
- Rendered exact AEON number bindings as numeric lexemes in the query CLI
  rather than quoting their adapter-provided string representation.

## 0.11.1 - 2026-09-14

### Fixed

- Fixed optional AEON Core and AES runtime discovery when the packages are
  installed by the calling project with import-only package exports. This
  restores published-package AEON, Telex, and Film query input without
  requiring an explicit module-path environment override.

## 0.11.0 - 2026-09-14

### Added

- Added reader-only Film v1 input to the Query CLI and direct Query Workbench
  runtime. Film records use the same portable AES namespace adapter as Telex,
  without reconstructing AEON source or parser events.

### Changed

- Require complete Film streams when no external namespace state is supplied.
  Film remains a byte-oriented query input and is not exposed through the
  browser JSON request envelope, mutation, re-encoding, or durable writing.

## 0.10.1 - 2026-09-11

### Added

- Added direct complete `telex.aes` input to the Query CLI and browser
  workbench. The adapter preserves portable paths, record order, structural
  identities, datatype components, flat attributes, and expanded node heads
  without reconstructing the AEON parser AST.
- Added a conservative Telex target surface and Mutate Workbench source mode.
  Exact scalar replacement now re-emits complete Telex while retaining event
  order, paths, identities, datatype components, and flat attributes. Changed
  events discard stale origin/span coordinates; structural rewrites fail closed
  pending a portable path-rewrite contract. The Instruction CLI can select the
  same representability surface with `--target telex` or `--target telex.aes`.
- Preserved structural identity as opaque binding metadata throughout SANSA
  resolution without using identity to construct or compare addresses.

### Fixed

- Accepted exact normative representation names such as `NodeLiteral` and
  `NodeHead` in `%kind` filters while retaining existing lower-first matching
  for compatible host namespaces.
- Kept representation-kind filters on the ordinary identifier grammar and
  rejected the obsolete hyphenated `%node-head` spelling.
- Aligned portable AES node-navigation fixtures with the explicit
  `NodeLiteral` → `NodeHead` → content hierarchy.

## 0.10.0 - 2026-09-01

### Breaking

- Renamed the AEON temporal literal family from `zrut` to `wtc` across query,
  instruction, mutation, workbench, fixture, declaration, and documentation
  surfaces.
- Changed qualifier datatype clarifiers to one bracketed list. String
  clarifiers must now be quoted, multiple values use comma separation inside
  the same brackets, and numeric clarifiers such as `radix[16]` are represented
  as numbers. Repeated clarifier lists and unquoted string clarifiers are
  rejected.

### Added

- Added experimental `traverseGraph(...)` and `traverseGraphSequence(...)`
  APIs for declared, directed relationship traversal with ordered path
  provenance.
- Added experimental graph capability metadata covering schema-version
  applicability, semantic-type constraints, edge cardinality, cycle policy,
  authorization hooks, and explicit traversal budgets.

### Changed

- Updated address, instruction, mutation, query, fixture, stress, and API
  contract surfaces to use the unified AEON datatype clarifier grammar.

### Security

- Graph traversal requires explicit budgets and applies an independent
  authorization decision to every traversal step without granting authority to
  composed Query reads.

## 0.9.1 - 2026-08-02

### Added

- Added explicit Shared AEON Value Semantics profile hooks for string comparison,
  ordering, and case mapping.
- Added `aeonValueSemanticsDefaultProfile`,
  `createIntlValueSemanticsProfile(...)`, and
  `createFrenchValueSemanticsProfile(...)`.
- Added `createNaturalAsciiValueSemanticsProfile(...)` and the
  `aeon.value.string.natural.ascii.v1` profile for deterministic numeric-region
  string ordering.
- Added Query `valueSemantics` evaluation option so consumers can select default
  or domain-specific string semantics.
- Added minimum structural equality and reference-form equality coverage to the
  standalone value-semantics helper.
- Added experimental SANSA.Mutate structured planning and host-adapter apply
  APIs for exact `create`, `replace`, `remove`, ordered `insert`, and
  same-container `move`.
- Added experimental SANSA.Mutate structured preconditions evaluated during
  planning with the SANSA.Query expression evaluator.
- Added default apply-time rechecking of preserved SANSA.Mutate preconditions
  before mutation hooks run.
- Added experimental SANSA.Mutate `maxOperations` and `maxPreconditions`
  budgets for planning and apply.
- Added explicit SANSA.Mutate apply report addresses for mutation role,
  affected binding, and resulting binding diagnostics.
- Added SANSA.Mutate plan-level `sourceProvenance` preservation for structured
  request envelopes.
- Added SANSA.Mutate plan-level portability warning preservation for locally
  accepted non-portable targets.
- Added explicit SANSA.Mutate adapter capability flags for operation support and
  stable/atomic apply capability advertisement.
- Added an experimental browser SANSA Mutate Workbench for structured JSON
  mutation requests against `.aeon` source fixtures.
- Added experimental SANSA.Instruction parsing, lowering, CLI tooling, and
  Mutate Workbench integration for conservative mutation verbs.
- Added SANSA.Instruction `append` source syntax as an alias for
  `insert last`.
- Added SANSA.Instruction `require` clauses that lower into structured
  SANSA.Mutate preconditions.
- Added SANSA.Instruction `because` and `by` clauses that preserve inert
  source-level claimed provenance.
- Added SANSA.Instruction CTS coverage for quoted create member names,
  attribute-space create destinations, candidate-relative remove/append/move,
  repeated require preconditions, target-surface datatype rejection, and illegal
  positional create destinations.
- Added SANSA.Instruction negative CTS coverage for candidate-relative lowering
  misses and downstream Mutate planning failures for non-ordered containers,
  invalid anchors, and cross-container or self-anchored moves.
- Added SANSA.Instruction parse/value CTS coverage for comments, complex
  datatype intent, malformed container literals, invalid quoted create
  destinations, nested datatype unions, and literal-only value payloads.
- Added SANSA.Instruction CTS coverage for quoted address-member create
  destinations, selector-as-create-destination rejection, typed replace values,
  date values, and SANSA selector values.
- Added Mutate Workbench diagnostic examples for duplicate object fields,
  literal-only value failures, invalid create member names, lower-phase target
  misses, lower-phase anchor misses, and JSON tuple target rejection.
- Added Mutate Workbench policy-boundary examples for allowed operations,
  default-deny failures, and explicit-deny failures.
- Added experimental SANSA.Mutate target-surface validation for AEON,
  JSON-compatible, and custom representability checks.
- Added a workbench-only experimental SANSA.Mutate policy plan filter for
  trusted consumer authorization tests.

### Changed

- Updated `isValue(...)` to use the concrete-value basis: infinities and
  containers are values, while Missing, explicit null, explicit absence values,
  NaN, and Binding Sets are not.
- Kept default Query string ordering on deterministic Unicode scalar value
  order unless an explicit value-semantics profile is supplied.
- Updated TypeScript declarations for SANSA.Instruction values to include
  object, list, tuple, node, SANSA address, and reference literal payloads.
- Rejected duplicate object field names in SANSA.Instruction object value
  literals instead of silently keeping the last value.
- Updated Mutate Workbench error responses so instruction parse failures expose
  their parse phase and nested cause diagnostics in text mode.
- Clarified Instruction and Mutate documentation around parse, lower, plan,
  policy, target-surface, and apply phase boundaries.
- Added Instruction coverage for repeated same-verb mutation rejection and
  direct `require` precondition planning failures.
- Clarified Instruction ordered placement vocabulary and added coverage for
  append canonicalization plus direct `insert after` and `move last` forms.
- Clarified Instruction value-intent boundaries for typed scalars, typed
  containers, nested container literals, and target-neutral lowering.
- Clarified Instruction target-surface behavior for AEON and JSON, including
  JSON-compatible containers and parameterized datatype rejection.
- Improved target-surface diagnostics so CLI and Workbench text output expose
  target format, rejected datatype, and rejected value path when available.
- Improved experimental policy diagnostics so Workbench and CTS output can
  identify the affected rule, policy field, policy scope, and invalid matcher
  address when available.
- Expanded Instruction/Mutate target-surface coverage for type-first values on
  ordered inserts and AEON parameterized container datatype families.
- Moved Mutate Workbench examples into a shared catalog module so UI rendering
  and runtime tests use the same grouped example source.
- Added declared Mutate Workbench catalog expectations and runtime coverage for
  every structured and Instruction example variant.
- Added operation-count and selected text-snippet assertions for representative
  successful Mutate Workbench catalog examples.
- Updated the Mutate Workbench status chip and catalog metadata so parse,
  lower, plan, policy, target, and apply phases remain visible in the UI and
  tests.

### Security

- Require explicit trusted or constrained activation authority before Query
  `path(...)` resolves a structured SANSA Address Literal, with parsed
  structural-root checks, selector capability restrictions, contextual and
  parent containment checks, and dynamic binding bounds.

## 0.9.0 - 2026-07-24

Initial public pre-1.0 release of `@altopelago/sansa`.

### Added

- SANSA Address parser and canonical renderer.
- SANSA Resolve over host-supplied namespace adapters.
- SANSA.Query parser and bounded evaluator.
- Shared AEON Value Semantics minimum consumer operations.
- Query CLI and browser workbench for technical testing.
- Host-neutral JSON fixture support for the Query tool.
- Optional AEON TypeScript Core integration for `.aeon` fixtures.
- CTS runners for value semantics, address parsing, resolve, and query.
- Address stress-test fixtures for legal and illegal SANSA cases.
- Capability metadata in `docs/capabilities.json`.

### Experimental

- Query `validation` policy.
- `SANSA.Transform` helpers: `objectFrom` and `fieldsFrom`.
- Browser Query workbench for technical exploration.

### Security

- Public release repository hardening docs: security policy, governance,
  contributing guide, and code of conduct.
- CI, dependency review, Dependabot, pinned GitHub Actions, and package
  dry-run verification.

### Notes

- SANSA is versioned independently from AEON.
- Query and transform surfaces are still expected to evolve before 1.0.
