export {
  evaluateAeonicArithmetic,
  evaluateAeonicArithmeticText,
  AEONIC_ARITHMETIC_PROFILE,
  AEONIC_ARITHMETIC_DEFAULT_RESOURCE_LIMITS,
} from './aeonic-arithmetic.js';

export {
  evaluateAeonicComparison,
  evaluateAeonicComparisonText,
  AEONIC_COMPARISON_BASELINE_PROFILE,
  AEONIC_COMPARISON_CODEPOINT_PROFILE,
  AEONIC_COMPARISON_DEFAULT_RESOURCE_LIMITS,
} from './aeonic-comparison.js';
import { parseDotSelectorFromCursor, parsePositionSelectorFromCursor, validatePositionIndex } from './selector-cursor.js';
const CHILD_IDENTITY_RE = /^[A-Za-z0-9_-]+$/;
const DENY_CHILD_IDENTITY = Symbol('consumer identity admission');
const QUERY_IDENTITY_BUDGET = Symbol('query identity inspections');
const IDENTITY_ACTIVATION_GUARD = Symbol('identity activation scope');
const DEFAULT_IDENTITY_INSPECTIONS = 10_000;
const IDENTIFIER_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;
const QUALIFIER_NUMBER_RE = /^[+-]?(?:(?:0|[1-9][0-9]*)(?:\.[0-9]+)?|\.[0-9]+)$/;
export const SANSA_MAX_POSITION_INDEX = 999_999;
export const SANSA_MAX_QUERY_INTEGER = Number.MAX_SAFE_INTEGER;

const QUERY_VALUE_METADATA_PROPERTY = '__sansaQueryValueMetadata';
const QUERY_OBJECT_FIELD_METADATA_PROPERTY = '__sansaObjectFieldMetadata';
const COMPARABLE_SCALAR_DESCRIPTOR_PROPERTY = Symbol('sansaComparableScalarDescriptor');
const TRANSFORM_EXTENSION_FUNCTIONS = new Map([
  ['objectFrom', 'sansa.transform.objectFrom'],
  ['fieldsFrom', 'sansa.transform.fieldsFrom'],
]);
const DEFAULT_VALUE_SEMANTICS_PROFILE_ID = 'aeon.value.default.v1';
const CODEPOINT_STRING_PROFILE_ID = 'aeon.value.string.codepoint.v1';
const FRENCH_STRING_PROFILE_ID = 'aeon.value.string.locale.fr.v1';
const NATURAL_ASCII_STRING_PROFILE_ID = 'aeon.value.string.natural.ascii.v1';
const TEMPORAL_CANONICAL_PROFILE_ID = 'aeon.value.temporal.canonical.v1';
const RADIX_NUMERIC_SAME_BASE_PROFILE_ID = 'aeon.value.radix.numeric.same-base.v1';
const RADIX_NUMERIC_CROSS_BASE_PROFILE_ID = 'aeon.value.radix.numeric.cross-base.v1';
const MAX_EXACT_NUMERIC_CHARACTERS = 65_536;
const MUTATION_REQUEST_ENVELOPE_FIELDS = new Set(['operations', 'preconditions', 'provenance']);
const MUTATION_OPERATION_FIELDS = new Map([
  ['create', new Set(['op', 'parent', 'name', 'value', 'datatype', 'kind', 'provenance'])],
  ['replace', new Set(['op', 'target', 'value', 'datatype', 'kind', 'provenance'])],
  ['remove', new Set(['op', 'target', 'provenance'])],
  ['insert', new Set(['op', 'container', 'placement', 'value', 'datatype', 'kind', 'provenance'])],
  ['move', new Set(['op', 'source', 'container', 'placement', 'provenance'])],
]);
const VALUE_SEMANTICS_METADATA_CATEGORIES = [
  'toggle',
  'hex',
  'radix',
  'encoding',
  'separator',
  'symbol',
  'sansa',
  'sansaAddress',
  'cloneReference',
  'pointerReference',
  'referenceForm',
  'date',
  'time',
  'datetime',
  'wtc',
  'temporal',
  'lexicalStructuredScalar',
  'container',
];

export class SansaParseError extends Error {
  constructor(message, index, code = 'SANSA_PARSE_ERROR') {
    super(message);
    this.name = 'SansaParseError';
    this.code = code;
    this.index = index;
  }
}

export function parseAddress(input, options = {}) {
  try {
    const parser = new AddressParser(input, options);
    const address = parser.parse();
    return { ok: true, address, warnings: parser.warnings };
  } catch (error) {
    if (error instanceof SansaParseError) {
      return {
        ok: false,
        errors: [{
          code: error.code,
          message: error.message,
          index: error.index,
        }],
      };
    }
    throw error;
  }
}

export function parseAddressOrThrow(input, options = {}) {
  const result = parseAddress(input, options);
  if (!result.ok) {
    const first = result.errors[0];
    throw new SansaParseError(first.message, first.index, first.code);
  }
  return result.address;
}

export function parseQuery(input, options = {}) {
  try {
    const parser = new QueryParser(input, options);
    const query = parser.parse();
    return { ok: true, query, warnings: parser.warnings };
  } catch (error) {
    if (error instanceof SansaParseError) {
      return {
        ok: false,
        errors: [{
          code: error.code,
          message: error.message,
          index: error.index,
        }],
      };
    }
    throw error;
  }
}

export function parseQueryOrThrow(input, options = {}) {
  const result = parseQuery(input, options);
  if (!result.ok) {
    const first = result.errors[0];
    throw new SansaParseError(first.message, first.index, first.code);
  }
  return result.query;
}

export function parseQueryExpression(input, options = {}) {
  try {
    const parser = new QueryExpressionParser(input, options);
    const expression = parser.parse();
    return { ok: true, expression, warnings: parser.warnings };
  } catch (error) {
    if (error instanceof SansaParseError) {
      return {
        ok: false,
        errors: [{
          code: error.code,
          message: error.message,
          index: error.index,
        }],
      };
    }
    throw error;
  }
}

export function parseQueryExpressionOrThrow(input, options = {}) {
  const result = parseQueryExpression(input, options);
  if (!result.ok) {
    const first = result.errors[0];
    throw new SansaParseError(first.message, first.index, first.code);
  }
  return result.expression;
}

export function parseInstruction(input, options = {}) {
  try {
    const parser = new InstructionParser(input, options);
    const instruction = parser.parse();
    return { ok: true, instruction, warnings: parser.warnings };
  } catch (error) {
    if (error instanceof SansaParseError) {
      return {
        ok: false,
        errors: [{
          code: error.code,
          message: error.message,
          index: error.index,
        }],
      };
    }
    throw error;
  }
}

export function parseInstructionOrThrow(input, options = {}) {
  const result = parseInstruction(input, options);
  if (!result.ok) {
    const first = result.errors[0];
    throw new SansaParseError(first.message, first.index, first.code);
  }
  return result.instruction;
}

export function lowerInstruction(input, namespaceOrOptions = {}, maybeOptions = undefined) {
  const normalizedArgs = normalizeLowerInstructionArgs(namespaceOrOptions, maybeOptions);
  const { namespace, options } = normalizedArgs;
  const parsed = typeof input === 'string' ? parseInstruction(input, options.parse ?? options) : { ok: true, instruction: input };
  if (!parsed.ok) {
    return {
      ok: false,
      errors: parsed.errors.map((error) => instructionLowerError(
        'SANSA_INSTRUCTION_PARSE_FAILED',
        error.message,
        { phase: 'parse', cause: error },
      )),
    };
  }
  try {
    const lowered = lowerParsedInstruction(parsed.instruction, namespace, options);
    const request = lowered.preconditions.length === 0
      ? lowered.operations.length === 1 ? lowered.operations[0] : lowered.operations
      : {
          operations: lowered.operations,
          preconditions: lowered.preconditions,
        };
    return {
      ok: true,
      request,
      provenance: parsed.instruction.provenance,
      diagnostics: [],
      warnings: parsed.warnings ?? [],
    };
  } catch (error) {
    if (error instanceof SansaInstructionLowerError) {
      return { ok: false, errors: [error.diagnostic] };
    }
    throw error;
  }
}

export function planInstruction(input, namespace, options = {}) {
  const lowered = lowerInstruction(input, namespace, options);
  if (!lowered.ok) {
    return {
      ok: false,
      phase: 'lower',
      errors: lowered.errors,
    };
  }

  const operations = Array.isArray(lowered.request)
    ? lowered.request
    : Array.isArray(lowered.request?.operations)
      ? lowered.request.operations
      : [lowered.request];
  const request = {
    operations,
    ...(Array.isArray(lowered.request?.preconditions) ? { preconditions: lowered.request.preconditions } : {}),
    provenance: {
      type: 'SansaInstruction',
      source: typeof input === 'string' ? input : input?.canonical,
      ...(lowered.provenance?.reason === undefined ? {} : { reason: lowered.provenance.reason }),
      ...(lowered.provenance?.claimedAuthor === undefined ? {} : { claimedAuthor: lowered.provenance.claimedAuthor }),
    },
  };
  const planned = planMutation(request, namespace, options.mutate ?? options);
  if (!planned.ok) {
    return {
      ok: false,
      phase: 'plan',
      loweredRequest: lowered.request,
      errors: planned.errors,
      warnings: lowered.warnings ?? [],
    };
  }
  return {
    ok: true,
    plan: planned.plan,
    loweredRequest: lowered.request,
    diagnostics: planned.diagnostics,
    warnings: lowered.warnings ?? [],
  };
}

export function validateMutationPlanTarget(plan, targetSurface = 'aeon') {
  if (!plan || typeof plan !== 'object' || !Array.isArray(plan.operations)) {
    return {
      ok: false,
      errors: [mutationTargetSurfaceError(
        'SANSA_MUTATE_INVALID_PLAN',
        'Mutation target validation requires a mutation plan',
        { targetFormat: targetSurfaceId(targetSurface) },
      )],
    };
  }

  const surface = resolveMutationTargetSurface(targetSurface);
  if (!surface.ok) return { ok: false, errors: [surface.error] };

  const errors = [];
  for (let operationIndex = 0; operationIndex < plan.operations.length; operationIndex += 1) {
    const operation = plan.operations[operationIndex];
    const result = surface.surface.validateOperation(operation, {
      plan,
      operationIndex,
      targetFormat: surface.surface.id,
    });
    const normalized = normalizeMutationTargetSurfaceOperationResult(result, {
      operation,
      operationIndex,
      targetFormat: surface.surface.id,
    });
    if (!normalized.ok) errors.push(...normalized.errors);
  }

  return errors.length === 0 ? { ok: true, diagnostics: [] } : { ok: false, errors };
}

export const aeonValueSemanticsDefaultProfile = Object.freeze({
  id: DEFAULT_VALUE_SEMANTICS_PROFILE_ID,
  stringOrder: CODEPOINT_STRING_PROFILE_ID,
  temporalOrder: TEMPORAL_CANONICAL_PROFILE_ID,
  caseMapping: 'unicode-default',
  compareStrings: compareStringsByUnicodeScalarValue,
  compareTemporal: compareTemporalByCanonicalValue,
  lowerString: (value) => value.toLowerCase(),
  upperString: (value) => value.toUpperCase(),
});

export function createIntlValueSemanticsProfile(options = {}) {
  const locale = options.locale ?? 'und';
  const collator = new Intl.Collator(locale, {
    usage: options.usage ?? 'sort',
    sensitivity: options.sensitivity ?? 'variant',
    ignorePunctuation: options.ignorePunctuation ?? false,
    numeric: options.numeric ?? false,
    caseFirst: options.caseFirst ?? 'false',
  });
  return Object.freeze({
    id: options.id ?? `aeon.value.string.intl.${Array.isArray(locale) ? locale.join('-') : locale}.v1`,
    locale,
    stringOrder: 'intl-collator',
    temporalOrder: TEMPORAL_CANONICAL_PROFILE_ID,
    caseMapping: 'intl-locale',
    compareStrings: (left, right) => normalizeComparison(collator.compare(left, right)),
    compareTemporal: options.compareTemporal ?? compareTemporalByCanonicalValue,
    ...(typeof options.compareRadix === 'function' ? { compareRadix: options.compareRadix } : {}),
    lowerString: (value) => value.toLocaleLowerCase(locale),
    upperString: (value) => value.toLocaleUpperCase(locale),
  });
}

export function createFrenchValueSemanticsProfile(options = {}) {
  return createIntlValueSemanticsProfile({
    id: 'aeon.value.string.locale.fr.v1',
    locale: 'fr',
    ...options,
  });
}

export function createNaturalAsciiValueSemanticsProfile(options = {}) {
  return Object.freeze({
    id: NATURAL_ASCII_STRING_PROFILE_ID,
    stringOrder: NATURAL_ASCII_STRING_PROFILE_ID,
    temporalOrder: TEMPORAL_CANONICAL_PROFILE_ID,
    caseMapping: 'unicode-default',
    ...options,
    compareStrings: compareStringsByNaturalAsciiOrder,
    compareTemporal: options.compareTemporal ?? compareTemporalByCanonicalValue,
    lowerString: (value) => value.toLowerCase(),
    upperString: (value) => value.toUpperCase(),
  });
}

export function createRadixNumericValueSemanticsProfile(options = {}) {
  return Object.freeze({
    ...aeonValueSemanticsDefaultProfile,
    id: options.id ?? RADIX_NUMERIC_SAME_BASE_PROFILE_ID,
    radixComparison: 'same-base-exact',
    compareRadix: compareExactRadixSemanticValues,
  });
}

export function createCrossBaseRadixNumericValueSemanticsProfile(options = {}) {
  return Object.freeze({
    ...aeonValueSemanticsDefaultProfile,
    id: options.id ?? RADIX_NUMERIC_CROSS_BASE_PROFILE_ID,
    radixComparison: 'cross-base-exact',
    compareRadix: compareExactCrossBaseRadixSemanticValues,
  });
}

/** Compare two exact radix payloads in the same declared base. */
export function compareExactRadixValues(left, right, base) {
  const leftValue = parseExactRadixValue(String(left), base);
  const rightValue = parseExactRadixValue(String(right), base);
  if (leftValue === null || rightValue === null) return null;
  return compareParsedRadixValues(leftValue, rightValue);
}

/** Compare two exact radix payloads with independently declared bases. */
export function compareExactCrossBaseRadixValues(left, leftBase, right, rightBase) {
  const leftValue = parseExactRadixValue(String(left), leftBase);
  const rightValue = parseExactRadixValue(String(right), rightBase);
  if (leftValue === null || rightValue === null) return null;
  if (leftBase === rightBase) return compareParsedRadixValues(leftValue, rightValue);
  return compareParsedCrossBaseRadixValues(leftValue, leftBase, rightValue, rightBase);
}

/** Return the number of represented fractional radix digits, excluding visual separators. */
export function radixScaleOf(value, base) {
  const payload = String(value);
  if (payload.length === 0 || payload.length > MAX_EXACT_NUMERIC_CHARACTERS) return null;
  if (base !== undefined && (!Number.isInteger(base) || base < 2 || base > 64)) return null;

  let index = payload[0] === '+' || payload[0] === '-' ? 1 : 0;
  if (index === payload.length) return null;
  let sawDigit = false;
  let sawPoint = false;
  let scale = 0;
  for (; index < payload.length; index += 1) {
    const character = payload[index];
    if (character === '.') {
      if (sawPoint) return null;
      sawPoint = true;
      continue;
    }
    if (character === '_') {
      const previous = payload[index - 1];
      const next = payload[index + 1];
      if (radixDigitValue(previous) === null || radixDigitValue(next) === null) return null;
      continue;
    }
    const digit = radixDigitValue(character);
    if (digit === null || base !== undefined && digit >= base) return null;
    sawDigit = true;
    if (sawPoint) scale += 1;
  }
  return !sawDigit || sawPoint && scale === 0 ? null : scale;
}

export function evaluateQuery(input, namespace, options = {}) {
  let valueSemanticsProfile;
  try {
    valueSemanticsProfile = getValueSemanticsProfile(options.valueSemantics);
  } catch (error) {
    return {
      ok: false,
      results: [],
      errors: [
        annotateQueryDiagnostic(queryEvaluateError(
          'SANSA_QUERY_INVALID_VALUE_SEMANTICS_PROFILE',
          error instanceof Error ? error.message : 'Invalid value-semantics profile',
        ), { phase: 'policy' }),
      ],
    };
  }

  options = {
    ...options,
    valueSemantics: valueSemanticsProfile,
    [QUERY_IDENTITY_BUDGET]: { inspected: 0 },
  };
  const parsed = typeof input === 'string' ? parseQuery(input, options.parse) : { ok: true, query: input };
  if (!parsed.ok) {
    return {
      ok: false,
      results: [],
      errors: parsed.errors.map((error) => annotateQueryDiagnostic(error, { phase: 'parse' })),
    };
  }

  const query = parsed.query;
  const policy = enforceQueryPolicy(query, options);
  if (!policy.ok) {
    return {
      ok: false,
      results: [],
      errors: [annotateQueryDiagnostic(policy.error, { phase: 'policy' })],
    };
  }

  const from = evaluateQueryFromClause(query.from, namespace, options);
  if (!from.ok) {
    return {
      ok: false,
      results: [],
      errors: from.errors.map((error) => annotateQueryDiagnostic(error, { phase: 'from' })),
    };
  }

  let bindings = from.bindings;
  const fromBudget = checkQueryBudget(options, 'maxFromBindings', bindings.length);
  if (!fromBudget.ok) {
    return {
      ok: false,
      results: [],
      errors: [annotateQueryDiagnostic(fromBudget.error, { phase: 'from' })],
    };
  }

  if (query.where) {
    const whereBudget = checkQueryBudget(options, 'maxWhereCandidates', bindings.length);
    if (!whereBudget.ok) {
      return {
        ok: false,
        results: [],
        errors: [annotateQueryDiagnostic(whereBudget.error, { phase: 'where' })],
      };
    }
    const filtered = [];
    for (const binding of bindings) {
      const evaluated = evaluateQueryExpressionValue(query.where.ast, binding, namespace, options);
      if (!evaluated.ok) {
        return {
          ok: false,
          results: [],
          errors: [annotateQueryDiagnostic(evaluated.error, {
            phase: 'where',
            candidateAddress: getBindingAddress(binding),
          })],
        };
      }
      const boolean = expectBooleanQueryValue(evaluated.value, namespace);
      if (!boolean.ok) {
        return {
          ok: false,
          results: [],
          errors: [annotateQueryDiagnostic(boolean.error, {
            phase: 'where',
            candidateAddress: getBindingAddress(binding),
          })],
        };
      }
      if (boolean.value) filtered.push(binding);
    }
    bindings = filtered;
  }

  if (query.orderBy) {
    const orderBudget = checkQueryBudget(options, 'maxOrderCandidates', bindings.length);
    if (!orderBudget.ok) {
      return {
        ok: false,
        results: [],
        errors: [annotateQueryDiagnostic(orderBudget.error, { phase: 'order' })],
      };
    }
    const ordered = orderQueryBindings(query.orderBy, bindings, namespace, options);
    if (!ordered.ok) {
      return {
        ok: false,
        results: [],
        errors: [annotateQueryDiagnostic(ordered.error, { phase: 'order' })],
      };
    }
    bindings = ordered.bindings;
  }

  if (query.offset) bindings = bindings.slice(query.offset.value);
  if (query.limit) bindings = bindings.slice(0, query.limit.value);

  const resultBudget = checkQueryBudget(options, 'maxResultRecords', bindings.length);
  if (!resultBudget.ok) {
    return {
      ok: false,
      results: [],
      errors: [annotateQueryDiagnostic(resultBudget.error, { phase: 'select' })],
    };
  }

  const results = [];
  for (const binding of bindings) {
    const evaluated = evaluateQueryExpressionValue(query.select.ast, binding, namespace, options);
    if (!evaluated.ok) {
      return {
        ok: false,
        results: [],
        errors: [annotateQueryDiagnostic(evaluated.error, {
          phase: 'select',
          candidateAddress: getBindingAddress(binding),
        })],
      };
    }
    const candidateAddress = getBindingAddress(binding);
    const valueAddress = queryValueAddress(evaluated.value);
    results.push({
      type: 'queryResult',
      ...(candidateAddress === undefined ? {} : { address: candidateAddress, candidateAddress }),
      ...(valueAddress === undefined ? {} : { valueAddress }),
      kind: evaluated.value.type === 'bindingSet' ? 'binding' : 'derived',
      binding,
      value: evaluated.value,
    });
  }

  return { ok: true, results, diagnostics: [] };
}

export function planMutation(input, namespace, options = {}) {
  const normalized = normalizeMutationRequest(input);
  if (!normalized.ok) {
    return { ok: false, errors: [mutationError(normalized.code, normalized.message, normalized.details)] };
  }

  const operationBudget = checkMutationBudget(options, 'maxOperations', normalized.operations.length, 'plan');
  if (!operationBudget.ok) return { ok: false, errors: [operationBudget.error] };
  const preconditionBudget = checkMutationBudget(options, 'maxPreconditions', normalized.preconditions.length, 'plan');
  if (!preconditionBudget.ok) return { ok: false, errors: [preconditionBudget.error] };
  const operationSurface = checkMutationOperationSurfaces(normalized.operations);
  if (!operationSurface.ok) return { ok: false, errors: [operationSurface.error] };
  const valueBudget = checkMutationValueBudgets(options, normalized.operations);
  if (!valueBudget.ok) return { ok: false, errors: [valueBudget.error] };

  const operations = [];
  const seenDestructiveTargets = new Set();
  const seenCreates = new Set();

  for (let operationIndex = 0; operationIndex < normalized.operations.length; operationIndex += 1) {
    const requested = normalized.operations[operationIndex];
    const planned = planMutationOperation(requested, operationIndex, namespace, options);
    if (!planned.ok) return { ok: false, errors: [planned.error] };

    const conflict = checkMutationPlanConflict(planned.operation, seenDestructiveTargets, seenCreates);
    if (!conflict.ok) {
      return {
        ok: false,
        errors: [mutationError(conflict.code, conflict.message, { operationIndex })],
      };
    }

    operations.push(planned.operation);
  }

  const preconditions = evaluateMutationPreconditions(normalized.preconditions, namespace, options);
  if (!preconditions.ok) return { ok: false, errors: [preconditions.error] };
  const portabilityWarnings = collectMutationPortabilityWarnings(operations, preconditions.preconditions);

  return {
    ok: true,
    plan: {
      type: 'SansaMutationPlan',
      planVersion: 'sansa.mutate.plan.v1',
      namespaceState: options.namespaceState ?? getNamespaceState(namespace),
      operations,
      preconditions: preconditions.preconditions,
      ...(normalized.sourceProvenance === undefined ? {} : { sourceProvenance: normalized.sourceProvenance }),
      ...(portabilityWarnings.length === 0 ? {} : { portabilityWarnings }),
      diagnostics: [],
    },
    diagnostics: [],
  };
}

export function applyMutationPlan(plan, namespace, options = {}) {
  if (!plan || typeof plan !== 'object' || !Array.isArray(plan.operations)) {
    return {
      ok: false,
      operationResults: [],
      errors: [mutationError('SANSA_MUTATE_INVALID_PLAN', 'Expected SANSA mutation plan')],
    };
  }

  const adapter = mutationAdapter(namespace);
  if (options.requireAtomic === true && adapter?.supportsAtomicApply !== true) {
    return {
      ok: false,
      operationResults: [],
      errors: [mutationError('SANSA_MUTATE_ATOMIC_APPLY_UNAVAILABLE', 'Mutation adapter does not advertise atomic apply')],
    };
  }

  const operationBudget = checkMutationBudget(options, 'maxOperations', plan.operations.length, 'apply');
  if (!operationBudget.ok) {
    return { ok: false, operationResults: [], errors: [operationBudget.error] };
  }
  const preconditionBudget = checkMutationBudget(options, 'maxPreconditions', (plan.preconditions ?? []).length, 'apply');
  if (!preconditionBudget.ok) {
    return { ok: false, operationResults: [], errors: [preconditionBudget.error] };
  }
  const valueBudget = checkMutationValueBudgets(options, plan.operations, 'apply');
  if (!valueBudget.ok) {
    return { ok: false, operationResults: [], errors: [valueBudget.error] };
  }

  for (let operationIndex = 0; operationIndex < plan.operations.length; operationIndex += 1) {
    const operation = plan.operations[operationIndex];
    const capability = mutationHookForOperation(operation, adapter);
    if (!capability.ok) {
      return {
        ok: false,
        operationResults: [],
        errors: [mutationError(capability.code, capability.message, { operationIndex })],
      };
    }
    const stable = verifyMutationOperationStability(operation, operationIndex, namespace, options);
    if (!stable.ok) {
      return { ok: false, operationResults: [], errors: [stable.error] };
    }
  }

  if (options.recheckPreconditions !== false) {
    const preconditions = verifyPlannedMutationPreconditions(plan.preconditions ?? [], namespace, options);
    if (!preconditions.ok) {
      return { ok: false, operationResults: [], errors: [preconditions.error] };
    }
  }

  const operationResults = [];
  for (let operationIndex = 0; operationIndex < plan.operations.length; operationIndex += 1) {
    const operation = plan.operations[operationIndex];
    const hook = mutationHookForOperation(operation, adapter).hook;
    const applied = applyMutationOperation(operation, hook);
    if (!applied.ok) {
      return {
        ok: false,
        operationResults,
        errors: [mutationError(
          'SANSA_MUTATE_APPLY_FAILED',
          applied.message,
          { operationIndex },
        )],
      };
    }
    operationResults.push({
      operationIndex,
      status: 'applied',
      ...mutationOperationReportAddresses(operation),
      ...(applied.previousAddress === undefined ? {} : { previousAddress: applied.previousAddress }),
      ...(applied.affectedAddress === undefined ? {} : { affectedAddress: applied.affectedAddress }),
      ...(applied.resultingAddress === undefined ? {} : { resultingAddress: applied.resultingAddress }),
      ...(applied.affectedBinding === undefined ? {} : { affectedBinding: applied.affectedBinding }),
    });
  }

  return {
    ok: true,
    planId: plan.planId,
    stateBefore: plan.namespaceState,
    stateAfter: getNamespaceState(namespace),
    operationResults,
    diagnostics: [],
  };
}

function normalizeMutationRequest(input) {
  if (Array.isArray(input)) return { ok: true, operations: input, preconditions: [] };
  if (input && typeof input === 'object' && Array.isArray(input.operations)) {
    const unsupportedField = firstUnsupportedField(input, MUTATION_REQUEST_ENVELOPE_FIELDS);
    if (unsupportedField !== undefined) {
      return {
        ok: false,
        code: 'SANSA_MUTATE_UNSUPPORTED_REQUEST_FIELD',
        message: `Mutation request field '${unsupportedField}' is not supported by the conservative mutation core`,
        details: { requestField: unsupportedField },
      };
    }
    if (input.preconditions !== undefined && !Array.isArray(input.preconditions)) {
      return {
        ok: false,
        code: 'SANSA_MUTATE_INVALID_PRECONDITION',
        message: 'Mutation request preconditions must be a list',
      };
    }
    return {
      ok: true,
      operations: input.operations,
      preconditions: input.preconditions ?? [],
      sourceProvenance: input.provenance,
    };
  }
  if (input && typeof input === 'object' && typeof input.op === 'string') {
    return { ok: true, operations: [input], preconditions: [] };
  }
  return {
    ok: false,
    code: 'SANSA_MUTATE_INVALID_REQUEST',
    message: 'Expected mutation request object, operation object, or operation list',
  };
}

function checkMutationOperationSurfaces(operations) {
  for (let operationIndex = 0; operationIndex < operations.length; operationIndex += 1) {
    const requested = operations[operationIndex];
    if (!requested || typeof requested !== 'object') continue;
    const allowedFields = MUTATION_OPERATION_FIELDS.get(requested.op);
    if (!allowedFields) continue;
    const unsupportedField = firstUnsupportedField(requested, allowedFields);
    if (unsupportedField !== undefined) {
      return {
        ok: false,
        error: mutationError(
          'SANSA_MUTATE_UNSUPPORTED_OPERATION_FIELD',
          `Mutation operation field '${unsupportedField}' is not supported by ${requested.op}`,
          { operationIndex, operationField: unsupportedField },
        ),
      };
    }
  }
  return { ok: true };
}

function firstUnsupportedField(input, allowedFields) {
  return Object.keys(input).find((field) => !allowedFields.has(field));
}

function evaluateMutationPreconditions(preconditions, namespace, options) {
  if (preconditions.length === 0) return { ok: true, preconditions: [] };

  let valueSemanticsProfile;
  try {
    valueSemanticsProfile = getValueSemanticsProfile(options.valueSemantics);
  } catch (error) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_VALUE_SEMANTICS_PROFILE',
        error instanceof Error ? error.message : 'Invalid value-semantics profile',
      ),
    };
  }

  const evaluationOptions = {
    ...options,
    valueSemantics: valueSemanticsProfile,
  };
  const planned = [];
  for (let preconditionIndex = 0; preconditionIndex < preconditions.length; preconditionIndex += 1) {
    const precondition = evaluateMutationPrecondition(
      preconditions[preconditionIndex],
      preconditionIndex,
      namespace,
      evaluationOptions,
    );
    if (!precondition.ok) return precondition;
    planned.push(precondition.precondition);
  }
  return { ok: true, preconditions: planned };
}

function evaluateMutationPrecondition(precondition, preconditionIndex, namespace, options) {
  if (!precondition || typeof precondition !== 'object' || typeof precondition.expression !== 'string') {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_PRECONDITION',
        'Mutation preconditions must provide an expression string',
        { preconditionIndex },
      ),
    };
  }

  const parsed = parseQueryExpression(precondition.expression, mutationQueryExpressionParseOptions(options));
  if (!parsed.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_PRECONDITION',
        'Mutation precondition expression is not valid',
        { preconditionIndex, cause: parsed.errors[0] },
      ),
    };
  }

  const context = resolveMutationPreconditionContext(precondition, preconditionIndex, namespace, options);
  if (!context.ok) return context;

  const evaluated = evaluateQueryExpressionValue(parsed.expression, context.binding, namespace, options);
  if (!evaluated.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        evaluated.error.message,
        { preconditionIndex, cause: evaluated.error },
      ),
    };
  }

  const boolean = expectBooleanQueryValue(evaluated.value, namespace);
  if (!boolean.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        boolean.error.message,
        { preconditionIndex, cause: boolean.error },
      ),
    };
  }
  if (boolean.value !== true) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_FAILED',
        'Mutation precondition evaluated false',
        { preconditionIndex },
      ),
    };
  }

  return {
    ok: true,
    precondition: {
      expression: precondition.expression,
      canonical: parsed.expression.canonical,
      ...(context.target === undefined ? {} : { target: context.target }),
    },
  };
}

function resolveMutationPreconditionContext(precondition, preconditionIndex, namespace, options) {
  if (precondition.target !== undefined) {
    const target = resolveMutationExactTarget(precondition.target, 'precondition target', undefined, namespace, options);
    if (!target.ok) {
      return {
        ok: false,
        error: mutationError(
          'SANSA_MUTATE_INVALID_PRECONDITION',
          target.error.message,
          { preconditionIndex, cause: target.error },
        ),
      };
    }
    return { ok: true, binding: target.target.binding, target: target.target };
  }

  const rootResult = resolveRoot({ kind: 'absolute' }, namespace, options.resolve ?? {});
  if (!rootResult.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        rootResult.error.message,
        { preconditionIndex, cause: rootResult.error },
      ),
    };
  }
  return { ok: true, binding: rootResult.binding };
}

function mutationQueryExpressionParseOptions(options) {
  if (options.parse?.expression || options.parse?.address) {
    return options.parse.expression ?? { address: options.parse.address };
  }
  if (options.parse) return { address: options.parse };
  return {};
}

function checkMutationBudget(options, budget, observed, phase, details = {}) {
  const limit = normalizeQueryBudgetLimit(options.budget?.[budget]);
  if (limit === undefined || observed <= limit) return { ok: true };
  return {
    ok: false,
    error: mutationError(
      'SANSA_MUTATE_BUDGET_EXCEEDED',
      `Mutation budget '${budget}' exceeded: limit ${limit}, observed ${observed}`,
      { phase, budget, limit, observed, ...details },
    ),
  };
}

function checkMutationValueBudgets(options, operations, phase = 'plan') {
  const budget = options.budget ?? {};
  const limits = {
    maxValueNodes: normalizeQueryBudgetLimit(budget.maxValueNodes),
    maxValueDepth: normalizeQueryBudgetLimit(budget.maxValueDepth),
    maxStringLength: normalizeQueryBudgetLimit(budget.maxStringLength),
  };
  if (Object.values(limits).every((value) => value === undefined)) return { ok: true };

  const observed = { valueNodes: 0, valueDepth: 0, stringLength: 0 };
  const paths = { valueDepth: undefined, stringLength: undefined };
  for (let index = 0; index < operations.length; index += 1) {
    const operation = operations[index];
    if (!mutationOperationCarriesValue(operation)) continue;
    const stats = mutationValueStats(operation.value, new WeakSet(), `operations[${index}].value`);
    observed.valueNodes += stats.nodes;
    if (stats.depth > observed.valueDepth) {
      observed.valueDepth = stats.depth;
      paths.valueDepth = stats.depthPath;
    }
    if (stats.stringLength > observed.stringLength) {
      observed.stringLength = stats.stringLength;
      paths.stringLength = stats.stringPath;
    }
  }

  const checks = [
    ['maxValueNodes', observed.valueNodes, undefined],
    ['maxValueDepth', observed.valueDepth, paths.valueDepth],
    ['maxStringLength', observed.stringLength, paths.stringLength],
  ];
  for (const [name, value, valuePath] of checks) {
    const limit = limits[name];
    if (limit !== undefined && value > limit) {
      return checkMutationBudget(
        { budget: { [name]: limit } },
        name,
        value,
        phase,
        valuePath === undefined ? {} : { valuePath },
      );
    }
  }
  return { ok: true };
}

function mutationOperationCarriesValue(operation) {
  return ['create', 'replace', 'insert'].includes(operation?.op) && Object.hasOwn(operation, 'value');
}

function mutationValueStats(value, seen = new WeakSet(), path = 'value') {
  if (typeof value === 'string') return { nodes: 1, depth: 1, depthPath: path, stringLength: value.length, stringPath: path };
  if (value === null || typeof value !== 'object') return { nodes: 1, depth: 1, depthPath: path, stringLength: 0, stringPath: undefined };
  if (seen.has(value)) return { nodes: 0, depth: 0, depthPath: undefined, stringLength: 0, stringPath: undefined };
  seen.add(value);

  const entries = Array.isArray(value)
    ? value.map((entry, index) => [index, entry])
    : Object.entries(value);
  let nodes = 1;
  let childDepth = 0;
  let childDepthPath = path;
  let stringLength = 0;
  let stringPath;
  for (const [key, entry] of entries) {
    const stats = mutationValueStats(entry, seen, `${path}${renderMutationValuePathSegment(key)}`);
    nodes += stats.nodes;
    if (stats.depth > childDepth) {
      childDepth = stats.depth;
      childDepthPath = stats.depthPath;
    }
    if (stats.stringLength > stringLength) {
      stringLength = stats.stringLength;
      stringPath = stats.stringPath;
    }
  }
  return { nodes, depth: childDepth + 1, depthPath: childDepthPath ?? path, stringLength, stringPath };
}

function renderMutationValuePathSegment(key) {
  if (typeof key === 'number') return `[${key}]`;
  return IDENTIFIER_RE.test(key) ? `.${key}` : `[${JSON.stringify(key)}]`;
}

function verifyPlannedMutationPreconditions(preconditions, namespace, options) {
  if (!Array.isArray(preconditions) || preconditions.length === 0) return { ok: true };

  let valueSemanticsProfile;
  try {
    valueSemanticsProfile = getValueSemanticsProfile(options.valueSemantics);
  } catch (error) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_VALUE_SEMANTICS_PROFILE',
        error instanceof Error ? error.message : 'Invalid value-semantics profile',
      ),
    };
  }

  const evaluationOptions = {
    ...options,
    valueSemantics: valueSemanticsProfile,
  };
  for (let preconditionIndex = 0; preconditionIndex < preconditions.length; preconditionIndex += 1) {
    const precondition = verifyPlannedMutationPrecondition(
      preconditions[preconditionIndex],
      preconditionIndex,
      namespace,
      evaluationOptions,
    );
    if (!precondition.ok) return precondition;
  }
  return { ok: true };
}

function verifyPlannedMutationPrecondition(precondition, preconditionIndex, namespace, options) {
  if (!precondition || typeof precondition !== 'object' || typeof precondition.expression !== 'string') {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_PRECONDITION',
        'Planned mutation preconditions must preserve an expression string',
        { preconditionIndex },
      ),
    };
  }

  const parsed = parseQueryExpression(precondition.canonical ?? precondition.expression, mutationQueryExpressionParseOptions(options));
  if (!parsed.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_PRECONDITION',
        'Planned mutation precondition expression is not valid',
        { preconditionIndex, cause: parsed.errors[0] },
      ),
    };
  }

  const context = resolvePlannedMutationPreconditionContext(precondition, preconditionIndex, namespace, options);
  if (!context.ok) return context;

  const evaluated = evaluateQueryExpressionValue(parsed.expression, context.binding, namespace, options);
  if (!evaluated.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        evaluated.error.message,
        { preconditionIndex, cause: evaluated.error },
      ),
    };
  }

  const boolean = expectBooleanQueryValue(evaluated.value, namespace);
  if (!boolean.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        boolean.error.message,
        { preconditionIndex, cause: boolean.error },
      ),
    };
  }
  if (boolean.value !== true) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_FAILED',
        'Mutation precondition no longer holds at apply time',
        { preconditionIndex },
      ),
    };
  }

  return { ok: true };
}

function resolvePlannedMutationPreconditionContext(precondition, preconditionIndex, namespace, options) {
  if (precondition.target !== undefined) {
    const stable = verifyMutationTargetStability(precondition.target, undefined, namespace, options);
    if (!stable.ok) {
      return {
        ok: false,
        error: mutationError(
          'SANSA_MUTATE_STALE_TARGET',
          stable.error.message,
          { preconditionIndex, cause: stable.error },
        ),
      };
    }
    return { ok: true, binding: precondition.target.binding };
  }

  const rootResult = resolveRoot({ kind: 'absolute' }, namespace, options.resolve ?? {});
  if (!rootResult.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PRECONDITION_EVALUATION_FAILED',
        rootResult.error.message,
        { preconditionIndex, cause: rootResult.error },
      ),
    };
  }
  return { ok: true, binding: rootResult.binding };
}

function planMutationOperation(requested, operationIndex, namespace, options) {
  if (!requested || typeof requested !== 'object') {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_INVALID_OPERATION', 'Expected mutation operation object', { operationIndex }),
    };
  }

  switch (requested.op) {
    case 'create':
      return planCreateOperation(requested, operationIndex, namespace, options);
    case 'replace':
      return planReplaceOperation(requested, operationIndex, namespace, options);
    case 'remove':
      return planRemoveOperation(requested, operationIndex, namespace, options);
    case 'insert':
      return planInsertOperation(requested, operationIndex, namespace, options);
    case 'move':
      return planMoveOperation(requested, operationIndex, namespace, options);
    default:
      return {
        ok: false,
        error: mutationError(
          'SANSA_MUTATE_UNSUPPORTED_OPERATION',
          `Unsupported mutation operation: ${requested.op}`,
          { operationIndex },
        ),
      };
  }
}

function planCreateOperation(requested, operationIndex, namespace, options) {
  const parent = resolveMutationExactTarget(requested.parent, 'parent', operationIndex, namespace, options);
  if (!parent.ok) return parent;
  if (!isMutationContainerBinding(namespace, parent.target.binding)) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_PARENT_NOT_CONTAINER',
        `Create parent ${parent.target.canonicalAddress} is not a container binding`,
        { operationIndex },
      ),
    };
  }
  if (typeof requested.name !== 'string' || requested.name.length === 0) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_INVALID_NAME', 'Create requires a non-empty string name', { operationIndex }),
    };
  }
  const datatype = mutationDatatype(requested, operationIndex);
  if (!datatype.ok) return datatype;
  const kind = mutationKind(requested, operationIndex);
  if (!kind.ok) return kind;
  if (selectMember(namespace, parent.target.binding, requested.name).length > 0) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_TARGET_EXISTS',
        `Create target '${requested.name}' already exists under ${parent.target.canonicalAddress}`,
        { operationIndex },
      ),
    };
  }
  return {
    ok: true,
    operation: {
      op: 'create',
      parent: parent.target,
      name: requested.name,
      ...datatype.value,
      ...kind.value,
      value: requested.value,
      ...mutationProvenance(requested),
    },
  };
}

function planReplaceOperation(requested, operationIndex, namespace, options) {
  const target = resolveMutationExactTarget(requested.target, 'target', operationIndex, namespace, options);
  if (!target.ok) return target;
  const datatype = mutationDatatype(requested, operationIndex);
  if (!datatype.ok) return datatype;
  const kind = mutationKind(requested, operationIndex);
  if (!kind.ok) return kind;
  return {
    ok: true,
    operation: {
      op: 'replace',
      target: target.target,
      ...datatype.value,
      ...kind.value,
      value: requested.value,
      ...mutationProvenance(requested),
    },
  };
}

function planRemoveOperation(requested, operationIndex, namespace, options) {
  const target = resolveMutationExactTarget(requested.target, 'target', operationIndex, namespace, options);
  if (!target.ok) return target;
  if (target.target.address.root.kind === 'absolute' && target.target.address.selectors.length === 0) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_ROOT_REMOVE_FORBIDDEN', 'The conservative mutation core does not remove the namespace root', { operationIndex }),
    };
  }
  return {
    ok: true,
    operation: {
      op: 'remove',
      target: target.target,
      ...mutationProvenance(requested),
    },
  };
}

function planInsertOperation(requested, operationIndex, namespace, options) {
  const container = resolveMutationExactTarget(requested.container, 'container', operationIndex, namespace, options);
  if (!container.ok) return container;
  if (!isMutationOrderedContainerBinding(namespace, container.target.binding)) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_CONTAINER_NOT_ORDERED',
        `Insert container ${container.target.canonicalAddress} is not an ordered container binding`,
        { operationIndex },
      ),
    };
  }
  const placement = resolveMutationPlacement(requested.placement, container.target, operationIndex, namespace, options);
  if (!placement.ok) return placement;
  const datatype = mutationDatatype(requested, operationIndex);
  if (!datatype.ok) return datatype;
  const kind = mutationKind(requested, operationIndex);
  if (!kind.ok) return kind;
  return {
    ok: true,
    operation: {
      op: 'insert',
      container: container.target,
      placement: placement.placement,
      ...datatype.value,
      ...kind.value,
      value: requested.value,
      ...mutationProvenance(requested),
    },
  };
}

function planMoveOperation(requested, operationIndex, namespace, options) {
  const source = resolveMutationExactTarget(requested.source, 'source', operationIndex, namespace, options);
  if (!source.ok) return source;
  const container = resolveMutationExactTarget(requested.container, 'container', operationIndex, namespace, options);
  if (!container.ok) return container;
  if (!isMutationOrderedContainerBinding(namespace, container.target.binding)) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_CONTAINER_NOT_ORDERED',
        `Move container ${container.target.canonicalAddress} is not an ordered container binding`,
        { operationIndex },
      ),
    };
  }
  if (!isDirectChildOfContainer(namespace, source.target.binding, container.target.binding)) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_MOVE_CONTAINER',
        'The conservative mutation core only moves bindings within their current ordered container',
        { operationIndex },
      ),
    };
  }
  const placement = resolveMutationPlacement(requested.placement, container.target, operationIndex, namespace, options);
  if (!placement.ok) return placement;
  if (placement.placement.anchor && sameMutationBinding(source.target, placement.placement.anchor, namespace)) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_INVALID_MOVE_ANCHOR', 'Move placement anchor must not be the moved source binding', { operationIndex }),
    };
  }
  return {
    ok: true,
    operation: {
      op: 'move',
      source: source.target,
      container: container.target,
      placement: placement.placement,
      ...mutationProvenance(requested),
    },
  };
}

function resolveMutationPlacement(placement, containerTarget, operationIndex, namespace, options) {
  const kind = typeof placement === 'string' ? placement : placement?.kind;
  if (kind !== 'first' && kind !== 'last' && kind !== 'before' && kind !== 'after') {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_UNSUPPORTED_PLACEMENT', 'Placement must be first, last, before, or after', { operationIndex }),
    };
  }
  if (kind === 'first' || kind === 'last') return { ok: true, placement: { kind } };

  const anchorInput = placement.anchor ?? placement.target;
  const anchor = resolveMutationExactTarget(anchorInput, 'anchor', operationIndex, namespace, options);
  if (!anchor.ok) return anchor;
  if (!isDirectChildOfContainer(namespace, anchor.target.binding, containerTarget.binding)) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_ANCHOR',
        'Ordered insertion and movement anchors must be direct children of the target container',
        { operationIndex },
      ),
    };
  }
  return { ok: true, placement: { kind, anchor: anchor.target } };
}

function resolveMutationExactTarget(input, role, operationIndex, namespace, options) {
  const parsed = typeof input === 'string' ? parseAddress(input, options.parse) : { ok: true, address: input };
  if (!parsed.ok) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_TARGET',
        `${capitalize(role)} address is not a valid SANSA address`,
        { operationIndex, cause: parsed.errors[0] },
      ),
    };
  }
  if (!parsed.address || parsed.address.type !== 'SansaAddress') {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_INVALID_TARGET', `${capitalize(role)} must be a SANSA address`, { operationIndex }),
    };
  }
  if (!parsed.address.isExact) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_NON_EXACT_TARGET', `${capitalize(role)} address must be exact`, { operationIndex }),
    };
  }

  const resolved = resolveConsumerAddress(parsed.address, namespace, options.resolve);
  if (!resolved.ok) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_TARGET_RESOLUTION_FAILED', `${capitalize(role)} address failed to resolve`, {
        operationIndex,
        cause: resolved.errors[0],
      }),
    };
  }
  if (resolved.bindings.length === 0) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_TARGET_MISS', `${capitalize(role)} address resolved no bindings`, { operationIndex }),
    };
  }
  if (resolved.bindings.length > 1) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_TARGET_MULTIPLICITY', `${capitalize(role)} address resolved multiple bindings`, { operationIndex }),
    };
  }

  const binding = resolved.bindings[0];
  const canonicalAddress = getBindingAddress(binding) ?? parsed.address.canonical;
  return {
    ok: true,
    target: {
      requestedAddress: typeof input === 'string' ? input : renderAddress(parsed.address),
      canonicalAddress,
      address: parsed.address,
      binding,
      ...mutationBindingIdentity(namespace, binding),
      ...mutationTargetWarnings(parsed.warnings),
    },
  };
}

function collectMutationPortabilityWarnings(operations, preconditions) {
  const warnings = [];
  for (const operation of operations) {
    for (const target of mutationOperationTargets(operation)) {
      warnings.push(...(target.portabilityWarnings ?? []));
    }
  }
  for (const precondition of preconditions) {
    warnings.push(...(precondition.target?.portabilityWarnings ?? []));
  }
  return warnings;
}

function mutationTargetWarnings(warnings) {
  const portabilityWarnings = (warnings ?? []).filter((warning) => warning.code?.startsWith('SANSA_NON_PORTABLE_'));
  return portabilityWarnings.length === 0 ? {} : { portabilityWarnings };
}

function checkMutationPlanConflict(operation, seenDestructiveTargets, seenCreates) {
  if (operation.op === 'create') {
    const key = `${mutationTargetKey(operation.parent)}\u0000${operation.name}`;
    if (seenCreates.has(key)) {
      return { ok: false, code: 'SANSA_MUTATE_DUPLICATE_TARGET', message: 'Plan contains repeated create for the same parent/name' };
    }
    seenCreates.add(key);
    return { ok: true };
  }
  for (const target of mutationOperationDestructiveTargets(operation)) {
    const key = mutationTargetKey(target);
    if (seenDestructiveTargets.has(key)) {
      return { ok: false, code: 'SANSA_MUTATE_DUPLICATE_TARGET', message: 'Plan contains repeated destructive operation for the same binding' };
    }
    seenDestructiveTargets.add(key);
  }
  return { ok: true };
}

function mutationOperationDestructiveTargets(operation) {
  if (operation.op === 'replace' || operation.op === 'remove') return [operation.target];
  if (operation.op === 'move') return [operation.source];
  return [];
}

function verifyMutationOperationStability(operation, operationIndex, namespace, options) {
  const targets = mutationOperationTargets(operation);
  for (const target of targets) {
    const stable = verifyMutationTargetStability(target, operationIndex, namespace, options);
    if (!stable.ok) return stable;
  }
  return { ok: true };
}

function verifyMutationTargetStability(target, operationIndex, namespace, options) {
  const resolved = resolveConsumerAddress(target.address, namespace, options.resolve);
  if (!resolved.ok || resolved.bindings.length !== 1) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_STALE_TARGET', `Mutation target is stale: ${target.canonicalAddress}`, { operationIndex }),
    };
  }
  const current = resolved.bindings[0];
  if (!sameMutationBinding(target, { binding: current, ...mutationBindingIdentity(namespace, current) }, namespace)) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_STALE_TARGET', `Mutation target identity changed: ${target.canonicalAddress}`, { operationIndex }),
    };
  }
  const observedState = mutationObservedState(namespace, current);
  if (target.observedState !== undefined && observedState !== undefined && target.observedState !== observedState) {
    return {
      ok: false,
      error: mutationError('SANSA_MUTATE_STALE_TARGET', `Mutation target state changed: ${target.canonicalAddress}`, { operationIndex }),
    };
  }
  return { ok: true };
}

function mutationOperationTargets(operation) {
  switch (operation.op) {
    case 'create':
      return [operation.parent];
    case 'replace':
    case 'remove':
      return [operation.target];
    case 'insert':
      return operation.placement.anchor ? [operation.container, operation.placement.anchor] : [operation.container];
    case 'move':
      return operation.placement.anchor
        ? [operation.source, operation.container, operation.placement.anchor]
        : [operation.source, operation.container];
    default:
      return [];
  }
}

function applyMutationOperation(operation, hook) {
  try {
    let result;
    if (operation.op === 'create') {
      result = hook(operation.parent.binding, operation.name, operation.value, operation);
    } else if (operation.op === 'replace') {
      result = hook(operation.target.binding, operation.value, operation);
    } else if (operation.op === 'remove') {
      result = hook(operation.target.binding, operation);
    } else if (operation.op === 'insert') {
      result = hook(operation.container.binding, operation.placement, operation.value, operation);
    } else if (operation.op === 'move') {
      result = hook(operation.source.binding, operation.container.binding, operation.placement, operation);
    }
    if (result && typeof result === 'object' && result.ok === false) {
      return { ok: false, message: result.message ?? result.error?.message ?? 'Mutation adapter rejected operation' };
    }
    const affectedBinding = result?.binding ?? result?.affectedBinding
      ?? operation.target?.binding
      ?? operation.source?.binding
      ?? operation.parent?.binding
      ?? operation.container?.binding;
    const fallbackAffectedAddress = getBindingAddress(affectedBinding);
    return {
      ok: true,
      previousAddress: operation.target?.canonicalAddress ?? operation.source?.canonicalAddress,
      affectedAddress: result?.affectedAddress ?? fallbackAffectedAddress,
      resultingAddress: result?.resultingAddress ?? fallbackMutationResultingAddress(operation, fallbackAffectedAddress),
      affectedBinding,
    };
  } catch (error) {
    return {
      ok: false,
      message: error instanceof Error ? error.message : 'Mutation adapter threw while applying operation',
    };
  }
}

function mutationOperationReportAddresses(operation) {
  const output = {};
  if (operation.target?.canonicalAddress) output.targetAddress = operation.target.canonicalAddress;
  if (operation.parent?.canonicalAddress) output.parentAddress = operation.parent.canonicalAddress;
  if (operation.container?.canonicalAddress) output.containerAddress = operation.container.canonicalAddress;
  if (operation.source?.canonicalAddress) output.sourceAddress = operation.source.canonicalAddress;
  if (operation.placement?.anchor?.canonicalAddress) output.anchorAddress = operation.placement.anchor.canonicalAddress;
  return output;
}

function fallbackMutationResultingAddress(operation, affectedAddress) {
  if (operation.op === 'remove') return undefined;
  if (operation.op === 'create' && operation.parent?.canonicalAddress) {
    return appendMemberAddress(operation.parent.canonicalAddress, operation.name);
  }
  return affectedAddress;
}

function appendMemberAddress(parentAddress, name) {
  return IDENTIFIER_RE.test(name)
    ? `${parentAddress}.${name}`
    : `${parentAddress}.[${quotePayload(name)}]`;
}

function mutationHookForOperation(operation, adapter) {
  const capabilityFlag = mutationCapabilityFlagForOperation(operation.op);
  if (capabilityFlag && adapter?.[capabilityFlag] === false) {
    return {
      ok: false,
      code: 'SANSA_MUTATE_UNSUPPORTED_ADAPTER_OPERATION',
      message: `Mutation adapter does not advertise '${operation.op}' support`,
    };
  }
  const hook = adapter?.[operation.op];
  if (typeof hook === 'function') return { ok: true, hook };
  return {
    ok: false,
    code: 'SANSA_MUTATE_UNSUPPORTED_ADAPTER_OPERATION',
    message: `Mutation adapter does not support '${operation.op}'`,
  };
}

function mutationCapabilityFlagForOperation(op) {
  switch (op) {
    case 'create':
      return 'supportsCreate';
    case 'replace':
      return 'supportsReplace';
    case 'remove':
      return 'supportsRemove';
    case 'insert':
      return 'supportsOrderedInsert';
    case 'move':
      return 'supportsMove';
    default:
      return null;
  }
}

function mutationAdapter(namespace) {
  return namespace?.mutate && typeof namespace.mutate === 'object' ? namespace.mutate : namespace;
}

function mutationBindingIdentity(namespace, binding) {
  const identity = {};
  const handle = mutationBindingHandle(namespace, binding);
  const observedState = mutationObservedState(namespace, binding);
  if (handle !== undefined) identity.bindingHandle = handle;
  if (observedState !== undefined) identity.observedState = observedState;
  return identity;
}

function mutationBindingHandle(namespace, binding) {
  if (typeof namespace?.bindingHandle === 'function') return namespace.bindingHandle(binding);
  if (typeof namespace?.mutate?.bindingHandle === 'function') return namespace.mutate.bindingHandle(binding);
  return binding.bindingHandle ?? binding.handle ?? binding.id;
}

function mutationObservedState(namespace, binding) {
  if (typeof namespace?.observedState === 'function') return namespace.observedState(binding);
  if (typeof namespace?.mutate?.observedState === 'function') return namespace.mutate.observedState(binding);
  return binding.observedState ?? binding.revision ?? binding.version;
}

function getNamespaceState(namespace) {
  if (typeof namespace?.namespaceState === 'function') return namespace.namespaceState();
  if (typeof namespace?.mutate?.namespaceState === 'function') return namespace.mutate.namespaceState();
  return namespace?.namespaceState ?? namespace?.state;
}

function sameMutationBinding(left, right, namespace) {
  if (left.binding === right.binding) return true;
  const adapter = mutationAdapter(namespace);
  if (typeof adapter?.sameBinding === 'function') return adapter.sameBinding(left.binding, right.binding) === true;
  if (left.bindingHandle !== undefined && right.bindingHandle !== undefined) return left.bindingHandle === right.bindingHandle;
  return false;
}

function isDirectChildOfContainer(namespace, child, container) {
  if (typeof namespace.parent === 'function' && namespace.parent(child) === container) return true;
  if (child.parent === container) return true;
  return getChildren(namespace, container).includes(child);
}

function isMutationContainerBinding(namespace, binding) {
  return mutationContainerKind(namespace, binding) !== undefined;
}

function isMutationOrderedContainerBinding(namespace, binding) {
  return ['list', 'tuple', 'node'].includes(mutationContainerKind(namespace, binding));
}

function mutationContainerKind(namespace, binding) {
  const rawKind = typeof namespace.representationKind === 'function'
    ? namespace.representationKind(binding)
    : binding.representationKind ?? binding.kind ?? binding.type;
  const kind = typeof rawKind === 'string' ? lowerFirst(rawKind) : undefined;
  if (['object', 'obj', 'o', 'envelope', 'objectNode'].includes(kind)) return 'object';
  if (['list', 'listNode'].includes(kind)) return 'list';
  if (['tuple', 'tupleLiteral'].includes(kind)) return 'tuple';
  if (['node', 'nodeLiteral'].includes(kind)) return 'node';
  if (kind === 'attributeSpace') return 'attributeSpace';

  const rawSemanticType = typeof namespace.semanticType === 'function'
    ? namespace.semanticType(binding)
    : binding.semanticType ?? binding.datatype;
  const semanticType = typeof rawSemanticType === 'string'
    ? datatypeBaseName(rawSemanticType)
    : undefined;
  if (['object', 'obj', 'o', 'envelope'].includes(semanticType)) return 'object';
  if (semanticType === 'list') return 'list';
  if (semanticType === 'tuple') return 'tuple';
  if (semanticType === 'node') return 'node';
  return undefined;
}

function mutationTargetKey(target) {
  if (target.bindingHandle !== undefined) return `handle:${String(target.bindingHandle)}`;
  return `address:${target.canonicalAddress}`;
}

function mutationProvenance(requested) {
  return requested.provenance === undefined ? {} : { provenance: requested.provenance };
}

function mutationDatatype(requested, operationIndex) {
  if (requested.datatype === undefined) return { ok: true, value: {} };
  if (typeof requested.datatype !== 'string' || requested.datatype.trim().length === 0) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_DATATYPE',
        'Mutation datatype must be a non-empty string when provided',
        { operationIndex },
      ),
    };
  }
  return { ok: true, value: { datatype: requested.datatype.trim() } };
}

function mutationKind(requested, operationIndex) {
  if (requested.kind === undefined) return { ok: true, value: {} };
  if (typeof requested.kind !== 'string' || requested.kind.trim().length === 0) {
    return {
      ok: false,
      error: mutationError(
        'SANSA_MUTATE_INVALID_KIND',
        'Mutation kind must be a non-empty string when provided',
        { operationIndex },
      ),
    };
  }
  return { ok: true, value: { kind: requested.kind.trim() } };
}

function mutationError(code, message, details = {}) {
  return { code, message, ...details };
}

function resolveMutationTargetSurface(targetSurface) {
  if (targetSurface === undefined || targetSurface === null || targetSurface === '' || targetSurface === 'aeon') {
    return { ok: true, surface: aeonMutationTargetSurface };
  }
  if (targetSurface === 'json' || targetSurface === 'json-compatible') {
    return { ok: true, surface: jsonMutationTargetSurface };
  }
  if (targetSurface === 'telex' || targetSurface === 'telex.aes') {
    return { ok: true, surface: telexMutationTargetSurface };
  }
  if (targetSurface && typeof targetSurface === 'object' && typeof targetSurface.validateOperation === 'function') {
    return {
      ok: true,
      surface: {
        id: typeof targetSurface.id === 'string' && targetSurface.id.length > 0 ? targetSurface.id : 'custom',
        validateOperation: targetSurface.validateOperation,
      },
    };
  }
  return {
    ok: false,
    error: mutationTargetSurfaceError(
      'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
      'Mutation target surface must be "aeon", "json", "json-compatible", "telex", "telex.aes", or an object with validateOperation',
      { targetFormat: targetSurfaceId(targetSurface) },
    ),
  };
}

const aeonMutationTargetSurface = Object.freeze({
  id: 'aeon',
  validateOperation(operation, context) {
    const datatype = operation.datatype;
    if (datatype !== undefined) {
      const datatypeResult = validateAeonTargetDatatype(datatype, context.operationIndex);
      if (!datatypeResult.ok) return datatypeResult;
    }
    if (operationHasValue(operation)) {
      return validateAeonTargetValue(operation.value, operation, `operations[${context.operationIndex}].value`, context.operationIndex);
    }
    return { ok: true };
  },
});

const jsonMutationTargetSurface = Object.freeze({
  id: 'json',
  validateOperation(operation, context) {
    const addressResult = validateJsonTargetAddresses(operation, context.operationIndex);
    if (!addressResult.ok) return addressResult;
    const containerResult = validateJsonTargetContainers(operation, context.operationIndex);
    if (!containerResult.ok) return containerResult;
    if (operation.datatype !== undefined) {
      const datatypeResult = validateJsonTargetDatatype(operation.datatype, context.operationIndex);
      if (!datatypeResult.ok) return datatypeResult;
    }
    if (operation.kind !== undefined) {
      const kindResult = validateJsonTargetDatatype(operation.kind, context.operationIndex, 'kind');
      if (!kindResult.ok) return kindResult;
    }
    if (!operationHasValue(operation)) return { ok: true };
    return validateJsonTargetValue(operation.value, context.operationIndex, 'value');
  },
});

const TELEX_SCALAR_KINDS = new Set([
  'StringLiteral',
  'NumberLiteral',
  'InfinityLiteral',
  'NaNLiteral',
  'NullLiteral',
  'BooleanLiteral',
  'ToggleLiteral',
  'HexLiteral',
  'RadixLiteral',
  'EncodingLiteral',
  'SeparatorLiteral',
  'SymbolicLiteral',
  'SansaAddressLiteral',
  'DateLiteral',
  'TimeLiteral',
  'DateTimeLiteral',
  'WTCDateTimeLiteral',
]);

const TELEX_KIND_ALIASES = new Map([
  ['string', 'StringLiteral'], ['trimtick', 'StringLiteral'], ['prose', 'StringLiteral'],
  ['number', 'NumberLiteral'], ['n', 'NumberLiteral'], ['integer', 'NumberLiteral'],
  ['boolean', 'BooleanLiteral'], ['bool', 'BooleanLiteral'], ['toggle', 'ToggleLiteral'],
  ['null', 'NullLiteral'], ['nan', 'NaNLiteral'], ['infinity', 'InfinityLiteral'],
  ['hex', 'HexLiteral'], ['radix', 'RadixLiteral'], ['encoding', 'EncodingLiteral'],
  ['base64', 'EncodingLiteral'], ['embed', 'EncodingLiteral'], ['inline', 'EncodingLiteral'],
  ['separator', 'SeparatorLiteral'], ['sep', 'SeparatorLiteral'], ['csv', 'SeparatorLiteral'],
  ['symbol', 'SymbolicLiteral'], ['symbolicliteral', 'SymbolicLiteral'],
  ['sansa', 'SansaAddressLiteral'], ['sansaaddress', 'SansaAddressLiteral'],
  ['date', 'DateLiteral'], ['time', 'TimeLiteral'], ['datetime', 'DateTimeLiteral'], ['wtc', 'WTCDateTimeLiteral'],
]);

const telexMutationTargetSurface = Object.freeze({
  id: 'telex',
  validateOperation(operation, context) {
    if (operation.op !== 'replace') {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_OPERATION',
          `Target 'telex' currently supports scalar replacement only; '${operation.op}' requires a portable path-rewrite contract`,
          { operationIndex: context.operationIndex, targetFormat: 'telex' },
        ),
      };
    }
    const exposedKind = operation.target?.binding?.representationKind;
    const kind = TELEX_SCALAR_KINDS.has(exposedKind)
      ? exposedKind
      : TELEX_KIND_ALIASES.get(String(exposedKind ?? '').toLowerCase());
    if (!TELEX_SCALAR_KINDS.has(kind)) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
          `Target 'telex' cannot replace '${exposedKind ?? 'unknown'}' bindings in the scalar-replacement profile`,
          { operationIndex: context.operationIndex, targetFormat: 'telex' },
        ),
      };
    }
    if (operation.value !== null && typeof operation.value === 'object') {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
          "Target 'telex' scalar replacement requires a scalar mutation value",
          { operationIndex: context.operationIndex, targetFormat: 'telex', valuePath: `operations[${context.operationIndex}].value` },
        ),
      };
    }
    const proposedKind = telexProposedScalarKind(operation, kind);
    if (!proposedKind.ok) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          proposedKind.code,
          proposedKind.message,
          { operationIndex: context.operationIndex, targetFormat: 'telex', ...(operation.datatype === undefined ? {} : { datatype: operation.datatype }) },
        ),
      };
    }
    const valueResult = validateTelexScalarMutationValue(proposedKind.kind, operation.value, kind);
    if (!valueResult.ok) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
          valueResult.message,
          { operationIndex: context.operationIndex, targetFormat: 'telex', valuePath: `operations[${context.operationIndex}].value` },
        ),
      };
    }
    return { ok: true };
  },
});

function telexProposedScalarKind(operation, fallback) {
  if (operation.kind !== undefined) {
    if (TELEX_SCALAR_KINDS.has(operation.kind)) return { ok: true, kind: operation.kind };
    const alias = TELEX_KIND_ALIASES.get(String(operation.kind).toLowerCase());
    if (alias !== undefined) return { ok: true, kind: alias };
    return {
      ok: false,
      code: 'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
      message: `Target 'telex' scalar replacement cannot represent kind '${operation.kind}'`,
    };
  }
  if (operation.datatype !== undefined) {
    const base = datatypeBaseName(operation.datatype)?.toLowerCase();
    const alias = TELEX_KIND_ALIASES.get(base);
    if (alias !== undefined) return { ok: true, kind: alias };
    if (/^(?:u?int|float|decimal)\d*$/u.test(base ?? '')) return { ok: true, kind: 'NumberLiteral' };
    if (/^radix\d+$/u.test(base ?? '')) return { ok: true, kind: 'RadixLiteral' };
    if (['object', 'list', 'tuple', 'node', 'clonereference', 'pointerreference'].includes(base)) {
      return {
        ok: false,
        code: 'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        message: `Target 'telex' scalar replacement cannot represent datatype '${operation.datatype}'`,
      };
    }
  }
  return { ok: true, kind: fallback };
}

function validateTelexScalarMutationValue(kind, value, currentKind) {
  if (kind === 'NumberLiteral') {
    return typeof value === 'number' && Number.isFinite(value)
      ? { ok: true }
      : { ok: false, message: "Target 'telex' NumberLiteral replacement requires a finite JSON number" };
  }
  if (kind === 'BooleanLiteral') {
    return typeof value === 'boolean'
      ? { ok: true }
      : { ok: false, message: "Target 'telex' BooleanLiteral replacement requires a JSON boolean" };
  }
  if (kind === 'NullLiteral') {
    return (typeof value === 'string' && value.length > 0) || (value === null && currentKind === 'NullLiteral')
      ? { ok: true }
      : { ok: false, message: "Target 'telex' NullLiteral replacement requires a non-empty reason string, or null for an existing null event" };
  }
  if (kind === 'NaNLiteral') {
    return value === null || value === 'NaN'
      ? { ok: true }
      : { ok: false, message: "Target 'telex' NaNLiteral replacement requires null or 'NaN'" };
  }
  if (kind === 'InfinityLiteral') {
    return value === Infinity || value === -Infinity || ['Infinity', '+Infinity', '-Infinity'].includes(value)
      ? { ok: true }
      : { ok: false, message: "Target 'telex' InfinityLiteral replacement requires an infinity token" };
  }
  return typeof value === 'string'
    ? { ok: true }
    : { ok: false, message: `Target 'telex' ${kind} replacement requires a JSON string` };
}

function normalizeMutationTargetSurfaceOperationResult(result, context) {
  if (result === undefined || result === true || result?.ok === true) return { ok: true };
  if (result === false) {
    return {
      ok: false,
      errors: [mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_OPERATION',
        `Target '${context.targetFormat}' rejected ${context.operation.op}`,
        { operationIndex: context.operationIndex, targetFormat: context.targetFormat },
      )],
    };
  }
  const rawErrors = Array.isArray(result?.errors)
    ? result.errors
    : result?.error
      ? [result.error]
      : result?.ok === false
        ? [result]
        : [];
  if (rawErrors.length === 0) {
    return {
      ok: false,
      errors: [mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_OPERATION',
        `Target '${context.targetFormat}' returned an invalid target-surface result`,
        { operationIndex: context.operationIndex, targetFormat: context.targetFormat },
      )],
    };
  }
  return {
    ok: false,
    errors: rawErrors.map((error) => normalizeMutationTargetSurfaceError(error, context)),
  };
}

function normalizeMutationTargetSurfaceError(error, context) {
  const {
    ok: _ok,
    error: _error,
    errors: _errors,
    ...details
  } = error ?? {};
  return mutationTargetSurfaceError(
    error?.code ?? 'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
    error?.message ?? `Target '${context.targetFormat}' rejected ${context.operation.op}`,
    {
      ...details,
      phase: 'target',
      operationIndex: Number.isInteger(error?.operationIndex) ? error.operationIndex : context.operationIndex,
      targetFormat: typeof error?.targetFormat === 'string' ? error.targetFormat : context.targetFormat,
    },
  );
}

function validateAeonTargetDatatype(datatype, operationIndex) {
  const base = datatypeBaseName(datatype);
  const hasGeneric = String(datatype).includes('<');
  const hasArgument = String(datatype).includes('[');
  const expression = parseAeonTargetDatatypeExpression(datatype, operationIndex);
  if (!expression.ok) return expression;
  if (hasGeneric && !aeonDatatypeAllowsGeneric(base)) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'aeon' does not allow generic parameters on datatype '${base ?? datatype}'`,
        { operationIndex, targetFormat: 'aeon', datatype },
      ),
    };
  }
  if (hasArgument && !aeonDatatypeAllowsArgument(base)) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'aeon' does not allow square-bracket arguments on datatype '${base ?? datatype}'`,
        { operationIndex, targetFormat: 'aeon', datatype },
      ),
    };
  }
  const reserved = validateAeonReservedDatatypeSurface(datatype, base, operationIndex);
  if (!reserved.ok) return reserved;
  const nodeGeneric = validateAeonNodeDatatypeSurface(expression.expression, datatype, operationIndex);
  if (!nodeGeneric.ok) return nodeGeneric;
  return { ok: true };
}

function validateAeonTargetValue(value, hints, path, operationIndex) {
  const compatibility = validateAeonDatatypeKindCompatibility(hints, path, operationIndex);
  if (!compatibility.ok) return compatibility;
  const representation = representationKindFromMutationHints(hints);
  if (representation === 'node') return validateAeonTargetNodeValue(value, path, operationIndex);
  const scalarValidation = validateAeonTargetScalarValue(value, representation, path, operationIndex);
  if (!scalarValidation.ok) return scalarValidation;
  // A reference payload is an address, not the referred value's literal data.
  if (['cloneReference', 'pointerReference', 'referenceForm'].includes(representation)) return { ok: true };
  if (typeof hints.datatype === 'string' && ['prose', 'trimtick'].includes(datatypeBaseName(hints.datatype))
      && typeof value === 'string' && !isRepresentableTrimtickPayload(value)) {
    return invalidAeonTargetValue('Trimtick normalization cannot preserve trailing newlines or whitespace-only content lines', path, operationIndex);
  }
  if (typeof hints.datatype === 'string' && datatypeBaseName(hints.datatype) === 'base64'
      && (typeof value !== 'string' || !isDecodableBase64UrlPayload(value))) {
    return invalidAeonTargetValue('base64 requires decodable Base64URL with zero unused tail bits', path, operationIndex);
  }
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index += 1) {
      const result = validateAeonTargetValue(value[index], {}, `${path}[${index}]`, operationIndex);
      if (!result.ok) return result;
    }
    return { ok: true };
  }
  if (value && typeof value === 'object') {
    for (const [key, entry] of Object.entries(value)) {
      const entryPath = `${path}${renderMutationValuePathSegment(key)}`;
      if (key.length === 0) return invalidAeonTargetValue('Keys must not be empty', entryPath, operationIndex);
      const result = validateAeonTargetValue(entry, {}, entryPath, operationIndex);
      if (!result.ok) return result;
    }
  }
  return { ok: true };
}

function validateAeonTargetNodeValue(value, path, operationIndex) {
  if (value === undefined || value === null) return { ok: true };
  if (Array.isArray(value)) return validateAeonTargetValue(value, {}, `${path}.children`, operationIndex);
  if (typeof value !== 'object') {
    return invalidAeonTargetValue('Node values must be an object with tag/children or an array of children', path, operationIndex);
  }
  if (value.tag !== undefined && !validAeonIdentifier(value.tag)) {
    return invalidAeonTargetValue('Node tags must be non-empty AEON identifiers', `${path}.tag`, operationIndex);
  }
  if (value.children !== undefined && !Array.isArray(value.children)) {
    return invalidAeonTargetValue('Node children must be a list when provided', `${path}.children`, operationIndex);
  }
  if (Array.isArray(value.children)) {
    for (let index = 0; index < value.children.length; index += 1) {
      const result = validateAeonTargetValue(value.children[index], {}, `${path}.children[${index}]`, operationIndex);
      if (!result.ok) return result;
    }
  }
  if (value.attributes !== undefined) {
    if (!value.attributes || typeof value.attributes !== 'object' || Array.isArray(value.attributes)) {
      return invalidAeonTargetValue('Node attributes must be an object when provided', `${path}.attributes`, operationIndex);
    }
    for (const [key, entry] of Object.entries(value.attributes)) {
      const entryPath = `${path}.attributes${renderMutationValuePathSegment(key)}`;
      if (key.length === 0) return invalidAeonTargetValue('Keys must not be empty', entryPath, operationIndex);
      const result = validateAeonTargetValue(entry, {}, entryPath, operationIndex);
      if (!result.ok) return result;
    }
  }
  return { ok: true };
}

function validateAeonTargetScalarValue(value, representation, path, operationIndex) {
  if (representation === undefined || ['object', 'list', 'tuple', 'node'].includes(representation)) {
    return { ok: true };
  }
  switch (representation) {
    case 'string':
      return typeof value === 'string'
        ? { ok: true }
        : invalidAeonTargetValue('String literals must use string payloads', path, operationIndex);
    case 'symbol':
      return typeof value === 'string' && value.length > 0
        ? { ok: true }
        : invalidAeonTargetValue('Symbol literals must use non-empty string payloads', path, operationIndex);
    case 'number':
      return typeof value === 'number' && Number.isFinite(value)
        ? { ok: true }
        : invalidAeonTargetValue('Number literals must use finite number payloads', path, operationIndex);
    case 'boolean':
      return typeof value === 'boolean'
        ? { ok: true }
        : invalidAeonTargetValue('Boolean literals must use boolean payloads', path, operationIndex);
    case 'hex':
      return typeof value === 'string' && value.trim() === value && /^[0-9A-Fa-f]+$/.test(value)
        ? { ok: true }
        : invalidAeonTargetValue('Hex literals must be non-empty hexadecimal text without the # prefix', path, operationIndex);
    case 'radix':
      return typeof value === 'string' && isAeonRadixPayload(value)
        ? { ok: true }
        : invalidAeonTargetValue('Radix literals must be valid AEON radix payload text without the % prefix', path, operationIndex);
    case 'encoding':
      return typeof value === 'string' && isAeonEncodingPayload(value)
        ? { ok: true }
        : invalidAeonTargetValue('Encoding literals must be valid AEON Base64URL payload text without the & prefix', path, operationIndex);
    case 'separator':
      return typeof value === 'string' && isAeonSeparatorPayload(value)
        ? { ok: true }
        : invalidAeonTargetValue('Separator literals must be valid AEON separator payload text without the ^ prefix', path, operationIndex);
    case 'sansa':
    case 'sansaAddress':
      return typeof value === 'string' && isValidSansaAddressValue(value)
        ? { ok: true }
        : invalidAeonTargetValue('SANSA literals must be valid SANSA address text', path, operationIndex);
    case 'toggle':
      return ['yes', 'no', 'on', 'off'].includes(value)
        ? { ok: true }
        : invalidAeonTargetValue('Toggle literals must be one of yes, no, on, or off', path, operationIndex);
    case 'null':
      return value === null || (typeof value === 'string' && validAeonIdentifier(value))
        ? { ok: true }
        : invalidAeonTargetValue('Null literals must be null or an AEON identifier reason', path, operationIndex);
    case 'nan':
      return value === null || value === 'NaN'
        ? { ok: true }
        : invalidAeonTargetValue('NaN literals must use null or "NaN" as the payload', path, operationIndex);
    case 'infinity':
      return ['Infinity', '+Infinity', '-Infinity'].includes(value)
        ? { ok: true }
        : invalidAeonTargetValue('Infinity literals must use "Infinity", "+Infinity", or "-Infinity"', path, operationIndex);
    case 'date':
    case 'time':
    case 'datetime':
    case 'wtc':
      return typeof value === 'string' && isQueryTemporalLiteral(value, representation)
        ? { ok: true }
        : invalidAeonTargetValue(`${representation} literals must use valid AEON temporal text`, path, operationIndex);
    case 'cloneReference':
    case 'pointerReference':
    case 'referenceForm':
      return typeof value === 'string' && isValidAeonReferenceTargetPath(value)
        ? { ok: true }
        : invalidAeonTargetValue('Reference literals must use an exact AEON target path', path, operationIndex);
    default:
      return { ok: true };
  }
}

function validateAeonDatatypeKindCompatibility({ datatype, kind } = {}, path, operationIndex) {
  if (datatype === undefined || kind === undefined) return { ok: true };
  const datatypeRepresentation = representationKindFromMutationName(datatype, { allowUnknown: false });
  const literalRepresentation = representationKindFromMutationName(kind, { allowUnknown: false });
  if (datatypeRepresentation === undefined || literalRepresentation === undefined) return { ok: true };
  if (['cloneReference', 'pointerReference', 'referenceForm'].includes(literalRepresentation)) return { ok: true };
  if (datatypeRepresentation === literalRepresentation) return { ok: true };
  return invalidAeonTargetValue(
    `Datatype '${datatype}' is not compatible with ${literalRepresentation} literal representation`,
    path,
    operationIndex,
    { datatype },
  );
}

function invalidAeonTargetValue(message, path, operationIndex, details = {}) {
  return {
    ok: false,
    error: mutationTargetSurfaceError(
      'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
      `Target 'aeon' cannot represent mutation value: ${message} at ${path}`,
      { operationIndex, targetFormat: 'aeon', valuePath: path, ...details },
    ),
  };
}

function aeonDatatypeAllowsGeneric(base) {
  return ['object', 'obj', 'o', 'envelope', 'list', 'tuple', 'node', 'null', 'nan', 'infinity'].includes(base);
}

function aeonDatatypeAllowsArgument(base) {
  const lowered = typeof base === 'string' ? base.toLowerCase() : base;
  return ['sep', 'separator', 'kadot', 'radix'].includes(lowered);
}

function validateAeonReservedDatatypeSurface(datatype, base, operationIndex) {
  const source = String(datatype).trim();
  const lowered = source.toLowerCase();
  const loweredBase = typeof base === 'string' ? base.toLowerCase() : base;
  if (/^radix\d+$/.test(lowered) && !['radix2', 'radix6', 'radix8', 'radix12'].includes(lowered)) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'aeon' does not define reserved radix alias '${source}'`,
        { operationIndex, targetFormat: 'aeon', datatype },
      ),
    };
  }
  if (loweredBase === 'radix' && source.includes('[')) {
    const match = /^radix\[\s*([1-9]\d*)\s*\]$/i.exec(source);
    const baseNumber = match ? Number(match[1]) : NaN;
    if (!match || baseNumber < 2 || baseNumber > 64) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
          `Target 'aeon' requires radix bracket metadata to be an integer from 2 to 64`,
          { operationIndex, targetFormat: 'aeon', datatype },
        ),
      };
    }
  }
  return validateAeonSeparatorDatatypeSurface(datatype, base, operationIndex);
}

function validateAeonSeparatorDatatypeSurface(datatype, base, operationIndex) {
  const source = String(datatype).trim();
  const loweredBase = typeof base === 'string' ? base.toLowerCase() : base;
  if (!['sep', 'separator', 'kadot'].includes(loweredBase)) return { ok: true };
  if (!source.includes('[')) return { ok: true };
  if (loweredBase === 'kadot') {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'aeon' does not allow separator metadata on datatype '${source}'`,
        { operationIndex, targetFormat: 'aeon', datatype },
      ),
    };
  }
  if (!/^(?:sep|separator)\[\s*"[A-Za-z0-9!#$%&*+\-.:;=?@^_|~<>]"\s*(?:,\s*"[A-Za-z0-9!#$%&*+\-.:;=?@^_|~<>]"\s*)*\]$/i.test(source)) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'aeon' requires separator metadata to use one allowed separator character per bracket`,
        { operationIndex, targetFormat: 'aeon', datatype },
      ),
    };
  }
  return { ok: true };
}

function parseAeonTargetDatatypeExpression(datatype, operationIndex) {
  const source = String(datatype).trim();
  try {
    const parser = new AddressParser(source);
    const expression = parser.parseQualifierExpression();
    if (!parser.atEnd() || expression.terms.length !== 1) {
      return invalidAeonTargetDatatype(
        `Target 'aeon' requires datatype intent to be one datatype expression`,
        operationIndex,
        datatype,
      );
    }
    return { ok: true, expression };
  } catch (error) {
    if (error instanceof SansaParseError) {
      return invalidAeonTargetDatatype(
        `Target 'aeon' cannot represent malformed datatype intent '${source}'`,
        operationIndex,
        datatype,
      );
    }
    throw error;
  }
}

function validateAeonNodeDatatypeSurface(expression, datatype, operationIndex) {
  const term = expression.terms[0];
  if (term.name !== 'node') return { ok: true };
  const parameterGroups = term.parameterGroups ?? (term.parameters.length > 0 ? [term.parameters] : []);
  for (const group of parameterGroups) {
    for (const argument of group) {
      const base = datatypeBaseName(renderQualifierTerm(argument));
      if (base !== 'node' && isReservedAeonDatatypeBase(base)) {
        return invalidAeonTargetDatatype(
          "Target 'aeon' allows binding-side node<T> claims only for node<node> or custom node profile claims",
          operationIndex,
          datatype,
        );
      }
    }
  }
  return { ok: true };
}

function invalidAeonTargetDatatype(message, operationIndex, datatype) {
  return {
    ok: false,
    error: mutationTargetSurfaceError(
      'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
      message,
      { operationIndex, targetFormat: 'aeon', datatype },
    ),
  };
}

function isReservedAeonDatatypeBase(base) {
  const name = typeof base === 'string' ? base : '';
  const lowered = name.toLowerCase();
  return [
    'string',
    'trimtick',
    'prose',
    'number',
    'n',
    'int',
    'uint',
    'float',
    'infinity',
    'nan',
    'boolean',
    'bool',
    'toggle',
    'hex',
    'radix',
    'encoding',
    'base64',
    'embed',
    'inline',
    'date',
    'time',
    'datetime',
    'wtc',
    'sep',
    'separator',
    'kadot',
    'symbol',
    'sansa',
    'object',
    'obj',
    'o',
    'envelope',
    'list',
    'tuple',
    'node',
    'null',
  ].includes(lowered) || /^(?:u?int|float)\d+$/.test(lowered) || /^radix\d+$/.test(lowered);
}

function isValidSansaAddressValue(value) {
  const result = parseAddress(value);
  return result.ok;
}

function isValidAeonReferenceTargetPath(value) {
  const source = normalizeAeonReferenceTargetSource(value);
  if (source === null) return false;
  const result = parseAddress(source);
  if (!result.ok) return false;
  const address = result.address;
  return address.root.kind === 'absolute'
    && address.qualifierExpression === null
    && address.isExact
    && address.selectors.every((selector) => selector.type !== 'localSpace');
}

function normalizeAeonReferenceTargetSource(value) {
  const source = String(value);
  if (source.length === 0 || source.trim() !== source || /\s/.test(source)) return null;
  if (source.startsWith('$')) return source;
  if (source.startsWith('?') || source.startsWith('.')) return null;
  if (source.startsWith('[')) {
    return source[1] === '"' ? `$.${source}` : null;
  }
  if (source.startsWith('"')) {
    const end = quotedPrefixEnd(source);
    if (end === null) return null;
    const rest = source.slice(end);
    if (rest.length > 0 && rest[0] !== '.' && rest[0] !== '[') return null;
    return `$.["${source.slice(1, end - 1)}"]${rest}`;
  }
  if (!isIdentifierStart(source[0])) return null;
  return `$.${source}`;
}

function quotedPrefixEnd(source) {
  for (let index = 1; index < source.length; index += 1) {
    const char = source[index];
    if (char === '\\') {
      index += 1;
      continue;
    }
    if (char === '"') return index + 1;
    if (char === '\n' || char === '\r') return null;
  }
  return null;
}

function validateJsonTargetAddresses(operation, operationIndex) {
  for (const role of ['target', 'parent', 'source', 'container']) {
    const target = operation[role];
    if (!target) continue;
    // A quoted member can contain literal .@ text. Classify selectors in both
    // paths so contextual aliases still reveal canonical attribute ancestors.
    // Do not reimpose the portable index ceiling on an already planned path.
    const canonical = parseAddress(String(target.canonicalAddress ?? ''), { maxPositionIndex: Number.MAX_SAFE_INTEGER });
    const hasAttributeSelector = target.address?.selectors?.some((selector) => selector.type === 'attributeSpace')
      || (canonical.ok && canonical.address.selectors.some((selector) => selector.type === 'attributeSpace'));
    if (target.binding?.representationKind === 'attributeSpace' || hasAttributeSelector) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
          `Target 'json' cannot represent AEON attribute-space mutations at ${target.canonicalAddress}`,
          { operationIndex, targetFormat: 'json' },
        ),
      };
    }
  }
  return { ok: true };
}

function validateJsonTargetContainers(operation, operationIndex) {
  for (const role of ['target', 'parent', 'source', 'container']) {
    const target = operation[role];
    const representation = target?.binding?.representationKind;
    if (representation === 'node' || representation === 'tuple') {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_FEATURE',
          `Target 'json' cannot represent ${representation} container mutations at ${target.canonicalAddress}`,
          { operationIndex, targetFormat: 'json' },
        ),
      };
    }
  }
  return { ok: true };
}

function validateJsonTargetDatatype(datatype, operationIndex, label = 'datatype') {
  const text = String(datatype);
  const base = datatypeBaseName(text);
  if (text.includes('<') || text.includes('[')) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'json' does not support parameterized ${label} '${text}'`,
        { operationIndex, targetFormat: 'json', datatype: text },
      ),
    };
  }
  if (!['object', 'list', 'array', 'string', 'number', 'boolean', 'bool', 'null'].includes(base)) {
    return {
      ok: false,
      error: mutationTargetSurfaceError(
        'SANSA_MUTATE_TARGET_UNSUPPORTED_DATATYPE',
        `Target 'json' does not support ${label} '${text}'`,
        { operationIndex, targetFormat: 'json', datatype: text },
      ),
    };
  }
  return { ok: true };
}

function validateJsonTargetValue(value, operationIndex, path) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return { ok: true };
  if (typeof value === 'number') {
    return Number.isFinite(value)
      ? { ok: true }
      : {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
          `Target 'json' cannot represent non-finite numbers at ${path}`,
          { operationIndex, targetFormat: 'json', valuePath: path },
        ),
      };
  }
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index += 1) {
      const result = validateJsonTargetValue(value[index], operationIndex, `${path}[${index}]`);
      if (!result.ok) return result;
    }
    return { ok: true };
  }
  if (value && typeof value === 'object') {
    if (value.type === 'CloneReference' || value.type === 'PointerReference' || typeof value.canonical === 'string') {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
          `Target 'json' cannot represent AEON reference forms at ${path}`,
          { operationIndex, targetFormat: 'json', valuePath: path },
        ),
      };
    }
    if (value.tag !== undefined || value.children !== undefined || value.attributes !== undefined) {
      return {
        ok: false,
        error: mutationTargetSurfaceError(
          'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
          `Target 'json' cannot represent AEON node values at ${path}`,
          { operationIndex, targetFormat: 'json', valuePath: path },
        ),
      };
    }
    for (const [key, entry] of Object.entries(value)) {
      const result = validateJsonTargetValue(entry, operationIndex, `${path}${renderMutationValuePathSegment(key)}`);
      if (!result.ok) return result;
    }
    return { ok: true };
  }
  return {
    ok: false,
    error: mutationTargetSurfaceError(
      'SANSA_MUTATE_TARGET_UNSUPPORTED_VALUE',
      `Target 'json' cannot represent ${typeof value} values at ${path}`,
      { operationIndex, targetFormat: 'json', valuePath: path },
    ),
  };
}

function operationHasValue(operation) {
  return operation.op === 'create' || operation.op === 'replace' || operation.op === 'insert';
}

function representationKindFromMutationHints({ datatype, kind } = {}) {
  return kind === undefined
    ? representationKindFromMutationName(datatype, { allowUnknown: false })
    : representationKindFromMutationName(kind, { allowUnknown: true });
}

function nestedInstructionLiteralKindFlattens(kind) {
  return !['string', 'number', 'boolean', 'object', 'list'].includes(kind);
}

function representationKindFromMutationName(name, { allowUnknown = false } = {}) {
  if (typeof name !== 'string') return undefined;
  const base = datatypeBaseName(name);
  const lowered = typeof base === 'string' ? base.toLowerCase() : base;
  if (['object', 'obj', 'o', 'envelope'].includes(base)) return 'object';
  if (base === 'list') return 'list';
  if (base === 'tuple') return 'tuple';
  if (base === 'node') return 'node';
  if (['string', 'trimtick', 'prose'].includes(base)) return 'string';
  if (['number', 'int', 'uint', 'float', 'n'].includes(base)) return 'number';
  if (base === 'bool' || base === 'boolean') return 'boolean';
  if (base === 'toggle') return 'toggle';
  if (base === 'hex') return 'hex';
  if (lowered === 'radix' || /^radix\d+$/.test(lowered)) return 'radix';
  if (base === 'nan') return 'nan';
  if (base === 'infinity') return 'infinity';
  if (base === 'null') return 'null';
  if (base === 'sep' || base === 'separator' || base === 'kadot') return 'separator';
  if (base === 'symbol' || lowered === 'symbolicliteral') return 'symbol';
  if (base === 'sansa') return 'sansa';
  if (base === 'encoding' || ['base64', 'embed', 'inline'].includes(base)) return 'encoding';
  if (['date', 'time', 'datetime', 'wtc'].includes(base)) return base;
  if (['cloneReference', 'pointerReference', 'referenceForm'].includes(base)) return base;
  return allowUnknown ? base : undefined;
}

function validAeonIdentifier(value) {
  return typeof value === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(value);
}

function mutationTargetSurfaceError(code, message, details = {}) {
  return { code, message, phase: 'target', ...details };
}

function targetSurfaceId(targetSurface) {
  if (typeof targetSurface === 'string') return targetSurface || 'aeon';
  if (targetSurface && typeof targetSurface === 'object' && typeof targetSurface.id === 'string') return targetSurface.id;
  return 'unknown';
}

function capitalize(value) {
  return value.slice(0, 1).toUpperCase() + value.slice(1);
}

function enforceQueryPolicy(query, options) {
  if (!isValidationQueryPolicy(options.policy)) return { ok: true };

  if (query.orderBy) return queryPolicyViolation('Validation query policy does not allow order by clauses');
  if (query.offset) return queryPolicyViolation('Validation query policy does not allow offset clauses');
  if (query.limit) return queryPolicyViolation('Validation query policy does not allow limit clauses');
  if (query.select.ast.type === 'projectionExpression') {
    return queryPolicyViolation('Validation query policy does not allow object projection expressions');
  }

  const expressions = [
    ...(query.from.source === 'expression' ? [query.from.ast] : []),
    ...(query.where ? [query.where.ast] : []),
    ...(query.orderBy ? query.orderBy.keys.map((key) => key.ast) : []),
    query.select.ast,
  ];
  const disallowedFunction = expressions
    .map((expression) => findExpression(expression, (entry) => entry.type === 'functionCallExpression'
      && TRANSFORM_EXTENSION_FUNCTIONS.has(entry.name)))
    .find(Boolean);
  if (disallowedFunction) {
    return queryPolicyViolation(
      `Validation query policy does not allow transform extension function '${disallowedFunction.name}'`,
      { extension: TRANSFORM_EXTENSION_FUNCTIONS.get(disallowedFunction.name) },
    );
  }

  return { ok: true };
}

function isValidationQueryPolicy(policy) {
  return policy === 'validation'
    || policy?.mode === 'validation'
    || policy?.validation === true;
}

function queryPolicyViolation(message, details = {}) {
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_POLICY_VIOLATION', message, details),
  };
}

function checkQueryBudget(options, budget, observed) {
  const limit = normalizeQueryBudgetLimit(options.budget?.[budget]);
  if (limit === undefined || observed <= limit) return { ok: true };
  return {
    ok: false,
    error: queryEvaluateError(
      'SANSA_QUERY_BUDGET_EXCEEDED',
      `Query budget '${budget}' exceeded: limit ${limit}, observed ${observed}`,
      { budget, limit, observed },
    ),
  };
}

function normalizeQueryBudgetLimit(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : undefined;
}

function findExpression(expression, predicate) {
  if (predicate(expression)) return expression;

  switch (expression.type) {
    case 'groupExpression':
      return findExpression(expression.expression, predicate);
    case 'unaryExpression':
      return findExpression(expression.argument, predicate);
    case 'binaryExpression':
      return findExpression(expression.left, predicate)
        ?? findExpression(expression.right, predicate);
    case 'functionCallExpression':
      for (const argument of expression.arguments) {
        const found = findExpression(argument, predicate);
        if (found) return found;
      }
      return null;
    case 'existenceExpression':
    case 'cardinalityExpression':
      return findExpression(expression.argument, predicate);
    case 'projectionExpression':
      for (const field of expression.fields) {
        const found = findExpression(field.expression, predicate);
        if (found) return found;
      }
      return null;
    default:
      return null;
  }
}

function resolveConsumerAddress(input, namespace, options = {}) {
  return resolveAddress(input, namespace, { ...options, [DENY_CHILD_IDENTITY]: true });
}

export function resolveAddress(input, namespace, options = {}) {
  let parsed = typeof input === 'string' ? parseAddress(input, options.parse) : { ok: true, address: input };
  if (!parsed.ok) return { ok: false, bindings: [], errors: parsed.errors };
  const hasIdentity = !(typeof input === 'string' && parsed.address.isExact)
    && Array.isArray(parsed.address?.selectors) && parsed.address.selectors.some(s => s?.type === 'childIdentity');
  if (hasIdentity && typeof input !== 'string') {
    try {
      if (input.type !== 'SansaAddress' || input.root?.type !== 'root' || !['absolute', 'contextual'].includes(input.root.kind)) throw new Error('invalid root');
      parsed = parseAddress(renderAddress(input), options.parse);
      if (!parsed.ok) throw new Error('invalid selectors');
    } catch {
      return { ok: false, bindings: [], errors: [resolveError('SANSA_RESOLVE_INVALID_ADDRESS', 'Invalid identity address AST')] };
    }
  }
  const maxIdentityInspections = options.maxIdentityInspections === undefined ? DEFAULT_IDENTITY_INSPECTIONS : options.maxIdentityInspections;
  if (!Number.isSafeInteger(maxIdentityInspections) || maxIdentityInspections < 0) {
    return { ok: false, bindings: [], errors: [resolveError('SANSA_RESOLVE_INVALID_IDENTITY_LIMIT', 'Identity inspection limit must be a non-negative safe integer')] };
  }

  const maxBindings = options.maxBindings;
  if (maxBindings !== undefined && (!Number.isSafeInteger(maxBindings) || maxBindings < 0)) {
    return {
      ok: false,
      bindings: [],
      errors: [resolveError('SANSA_RESOLVE_INVALID_BINDING_LIMIT', 'Resolve maxBindings must be a non-negative safe integer')],
    };
  }

  const rootResult = resolveRoot(parsed.address.root, namespace, options);
  if (!rootResult.ok) return { ok: false, bindings: [], errors: [rootResult.error] };
  if (hasIdentity) {
    const selectorIndex = parsed.address.selectors.findIndex(s => s.type === 'childIdentity');
    const identity = parsed.address.selectors[selectorIndex].identity;
    if (options[DENY_CHILD_IDENTITY] || typeof namespace.identity !== 'function') {
      const code = options[DENY_CHILD_IDENTITY] ? 'SANSA_RESOLVE_UNSUPPORTED_SELECTOR' : 'SANSA_RESOLVE_UNSUPPORTED_IDENTITY';
      return { ok: false, bindings: [], errors: [resolveError(code, 'Child identity selection is not supported by this consumer or namespace', selectorIndex, { identity })] };
    }
  }
  const identityBudget = hasIdentity
    ? (options[QUERY_IDENTITY_BUDGET] ?? { inspected: 0 })
    : undefined;

  if (maxBindings === 0 && parsed.address.selectors.length === 0) {
    return {
      ok: false,
      bindings: [],
      errors: [resolveBindingLimitError(maxBindings, 1)],
    };
  }

  let current = [rootResult.binding];
  for (let index = 0; index < parsed.address.selectors.length; index += 1) {
    const selector = parsed.address.selectors[index];
    const selected = applyResolveSelector(
      selector,
      current,
      namespace,
      index,
      {
        effectiveRoot: options.allowParentFromEffectiveRoot === true ? undefined : rootResult.binding,
        parentTraversal: options.parentTraversal,
        failOnParentFromEffectiveRoot: options.failOnParentFromEffectiveRoot === true,
        maxBindings,
        identityBudget,
        maxIdentityInspections,
        identityActivationGuard: options[IDENTITY_ACTIVATION_GUARD],
      },
    );
    if (!selected.ok) return { ok: false, bindings: [], errors: [selected.error] };
    current = selected.bindings;
    if (maxBindings !== undefined && current.length > maxBindings) {
      return {
        ok: false,
        bindings: [],
        errors: [resolveBindingLimitError(maxBindings, current.length, index)],
      };
    }
    if (current.length === 0) break;
  }

  if (parsed.address.isExact && current.length > 1) {
    return {
      ok: false,
      bindings: [],
      errors: [
        resolveError(
          'SANSA_RESOLVE_EXACT_MULTIPLICITY_VIOLATION',
          'Exact SANSA resolution produced more than one binding',
        ),
      ],
    };
  }

  return { ok: true, bindings: current, diagnostics: [] };
}

export function traverseGraph(starts, namespace, declarations, options = {}) {
  const invalid = validateGraphInput(starts, namespace, declarations, options);
  if (invalid) return { ok: false, bindings: [], paths: [], errors: [invalid] };

  const paths = [];
  const bindings = [];
  const bindingAddresses = new Set();
  let visitedEdges = 0;

  for (const start of starts) {
    const startAddress = graphBindingAddress(start, namespace);
    if (!startAddress) {
      return graphFailure('SANSA_GRAPH_START_ADDRESS_MISSING', 'Graph start binding has no canonical address');
    }
    for (const declaration of declarations) {
      if (!declaration.schemaVersions.includes(options.schemaVersion)) {
        return graphFailure('SANSA_GRAPH_SCHEMA_VERSION_UNSUPPORTED', `Relationship '${declaration.id}' does not apply to schema version '${options.schemaVersion}'`, {
          declarationId: declaration.id,
          startAddress,
        });
      }
      const sourceSemanticType = graphBindingSemanticType(start, namespace);
      if (!declaration.sourceSemanticTypes.includes(sourceSemanticType)) {
        return graphFailure('SANSA_GRAPH_SOURCE_TYPE_MISMATCH', `Relationship '${declaration.id}' does not admit source semantic type '${sourceSemanticType || '<unknown>'}'`, {
          declarationId: declaration.id,
          startAddress,
        });
      }
      const edges = resolveConsumerAddress(declaration.edgeAddress, namespace, {
        contextualRoot: start,
        maxBindings: options.budget.maxVisitedEdges,
      });
      if (!edges.ok) return { ok: false, bindings: [], paths: [], errors: edges.errors };
      if (edges.bindings.length === 0 && declaration.missingEdge === 'error') {
        return graphFailure('SANSA_GRAPH_EDGE_MISSING', `Relationship '${declaration.id}' has no edge at '${declaration.edgeAddress}'`, {
          declarationId: declaration.id,
          startAddress,
        });
      }
      if (!graphCardinalityMatches(declaration.edgeCardinality, edges.bindings.length)) {
        return graphFailure('SANSA_GRAPH_EDGE_CARDINALITY_MISMATCH', `Relationship '${declaration.id}' edge cardinality '${declaration.edgeCardinality}' rejected ${edges.bindings.length} resolved edges`, {
          declarationId: declaration.id,
          startAddress,
          observed: edges.bindings.length,
        });
      }
      for (const edge of edges.bindings) {
        visitedEdges += 1;
        if (visitedEdges > options.budget.maxVisitedEdges) {
          return graphBudgetFailure('maxVisitedEdges', options.budget.maxVisitedEdges, visitedEdges);
        }
        const edgeAddress = graphBindingAddress(edge, namespace);
        if (!edgeAddress) {
          return graphFailure('SANSA_GRAPH_EDGE_ADDRESS_MISSING', 'Graph relationship edge has no canonical address', {
            declarationId: declaration.id,
            startAddress,
          });
        }
        const targetAddress = graphReferenceTarget(graphBindingValue(edge, namespace));
        if (!targetAddress) {
          return graphFailure('SANSA_GRAPH_INVALID_REFERENCE_TARGET', `Relationship edge '${edgeAddress}' does not contain an absolute SANSA address reference`, {
            declarationId: declaration.id,
            startAddress,
            edgeAddress,
          });
        }
        const target = resolveConsumerAddress(targetAddress, namespace, { maxBindings: 2 });
        if (!target.ok) return { ok: false, bindings: [], paths: [], errors: target.errors };
        if (target.bindings.length === 0) {
          if (declaration.danglingTarget === 'error') {
            return graphFailure('SANSA_GRAPH_DANGLING_TARGET', `Relationship edge '${edgeAddress}' targets missing binding '${targetAddress}'`, {
              declarationId: declaration.id,
              startAddress,
              edgeAddress,
              targetAddress,
            });
          }
          continue;
        }
        const end = target.bindings[0];
        const endAddress = graphBindingAddress(end, namespace);
        if (!endAddress) {
          return graphFailure('SANSA_GRAPH_END_ADDRESS_MISSING', 'Graph relationship target has no canonical address', {
            declarationId: declaration.id,
            startAddress,
            edgeAddress,
            targetAddress,
          });
        }
        const targetSemanticType = graphBindingSemanticType(end, namespace);
        if (!declaration.targetSemanticTypes.includes(targetSemanticType)) {
          return graphFailure('SANSA_GRAPH_TARGET_TYPE_MISMATCH', `Relationship '${declaration.id}' does not admit target semantic type '${targetSemanticType || '<unknown>'}'`, {
            declarationId: declaration.id,
            startAddress,
            edgeAddress,
            targetAddress,
          });
        }
        if (options.authorizeStep && options.authorizeStep({ start, edge, end, declaration }) !== true) {
          return graphFailure('SANSA_GRAPH_STEP_UNAUTHORIZED', `Traversal step through relationship '${declaration.id}' was not authorized`, {
            declarationId: declaration.id,
            startAddress,
            edgeAddress,
            targetAddress,
          });
        }
        paths.push({
          declarationId: declaration.id,
          start,
          startAddress,
          edge,
          edgeAddress,
          end,
          endAddress,
        });
        if (paths.length > options.budget.maxResults) {
          return graphBudgetFailure('maxResults', options.budget.maxResults, paths.length);
        }
        if (!bindingAddresses.has(endAddress)) {
          bindingAddresses.add(endAddress);
          bindings.push(end);
          if (bindings.length > options.budget.maxVisitedNodes) {
            return graphBudgetFailure('maxVisitedNodes', options.budget.maxVisitedNodes, bindings.length);
          }
        }
      }
    }
  }

  return {
    ok: true,
    bindings,
    paths,
    metrics: { visitedNodes: bindings.length, visitedEdges },
    diagnostics: [],
  };
}

export function traverseGraphSequence(starts, namespace, hops, options = {}) {
  if (!Array.isArray(hops) || hops.length === 0 || !['omit', 'error'].includes(options.cyclePolicy)) {
    return graphFailure('SANSA_GRAPH_INVALID_INPUT', 'Graph sequence traversal requires one or more declaration hops and an explicit cycle policy');
  }
  if (!options.budget || !Number.isSafeInteger(options.budget.maxDepth) || options.budget.maxDepth < hops.length) {
    return graphBudgetFailure('maxDepth', options.budget?.maxDepth, hops.length);
  }
  if (!Array.isArray(starts) || starts.length > options.budget.maxStartBindings) {
    return graphBudgetFailure('maxStartBindings', options.budget.maxStartBindings, Array.isArray(starts) ? starts.length : undefined);
  }
  for (const declarations of hops) {
    const invalid = validateGraphInput(starts, namespace, declarations, options);
    if (invalid) return { ok: false, bindings: [], paths: [], errors: [invalid] };
  }

  let frontier = [];
  for (const start of starts) {
    const startAddress = graphBindingAddress(start, namespace);
    if (!startAddress) return graphFailure('SANSA_GRAPH_START_ADDRESS_MISSING', 'Graph start binding has no canonical address');
    frontier.push({ start, startAddress, current: start, steps: [], seen: new Set([startAddress]) });
  }

  const visitedNodeAddresses = new Set();
  let visitedEdges = 0;
  for (const declarations of hops) {
    const next = [];
    for (const path of frontier) {
      const traversed = traverseGraph([path.current], namespace, declarations, options);
      if (!traversed.ok) return traversed;
      visitedEdges += traversed.metrics.visitedEdges;
      if (visitedEdges > options.budget.maxVisitedEdges) {
        return graphBudgetFailure('maxVisitedEdges', options.budget.maxVisitedEdges, visitedEdges);
      }
      for (const step of traversed.paths) {
        if (path.seen.has(step.endAddress)) {
          if (options.cyclePolicy === 'error') {
            return graphFailure('SANSA_GRAPH_CYCLE_DETECTED', `Graph sequence revisited binding '${step.endAddress}'`, {
              declarationId: step.declarationId,
              startAddress: path.startAddress,
              edgeAddress: step.edgeAddress,
              targetAddress: step.endAddress,
            });
          }
          continue;
        }
        visitedNodeAddresses.add(step.endAddress);
        if (visitedNodeAddresses.size > options.budget.maxVisitedNodes) {
          return graphBudgetFailure('maxVisitedNodes', options.budget.maxVisitedNodes, visitedNodeAddresses.size);
        }
        next.push({
          ...path,
          current: step.end,
          steps: [...path.steps, step],
          seen: new Set([...path.seen, step.endAddress]),
        });
        if (next.length > options.budget.maxResults) {
          return graphBudgetFailure('maxResults', options.budget.maxResults, next.length);
        }
      }
    }
    frontier = next;
    if (frontier.length === 0) break;
  }

  const bindings = [];
  const finalAddresses = new Set();
  const paths = frontier.map((path) => {
    const endAddress = graphBindingAddress(path.current, namespace);
    if (!finalAddresses.has(endAddress)) {
      finalAddresses.add(endAddress);
      bindings.push(path.current);
    }
    return {
      start: path.start,
      startAddress: path.startAddress,
      end: path.current,
      endAddress,
      steps: path.steps,
    };
  });
  return {
    ok: true,
    bindings,
    paths,
    metrics: { visitedNodes: visitedNodeAddresses.size, visitedEdges },
    diagnostics: [],
  };
}

function validateGraphInput(starts, namespace, declarations, options) {
  if (!Array.isArray(starts) || !namespace || typeof namespace !== 'object' || !Array.isArray(declarations)) {
    return graphError('SANSA_GRAPH_INVALID_INPUT', 'Graph traversal requires start bindings, a namespace, and relationship declarations');
  }
  if (!options.budget || typeof options.budget !== 'object') {
    return graphError('SANSA_GRAPH_BUDGET_REQUIRED', 'Graph traversal requires an explicit budget');
  }
  if (typeof options.schemaVersion !== 'string' || options.schemaVersion.length === 0) {
    return graphError('SANSA_GRAPH_INVALID_INPUT', 'Graph traversal requires an explicit schema version');
  }
  for (const field of ['maxDepth', 'maxStartBindings', 'maxVisitedNodes', 'maxVisitedEdges', 'maxResults']) {
    const value = options.budget[field];
    if (!Number.isSafeInteger(value) || value < 0) {
      return graphError('SANSA_GRAPH_INVALID_BUDGET', `Graph budget '${field}' must be a non-negative safe integer`, { budget: field });
    }
  }
  if (declarations.length > 0 && options.budget.maxDepth < 1) {
    return graphError('SANSA_GRAPH_BUDGET_EXCEEDED', 'Graph depth budget exceeded', {
      budget: 'maxDepth',
      limit: options.budget.maxDepth,
      observed: 1,
    });
  }
  if (starts.length > options.budget.maxStartBindings) {
    return graphError('SANSA_GRAPH_BUDGET_EXCEEDED', 'Graph start binding budget exceeded', {
      budget: 'maxStartBindings',
      limit: options.budget.maxStartBindings,
      observed: starts.length,
    });
  }
  const ids = new Set();
  for (const declaration of declarations) {
    if (!declaration || typeof declaration !== 'object'
      || typeof declaration.id !== 'string' || declaration.id.length === 0
      || declaration.direction !== 'directed'
      || !isNonEmptyUniqueStringArray(declaration.schemaVersions)
      || declaration.namespaceTransition !== 'same-namespace'
      || declaration.referenceForm !== 'absolute-address-reference'
      || !isNonEmptyUniqueStringArray(declaration.sourceSemanticTypes)
      || !isNonEmptyUniqueStringArray(declaration.targetSemanticTypes)
      || typeof declaration.edgeAddress !== 'string' || !declaration.edgeAddress.startsWith('?')
      || !['zero-or-one', 'exactly-one', 'zero-or-more', 'one-or-more'].includes(declaration.edgeCardinality)
      || (declaration.missingEdge !== 'omit' && declaration.missingEdge !== 'error')
      || (declaration.danglingTarget !== 'omit' && declaration.danglingTarget !== 'error')) {
      return graphError('SANSA_GRAPH_INVALID_DECLARATION', 'Graph relationship declaration is invalid');
    }
    if (ids.has(declaration.id)) {
      return graphError('SANSA_GRAPH_DUPLICATE_DECLARATION', `Graph relationship declaration '${declaration.id}' is duplicated`, {
        declarationId: declaration.id,
      });
    }
    ids.add(declaration.id);
  }
  return null;
}

function graphBindingAddress(binding, namespace) {
  if (typeof binding?.address === 'string') return binding.address;
  const handle = namespace.bindingHandle?.(binding);
  return typeof handle === 'string' ? handle : undefined;
}

function graphBindingValue(binding, namespace) {
  return namespace.value ? namespace.value(binding) : binding?.value;
}

function graphBindingSemanticType(binding, namespace) {
  const value = typeof namespace.semanticType === 'function'
    ? namespace.semanticType(binding)
    : binding?.semanticType ?? binding?.datatype;
  return typeof value === 'string' ? value : '';
}

function graphCardinalityMatches(cardinality, observed) {
  if (cardinality === 'zero-or-one') return observed <= 1;
  if (cardinality === 'exactly-one') return observed === 1;
  if (cardinality === 'one-or-more') return observed >= 1;
  return true;
}

function isNonEmptyUniqueStringArray(value) {
  return Array.isArray(value)
    && value.length > 0
    && value.every((item) => typeof item === 'string' && item.length > 0)
    && new Set(value).size === value.length;
}

function graphReferenceTarget(value) {
  if (typeof value === 'string' && value.startsWith('$')) return value;
  if (!value || typeof value !== 'object') return undefined;
  if ((value.type === 'PointerReference' || value.type === 'CloneReference') && typeof value.target === 'string' && value.target.startsWith('$')) {
    return value.target;
  }
  if (value.type === 'StringLiteral' && typeof value.value === 'string' && value.value.startsWith('$')) return value.value;
  return undefined;
}

function graphBudgetFailure(budget, limit, observed) {
  return graphFailure('SANSA_GRAPH_BUDGET_EXCEEDED', `Graph budget '${budget}' exceeded`, { budget, limit, observed });
}

function graphFailure(code, message, details = {}) {
  return { ok: false, bindings: [], paths: [], errors: [graphError(code, message, details)] };
}

function graphError(code, message, details = {}) {
  return { code, message, ...details };
}

export function renderAddress(address) {
  if (Array.isArray(address?.selectors) && address.selectors.some(s => s?.type === 'childIdentity')
      && !validIdentityAddressAst(address)) throw new Error('Invalid identity address AST');
  let output = address.root.kind === 'absolute' ? '$' : '?';

  for (const selector of address.selectors) {
    switch (selector.type) {
      case 'member':
        output += IDENTIFIER_RE.test(selector.name)
          ? `.${selector.name}`
          : `.[${quotePayload(selector.name)}]`;
        break;
      case 'position':
        output += `[${selector.index}]`;
        break;
      case 'positionRange':
        output += `[${selector.start ?? ''}..${selector.end ?? ''}]`;
        break;
      case 'parent':
        output += '.^';
        break;
      case 'attributeSpace':
        output += '.@';
        break;
      case 'localSpace':
        output += `.<${quotePayload(selector.name)}>`;
        break;
      case 'directExpansion':
        output += '.*';
        break;
      case 'descendantExpansion':
        output += '.**';
        break;
      case 'namePattern':
        output += `.(${quotePayload(selector.pattern)})`;
        break;
      case 'semanticTypeFilter':
        output += `#${selector.name}`;
        break;
      case 'representationKindFilter':
        output += `%${selector.name}`;
        break;
      default:
        output += renderExtendedSelector(selector);
    }
  }

  if (address.qualifierExpression) {
    output += `:${renderQualifierExpression(address.qualifierExpression)}`;
  }

  return output;
}

// Validate caller data before rendering can turn unquoted payloads into syntax.
// The ordinary parsed-address rendering path retains its existing contract.
function validIdentityAddressAst(address) {
  if (address.type !== 'SansaAddress' || address.root?.type !== 'root'
      || !['absolute', 'contextual'].includes(address.root.kind)) return false;
  const text = value => typeof value === 'string';
  const index = value => Number.isSafeInteger(value) && value >= 0;
  for (const s of address.selectors) {
    if (!s) return false;
    switch (s.type) {
      case 'childIdentity':
        if (!text(s.identity) || !CHILD_IDENTITY_RE.test(s.identity)) return false;
        break;
      case 'member': case 'localSpace':
        if (!text(s.name)) return false;
        break;
      case 'namePattern':
        if (!text(s.pattern)) return false;
        break;
      case 'semanticTypeFilter': case 'representationKindFilter':
        if (!text(s.name) || !IDENTIFIER_RE.test(s.name)) return false;
        break;
      case 'position':
        if (!index(s.index)) return false;
        break;
      case 'positionRange':
        if (![s.start, s.end].every(v => v == null || index(v))) return false;
        break;
      case 'parent': case 'attributeSpace': case 'directExpansion': case 'descendantExpansion': break;
      default: return false;
    }
  }
  if (!address.qualifierExpression) return true;
  const terms = address.qualifierExpression.terms;
  if (!Array.isArray(terms) || terms.length === 0) return false;
  const stack = terms.map(term => [term, false]);
  const ancestors = new Set();
  while (stack.length) {
    const [term, leaving] = stack.pop();
    if (leaving) { ancestors.delete(term); continue; }
    if (!term || ancestors.has(term) || !text(term.name) || !IDENTIFIER_RE.test(term.name)
        || !Array.isArray(term.arguments)) return false;
    ancestors.add(term);
    stack.push([term, true]);
    const groups = term.parameterGroups ?? (Array.isArray(term.parameters) && term.parameters.length ? [term.parameters] : []);
    if (!Array.isArray(groups)) return false;
    for (const group of groups) {
      if (!Array.isArray(group) || group.length === 0) return false;
      for (const child of group) stack.push([child, false]);
    }
    for (const arg of term.arguments) {
      if (!arg) return false;
      if (arg.kind === 'quoted') { if (!text(arg.value)) return false; }
      else if (arg.kind === 'number') {
        if (typeof arg.value !== 'number' || !Number.isFinite(arg.value)
            || !QUALIFIER_NUMBER_RE.test(String(arg.value))) return false;
      } else if (arg.kind === 'token') {
        if (!text(arg.value) || !QUALIFIER_NUMBER_RE.test(arg.value)) return false;
      } else return false;
    }
  }
  return true;
}

function renderExtendedSelector(selector) {
  if (selector.type !== 'childIdentity') throw new Error(`Unknown selector type: ${selector.type}`);
  if (typeof selector.identity !== 'string' || !CHILD_IDENTITY_RE.test(selector.identity)) throw new Error('Invalid child identity');
  return `.\\${selector.identity}\\`;
}

export function renderQuery(query) {
  const lines = [`from ${renderQueryFromClause(query.from)}`];
  if (query.where) lines.push(`where ${renderQueryExpression(query.where.ast)}`);
  if (query.orderBy) {
    lines.push(`order by ${query.orderBy.keys.map((key) => `${renderQueryExpression(key.ast)} ${key.direction}`).join(', ')}`);
  }
  if (query.offset) lines.push(`offset ${query.offset.value}`);
  if (query.limit) lines.push(`limit ${query.limit.value}`);
  lines.push(`select ${renderQueryExpression(query.select.ast)}`);
  return lines.join('\n');
}

function renderQueryFromClause(from) {
  return from.source === 'expression'
    ? renderQueryExpression(from.ast)
    : renderAddress(from.address);
}

export function renderQueryExpression(expression) {
  switch (expression.type) {
    case 'literalExpression':
      return expression.canonical ?? (expression.kind === 'string' ? quotePayload(expression.value) : String(expression.value));
    case 'currentBindingExpression':
      return '.';
    case 'resolutionExpression':
      return expression.canonical;
    case 'groupExpression':
      return `(${renderQueryExpression(expression.expression)})`;
    case 'unaryExpression':
      return `${expression.operator} ${renderQueryExpression(expression.argument)}`;
    case 'binaryExpression':
      return `${renderQueryExpression(expression.left)} ${expression.operator} ${renderQueryExpression(expression.right)}`;
    case 'functionCallExpression':
      return `${expression.name}(${expression.arguments.map((argument) => renderQueryExpression(argument)).join(', ')})`;
    case 'existenceExpression':
      return `${expression.operator}(${renderQueryExpression(expression.argument)})`;
    case 'cardinalityExpression':
      return `${expression.operator}(${renderQueryExpression(expression.argument)})`;
    case 'projectionExpression':
      return `{ ${expression.fields.map((field) => `${field.name} = ${renderQueryExpression(field.expression)}`).join(' ')} }`;
    default:
      throw new Error(`Unknown query expression type: ${expression.type}`);
  }
}

class SansaInstructionLowerError extends Error {
  constructor(diagnostic) {
    super(diagnostic.message);
    this.name = 'SansaInstructionLowerError';
    this.diagnostic = diagnostic;
  }
}

function normalizeLowerInstructionArgs(namespaceOrOptions, maybeOptions) {
  if (maybeOptions !== undefined) {
    return { namespace: namespaceOrOptions, options: maybeOptions ?? {} };
  }
  const options = namespaceOrOptions ?? {};
  if (isLikelyResolveNamespace(options)) {
    return { namespace: options, options: {} };
  }
  return { namespace: options.namespace, options };
}

function isLikelyResolveNamespace(value) {
  return value
    && typeof value === 'object'
    && (
      Object.hasOwn(value, 'root')
      || typeof value.children === 'function'
      || typeof value.parent === 'function'
      || Object.hasOwn(value, 'mutate')
    );
}

function lowerParsedInstruction(instruction, namespace, options = {}) {
  const requires = instruction.requires ?? [];
  if (instruction.from || instruction.where) {
    if (!namespace) {
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_LOWERING_REQUIRES_NAMESPACE',
        'Instruction lowering with from/where clauses requires a SANSA resolve namespace',
        { phase: 'lower' },
      ));
    }
    return lowerInstructionWithCandidates(instruction, namespace, options);
  }
  return {
    operations: [lowerInstructionMutationDirect(instruction.mutation)],
    preconditions: lowerInstructionRequiresDirect(requires),
  };
}

function lowerInstructionMutationDirect(mutation) {
  switch (mutation.verb) {
    case 'create': {
      const destination = lowerCreateDestinationDirect(mutation.destination);
      return withInstructionValueIntent({
        op: 'create',
        parent: destination.parent,
        name: destination.name,
      }, mutation.value);
    }
    case 'replace':
      return withInstructionValueIntent({
        op: 'replace',
        target: mutation.target.address.canonical,
      }, mutation.value);
    case 'remove':
      return {
        op: 'remove',
        target: mutation.target.address.canonical,
      };
    case 'insert':
      return withInstructionValueIntent({
        op: 'insert',
        container: mutation.container.address.canonical,
        placement: lowerInstructionPlacementDirect(mutation.placement),
      }, mutation.value);
    case 'move':
      return {
        op: 'move',
        source: mutation.source.address.canonical,
        container: mutation.container.address.canonical,
        placement: lowerInstructionPlacementDirect(mutation.placement),
      };
    default:
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_UNSUPPORTED_VERB',
        `Unsupported instruction verb '${mutation.verb}'`,
        { phase: 'lower' },
      ));
  }
}

function lowerInstructionWithCandidates(instruction, namespace, options) {
  const selected = selectInstructionCandidates(instruction, namespace, options);
  const operations = [];
  const preconditions = [];
  for (const candidate of selected) {
    operations.push(lowerInstructionMutationForCandidate(instruction.mutation, candidate, namespace, options));
    preconditions.push(...lowerInstructionRequiresForCandidate(instruction.requires ?? [], candidate));
  }
  return { operations, preconditions };
}

function selectInstructionCandidates(instruction, namespace, options) {
  const candidates = resolveInstructionFromCandidates(instruction, namespace, options);
  if (!instruction.where) return candidates;

  let valueSemanticsProfile;
  try {
    valueSemanticsProfile = getValueSemanticsProfile(options.valueSemantics);
  } catch (error) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_INVALID_VALUE_SEMANTICS_PROFILE',
      error instanceof Error ? error.message : 'Invalid value-semantics profile',
      { phase: 'lower' },
    ));
  }

  const evaluationOptions = {
    ...options,
    valueSemantics: valueSemanticsProfile,
  };
  const filtered = [];
  for (const candidate of candidates) {
    const candidateAddress = getBindingAddress(candidate);
    const evaluated = evaluateQueryExpressionValue(instruction.where.ast, candidate, namespace, evaluationOptions);
    if (!evaluated.ok) {
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_WHERE_EVALUATION_FAILED',
        evaluated.error.message,
        { phase: 'lower', candidateAddress, cause: evaluated.error },
      ));
    }
    const boolean = expectBooleanQueryValue(evaluated.value, namespace);
    if (!boolean.ok) {
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_WHERE_EVALUATION_FAILED',
        boolean.error.message,
        { phase: 'lower', candidateAddress, cause: boolean.error },
      ));
    }
    if (boolean.value) filtered.push(candidate);
  }
  return filtered;
}

function resolveInstructionFromCandidates(instruction, namespace, options) {
  if (!instruction.from) {
    const binding = options.contextualRoot ?? namespace.contextualRoot;
    if (isBindingObject(binding)) return [binding];
    const root = resolveRoot({ kind: 'absolute' }, namespace, options.resolve ?? {});
    if (!root.ok) {
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_CANDIDATE_RESOLUTION_FAILED',
        root.error.message,
        { phase: 'lower', cause: root.error },
      ));
    }
    return [root.binding];
  }

  const resolved = resolveConsumerAddress(instruction.from.address, namespace, options.resolve);
  if (!resolved.ok) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_CANDIDATE_RESOLUTION_FAILED',
      resolved.errors[0].message,
      { phase: 'lower', cause: resolved.errors[0] },
    ));
  }
  return resolved.bindings;
}

function lowerInstructionMutationForCandidate(mutation, candidate, namespace, options) {
  switch (mutation.verb) {
    case 'create': {
      const destination = lowerCreateDestinationForCandidate(mutation.destination, candidate, namespace, options);
      return withInstructionValueIntent({
        op: 'create',
        parent: destination.parent,
        name: destination.name,
      }, mutation.value);
    }
    case 'replace': {
      const target = resolveInstructionExactAddress(mutation.target, candidate, namespace, options, 'target');
      return withInstructionValueIntent({
        op: 'replace',
        target,
      }, mutation.value);
    }
    case 'remove': {
      const target = resolveInstructionExactAddress(mutation.target, candidate, namespace, options, 'target');
      return { op: 'remove', target };
    }
    case 'insert': {
      const container = resolveInstructionExactAddress(mutation.container, candidate, namespace, options, 'container');
      return withInstructionValueIntent({
        op: 'insert',
        container,
        placement: lowerInstructionPlacementForCandidate(mutation.placement, candidate, namespace, options),
      }, mutation.value);
    }
    case 'move': {
      const source = resolveInstructionExactAddress(mutation.source, candidate, namespace, options, 'source');
      const container = resolveInstructionExactAddress(mutation.container, candidate, namespace, options, 'container');
      return {
        op: 'move',
        source,
        container,
        placement: lowerInstructionPlacementForCandidate(mutation.placement, candidate, namespace, options),
      };
    }
    default:
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_UNSUPPORTED_VERB',
        `Unsupported instruction verb '${mutation.verb}'`,
        { phase: 'lower' },
      ));
  }
}

function lowerCreateDestinationForCandidate(destination, candidate, namespace, options) {
  if (destination.kind === 'member') {
    const parent = getBindingAddress(candidate);
    if (!parent) {
      throw new SansaInstructionLowerError(instructionLowerError(
        'SANSA_INSTRUCTION_CANDIDATE_ADDRESS_UNAVAILABLE',
        'Candidate binding does not expose a canonical address for create lowering',
        { phase: 'lower' },
      ));
    }
    return { parent, name: destination.name };
  }
  const split = splitCreateDestinationAddress(destination.address);
  const parent = resolveInstructionExactAddress(
    { type: 'instructionAddress', source: destination.canonical, address: split.parent, canonical: renderInstructionAddress(split.parent) },
    candidate,
    namespace,
    options,
    'parent',
  );
  return { parent, name: split.name };
}

function resolveInstructionExactAddress(instructionAddress, candidate, namespace, options, role) {
  const address = instructionAddress.address;
  if (!address.isExact) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_NON_EXACT_TARGET',
      `Instruction ${role} address must be exact before lowering`,
      { phase: 'lower', candidateAddress: getBindingAddress(candidate) },
    ));
  }

  const resolved = resolveConsumerAddress(address, namespace, {
    ...(options.resolve ?? {}),
    ...(address.root.kind === 'contextual' ? { contextualRoot: candidate, allowParentFromEffectiveRoot: true } : {}),
  });
  if (!resolved.ok) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_TARGET_RESOLUTION_FAILED',
      resolved.errors[0].message,
      { phase: 'lower', candidateAddress: getBindingAddress(candidate), cause: resolved.errors[0] },
    ));
  }
  if (resolved.bindings.length === 0) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_TARGET_MISS',
      `Instruction ${role} address resolved no bindings`,
      { phase: 'lower', candidateAddress: getBindingAddress(candidate), role },
    ));
  }
  if (resolved.bindings.length > 1) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_TARGET_MULTIPLICITY',
      `Instruction ${role} address resolved multiple bindings`,
      { phase: 'lower', candidateAddress: getBindingAddress(candidate), role },
    ));
  }
  const canonical = getBindingAddress(resolved.bindings[0]);
  if (!canonical) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_TARGET_ADDRESS_UNAVAILABLE',
      `Resolved instruction ${role} binding does not expose a canonical address`,
      { phase: 'lower', candidateAddress: getBindingAddress(candidate), role },
    ));
  }
  return canonical;
}

function lowerCreateDestinationDirect(destination) {
  if (destination.kind === 'member') {
    return { parent: '?', name: destination.name };
  }
  const split = splitCreateDestinationAddress(destination.address);
  return { parent: renderAddress(split.parent), name: split.name };
}

function splitCreateDestinationAddress(address) {
  const finalSelector = address.selectors[address.selectors.length - 1];
  if (!finalSelector || finalSelector.type !== 'member') {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_CREATE_DESTINATION_NOT_MEMBER',
      'Create destination must be a member name or an address ending in a member selector',
      { phase: 'lower' },
    ));
  }
  const parent = {
    type: 'SansaAddress',
    root: address.root,
    selectors: address.selectors.slice(0, -1),
    qualifierExpression: null,
    isExact: address.selectors.slice(0, -1).every(isExactSelector),
  };
  parent.canonical = renderAddress(parent);
  return { parent, name: finalSelector.name };
}

function lowerInstructionPlacementDirect(placement) {
  if (placement.kind === 'first' || placement.kind === 'last') return placement.kind;
  return {
    kind: placement.kind,
    anchor: placement.anchor.address.canonical,
  };
}

function lowerInstructionPlacementForCandidate(placement, candidate, namespace, options) {
  if (placement.kind === 'first' || placement.kind === 'last') return placement.kind;
  return {
    kind: placement.kind,
    anchor: resolveInstructionExactAddress(placement.anchor, candidate, namespace, options, 'anchor'),
  };
}

function lowerInstructionRequiresDirect(requires) {
  return requires.map((requirement) => ({
    expression: requirement.expression,
  }));
}

function lowerInstructionRequiresForCandidate(requires, candidate) {
  if (requires.length === 0) return [];
  const candidateAddress = getBindingAddress(candidate);
  if (!candidateAddress) {
    throw new SansaInstructionLowerError(instructionLowerError(
      'SANSA_INSTRUCTION_CANDIDATE_ADDRESS_UNAVAILABLE',
      'Candidate binding does not expose a canonical address for require lowering',
      { phase: 'lower' },
    ));
  }
  return requires.map((requirement) => ({
    expression: requirement.expression,
    target: candidateAddress,
  }));
}

function withInstructionValueIntent(operation, instructionValue) {
  return {
    ...operation,
    ...(instructionValue.datatype === undefined ? {} : { datatype: instructionValue.datatype }),
    ...(instructionValue.kind === undefined ? {} : { kind: instructionValue.kind }),
    value: instructionValue.value,
  };
}

function instructionLowerError(code, message, detail = {}) {
  return {
    code,
    message,
    ...detail,
  };
}

function resolveRoot(root, namespace, options) {
  if (!namespace || typeof namespace !== 'object') {
    return { ok: false, error: resolveError('SANSA_RESOLVE_EXPECTED_NAMESPACE', 'Expected SANSA resolve namespace') };
  }

  if (root.kind === 'contextual') {
    const binding = options.contextualRoot ?? namespace.contextualRoot;
    if (isBindingObject(binding)) return { ok: true, binding };
    return {
      ok: false,
      error: resolveError('SANSA_RESOLVE_UNSUPPORTED_CONTEXTUAL_ROOT', 'Contextual root requires a contextualRoot binding'),
    };
  }

  const rootBinding = typeof namespace.root === 'function' ? namespace.root() : namespace.root;
  if (rootBinding) return { ok: true, binding: rootBinding };
  return { ok: false, error: resolveError('SANSA_RESOLVE_MISSING_ROOT', 'SANSA resolve namespace does not expose a root binding') };
}

function isBindingObject(value) {
  return value !== null && typeof value === 'object';
}

function resolveQueryAddress(address, namespace, options, resolveOptions = options.resolve) {
  const budget = options[QUERY_IDENTITY_BUDGET];
  return budget === undefined
    ? resolveConsumerAddress(address, namespace, resolveOptions)
    : resolveAddress(address, namespace, { ...resolveOptions, [QUERY_IDENTITY_BUDGET]: budget });
}

function evaluateQueryFromClause(from, namespace, options) {
  if (from.source !== 'expression') {
    return resolveQueryAddress(from.address, namespace, options);
  }

  const rootResult = resolveRoot({ kind: 'absolute' }, namespace, options.resolve ?? {});
  if (!rootResult.ok) return { ok: false, bindings: [], errors: [rootResult.error] };

  const evaluated = evaluateQueryExpressionValue(from.ast, rootResult.binding, namespace, options);
  if (!evaluated.ok) return { ok: false, bindings: [], errors: [evaluated.error] };
  if (evaluated.value.type !== 'bindingSet') {
    return {
      ok: false,
      bindings: [],
      errors: [
        queryEvaluateError(
          'SANSA_QUERY_EVALUATE_INVALID_FROM_SOURCE',
          "Dynamic 'from' source expression must evaluate to a Binding Set",
        ),
      ],
    };
  }
  return { ok: true, bindings: evaluated.value.bindings, diagnostics: [] };
}

function evaluateQueryExpressionValue(expression, currentBinding, namespace, options) {
  switch (expression.type) {
    case 'literalExpression':
      return {
        ok: true,
        value: scalarQueryValue(
          expression.kind === 'number' ? expression.canonical : expression.value,
          queryLiteralMetadata(expression),
        ).value,
      };
    case 'currentBindingExpression':
      return {
        ok: true,
        value: {
          type: 'bindingSet',
          bindings: [currentBinding],
        },
      };
    case 'resolutionExpression':
      return evaluateResolutionExpression(expression, currentBinding, namespace, options);
    case 'groupExpression':
      return evaluateQueryExpressionValue(expression.expression, currentBinding, namespace, options);
    case 'unaryExpression':
      return evaluateUnaryExpression(expression, currentBinding, namespace, options);
    case 'binaryExpression':
      return evaluateBinaryExpression(expression, currentBinding, namespace, options);
    case 'projectionExpression':
      return evaluateProjectionExpression(expression, currentBinding, namespace, options);
    case 'functionCallExpression':
      return evaluateFunctionCallExpression(expression, currentBinding, namespace, options);
    case 'existenceExpression':
      return evaluateExistenceExpression(expression, currentBinding, namespace, options);
    case 'cardinalityExpression':
      return evaluateCardinalityExpression(expression, currentBinding, namespace, options);
    default:
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_UNSUPPORTED_EXPRESSION', `Unsupported query expression type: ${expression.type}`),
      };
  }
}

function evaluateResolutionExpression(expression, currentBinding, namespace, options) {
  const resolveOptions = {
    ...(options.resolve ?? {}),
    ...(['current', 'contextual'].includes(expression.scope) ? { contextualRoot: currentBinding } : {}),
    ...(expression.scope === 'current' ? { allowParentFromEffectiveRoot: true } : {}),
  };
  const resolved = resolveQueryAddress(expression.address, namespace, options, resolveOptions);
  if (!resolved.ok) return { ok: false, error: resolved.errors[0] };
  return {
    ok: true,
    value: {
      type: 'bindingSet',
      bindings: resolved.bindings,
    },
  };
}

function evaluateUnaryExpression(expression, currentBinding, namespace, options) {
  const evaluated = evaluateQueryExpressionValue(expression.argument, currentBinding, namespace, options);
  if (!evaluated.ok) return evaluated;
  const boolean = expectBooleanQueryValue(evaluated.value, namespace);
  if (!boolean.ok) return boolean;
  return {
    ok: true,
    value: {
      type: 'scalar',
      value: !boolean.value,
    },
  };
}

function evaluateBinaryExpression(expression, currentBinding, namespace, options) {
  if (expression.operator === 'and' || expression.operator === 'or') {
    return evaluateBooleanBinaryExpression(expression, currentBinding, namespace, options);
  }

  const left = evaluateQueryExpressionValue(expression.left, currentBinding, namespace, options);
  if (!left.ok) return left;
  const right = evaluateQueryExpressionValue(expression.right, currentBinding, namespace, options);
  if (!right.ok) return right;

  if (expression.operator === 'in') {
    return evaluateMembershipExpression(left.value, right.value, namespace, options);
  }

  const nativeStructuralEquality = evaluateNativeStructuralEquality(
    expression.operator,
    left.value,
    right.value,
    namespace,
    options,
  );
  if (nativeStructuralEquality !== undefined) return nativeStructuralEquality;

  const leftScalar = expectComparableQueryValue(left.value, namespace);
  if (!leftScalar.ok) return leftScalar;
  const rightScalar = expectComparableQueryValue(right.value, namespace);
  if (!rightScalar.ok) return rightScalar;
  return compareQueryScalars(expression.operator, leftScalar, rightScalar, options);
}

function evaluateNativeStructuralEquality(operator, left, right, namespace, options) {
  if (!['==', '!='].includes(operator) || typeof namespace.structurallyEqual !== 'function') {
    return undefined;
  }
  if (left.type !== 'bindingSet' || right.type !== 'bindingSet') return undefined;
  if (left.bindings.length !== 1 || right.bindings.length !== 1) return undefined;

  const leftBinding = left.bindings[0];
  const rightBinding = right.bindings[0];
  const leftKind = explicitContainerKindFromBinding(namespace, leftBinding);
  const rightKind = explicitContainerKindFromBinding(namespace, rightBinding);
  if (leftKind === undefined || rightKind === undefined || leftKind !== rightKind) return undefined;

  const equal = namespace.structurallyEqual(leftBinding, rightBinding, {
    operator,
    valueSemantics: options.valueSemantics,
  });
  if (typeof equal !== 'boolean') return undefined;
  return {
    ok: true,
    value: {
      type: 'scalar',
      value: operator === '==' ? equal : !equal,
    },
  };
}

function evaluateMembershipExpression(leftValue, rightValue, namespace, options) {
  const leftScalar = expectScalarQueryValue(leftValue, namespace);
  if (!leftScalar.ok) return leftScalar;

  if (rightValue.type !== 'bindingSet') {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_COMPARISON', 'Membership right operand must evaluate to a Binding Set'),
    };
  }

  for (const binding of rightValue.bindings) {
    const rightScalar = getBindingScalarValue(namespace, binding);
    if (!rightScalar.ok) return rightScalar;
    const compared = compareQueryScalars('==', leftScalar, rightScalar, options);
    if (!compared.ok) return compared;
    if (compared.value.value) {
      return {
        ok: true,
        value: {
          type: 'scalar',
          value: true,
        },
      };
    }
  }

  return {
    ok: true,
    value: {
      type: 'scalar',
      value: false,
    },
  };
}

function evaluateBooleanBinaryExpression(expression, currentBinding, namespace, options) {
  const left = evaluateQueryExpressionValue(expression.left, currentBinding, namespace, options);
  if (!left.ok) return left;
  const leftBoolean = expectBooleanQueryValue(left.value, namespace);
  if (!leftBoolean.ok) return leftBoolean;

  if (expression.operator === 'and' && leftBoolean.value === false) {
    return { ok: true, value: { type: 'scalar', value: false } };
  }
  if (expression.operator === 'or' && leftBoolean.value === true) {
    return { ok: true, value: { type: 'scalar', value: true } };
  }

  const right = evaluateQueryExpressionValue(expression.right, currentBinding, namespace, options);
  if (!right.ok) return right;
  const rightBoolean = expectBooleanQueryValue(right.value, namespace);
  if (!rightBoolean.ok) return rightBoolean;
  return {
    ok: true,
    value: {
      type: 'scalar',
      value: expression.operator === 'and'
        ? leftBoolean.value && rightBoolean.value
        : leftBoolean.value || rightBoolean.value,
    },
  };
}

function evaluateProjectionExpression(expression, currentBinding, namespace, options) {
  const value = {};
  const fieldMetadata = {};
  for (const field of expression.fields) {
    const evaluated = evaluateQueryExpressionValue(field.expression, currentBinding, namespace, options);
    if (!evaluated.ok) return evaluated;
    const metadata = queryValueMetadata(evaluated.value, namespace);
    const unwrapped = unwrapQueryValue(evaluated.value, namespace);
    if (!unwrapped.ok) return unwrapped;
    value[field.name] = unwrapped.value;
    if (metadata) fieldMetadata[field.name] = metadata;
  }
  if (Object.keys(fieldMetadata).length > 0) {
    Object.defineProperty(value, QUERY_OBJECT_FIELD_METADATA_PROPERTY, {
      value: fieldMetadata,
      enumerable: false,
    });
  }
  return {
    ok: true,
    value: {
      type: 'object',
      value,
    },
  };
}

function evaluateFunctionCallExpression(expression, currentBinding, namespace, options) {
  if (isSpecialValuePredicateName(expression.name)) {
    return evaluateSpecialValuePredicate(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'path') {
    return evaluatePathExpression(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'fallback') {
    return evaluateFallbackExpression(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'resolveChild') {
    return evaluateResolveChildExpression(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'follow') {
    return evaluateFollowExpression(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'objectFrom') {
    const extension = expectEnabledExtension(expression.name, options);
    if (!extension.ok) return extension;
    return evaluateObjectFromExpression(expression, currentBinding, namespace, options);
  }
  if (expression.name === 'fieldsFrom') {
    const extension = expectEnabledExtension(expression.name, options);
    if (!extension.ok) return extension;
    return evaluateFieldsFromExpression(expression, currentBinding, namespace, options);
  }
  if (!isOrdinaryFunctionName(expression.name)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION', `Function '${expression.name}' is not supported by this evaluator slice`),
    };
  }

  const evaluatedArgs = [];
  for (const argument of expression.arguments) {
    const evaluated = evaluateQueryExpressionValue(argument, currentBinding, namespace, options);
    if (!evaluated.ok) return evaluated;
    const scalar = expectScalarQueryValue(evaluated.value, namespace);
    if (!scalar.ok) return scalar;
    evaluatedArgs.push(scalar);
  }

  return evaluateOrdinaryFunction(expression.name, evaluatedArgs, options);
}

function expectEnabledExtension(functionName, options) {
  const extensionId = TRANSFORM_EXTENSION_FUNCTIONS.get(functionName);
  if (!extensionId || isExtensionEnabled(extensionId, options)) return { ok: true };
  return {
    ok: false,
    error: queryEvaluateError(
      'SANSA_QUERY_EVALUATE_UNSUPPORTED_EXTENSION',
      `Function '${functionName}' requires disabled extension '${extensionId}'`,
      { extension: extensionId },
    ),
  };
}

function isExtensionEnabled(extensionId, options) {
  const enabledExtensions = options.enabledExtensions;
  if (Array.isArray(enabledExtensions)) return enabledExtensions.includes(extensionId);

  const extensions = options.extensions;
  if (!extensions || typeof extensions !== 'object') return true;
  if (extensions.transform === false) return false;
  if (extensions.transform === true) return true;
  if (extensionId === 'sansa.transform.objectFrom' && extensions.objectFrom === false) return false;
  if (extensionId === 'sansa.transform.fieldsFrom' && extensions.fieldsFrom === false) return false;
  return true;
}

function isOrdinaryFunctionName(name) {
  return ['contains', 'startsWith', 'endsWith', 'lower', 'upper', 'concat', 'radixScale', 'temporalRelation'].includes(name);
}

function evaluateOrdinaryFunction(name, evaluatedArgs, options = {}) {
  const profile = getValueSemanticsProfile(options.valueSemantics);
  switch (name) {
    case 'contains':
      return evaluateStringFunction(name, evaluatedArgs, 2, ([value, search]) => value.includes(search));
    case 'startsWith':
      return evaluateStringFunction(name, evaluatedArgs, 2, ([value, search]) => value.startsWith(search));
    case 'endsWith':
      return evaluateStringFunction(name, evaluatedArgs, 2, ([value, search]) => value.endsWith(search));
    case 'lower':
      return evaluateStringFunction(name, evaluatedArgs, 1, ([value]) => profile.lowerString(value));
    case 'upper':
      return evaluateStringFunction(name, evaluatedArgs, 1, ([value]) => profile.upperString(value));
    case 'concat':
      if (evaluatedArgs.length === 0) {
        return {
          ok: false,
          error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'concat' expects at least one argument"),
        };
      }
      return evaluateStringFunction(name, evaluatedArgs, evaluatedArgs.length, (args) => args.join(''));
    case 'radixScale':
      return evaluateRadixScaleFunction(evaluatedArgs);
    case 'temporalRelation':
      return evaluateTemporalRelationFunction(evaluatedArgs);
    default:
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION', `Function '${name}' is not supported by this evaluator slice`),
      };
  }
}

function evaluateTemporalRelationFunction(args) {
  if (args.length !== 2) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'temporalRelation' expects 2 arguments"),
    };
  }

  const claims = args.map((argument) => {
    const info = queryScalarToInfo(argument);
    const category = normalizeValueSemanticsCategory(info.category ?? info.kind);
    if (category !== 'temporal' || typeof info.value !== 'string') return null;
    return {
      payload: info.value,
      semanticType: temporalSemanticType(info),
    };
  });

  if (claims.some((claim) => claim === null)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'temporalRelation' expects temporal arguments"),
    };
  }

  return scalarQueryValue(compareTemporalClaims(claims[0], claims[1]), {
    kind: 'string',
    category: 'string',
  });
}

function evaluateRadixScaleFunction(args) {
  if (args.length !== 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'radixScale' expects 1 argument"),
    };
  }
  const info = queryScalarToInfo(args[0]);
  const category = normalizeValueSemanticsCategory(info.category ?? info.kind);
  if (category !== 'radix') {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'radixScale' expects a radix value"),
    };
  }
  const scale = radixScaleOf(info.value, info.radixBase);
  if (scale === null || info.radixScale !== undefined && info.radixScale !== scale) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'radixScale' received an invalid radix value"),
    };
  }
  return scalarQueryValue(scale, { kind: 'number', category: 'finiteNumber', numericLexeme: String(scale) });
}

function evaluatePathExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length !== 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'path' expects 1 argument"),
    };
  }

  const evaluated = evaluateQueryExpressionValue(expression.arguments[0], currentBinding, namespace, options);
  if (!evaluated.ok) return evaluated;
  const scalar = expectScalarQueryValue(evaluated.value, namespace);
  if (!scalar.ok) return scalar;
  if (scalar.metadata?.numericLexeme !== undefined) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'path' expects a string or SANSA address literal"),
    };
  }

  let activated = activateAddressLiteral(scalar.value, options.parse?.address);
  if (!activated.ok) return activated;
  if (!Array.isArray(activated.address?.selectors) || !['absolute', 'contextual'].includes(activated.address.root?.kind)) {
    return {ok: false, error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL', 'Invalid activated address AST')};
  }
  const hasIdentity = activated.address.selectors.some(s => s?.type === 'childIdentity');
  if (hasIdentity) {
    const address = normalizeActivationAst(activated.address, options.parse?.address, false);
    if (!address) return deniedAddressActivation('Cannot establish a bounded unqualified identity activation address');
    activated = {ok: true, address};
  }

  const activation = authorizeAddressActivation(
    activated.address,
    currentBinding,
    options.addressActivation,
    options.parse?.address,
    namespace,
  );
  if (!activation.ok) return activation;

  const identityRoots = activation.identityRoots;
  const guard = identityRoots === undefined ? undefined : binding => {
    const address = canonicalActivationPath(getBindingAddress(binding), options.parse?.address);
    return address && identityRoots.some(root => addressHasStructuralPrefix(address, root))
      ? undefined
      : deniedAddressActivation('Identity activation binding has no permitted canonical structural path').error;
  };
  const hostLimit = options.resolve?.maxBindings;
  const activationLimit = activation.maxBindings;
  if (hasIdentity && hostLimit !== undefined && (!Number.isSafeInteger(hostLimit) || hostLimit < 0)) {
    return {ok: false, error: resolveError('SANSA_RESOLVE_INVALID_BINDING_LIMIT', 'Resolve maxBindings must be a non-negative safe integer')};
  }
  const maxBindings = hasIdentity && hostLimit !== undefined && activationLimit !== undefined
    ? Math.min(hostLimit, activationLimit) : (activationLimit ?? hostLimit);
  const resolveOptions = {
    ...(options.resolve ?? {}),
    contextualRoot: currentBinding,
    ...(activation.allowParentFromEffectiveRoot ? {allowParentFromEffectiveRoot: true} : {}),
    ...(maxBindings === undefined ? {} : {maxBindings}),
    ...(guard ? {[IDENTITY_ACTIVATION_GUARD]: guard} : {}),
  };
  const resolved = guard
    ? resolveQueryAddress(activated.address, namespace, options, resolveOptions)
    : resolveConsumerAddress(activated.address, namespace, resolveOptions);
  if (!resolved.ok) {
    const error = resolved.errors[0];
    if (error.code === 'SANSA_RESOLVE_BINDING_LIMIT_EXCEEDED') {
      return {
        ok: false,
        error: queryEvaluateError(
          'SANSA_QUERY_PATH_ACTIVATION_BINDING_LIMIT_EXCEEDED',
          error.message,
          { limit: error.limit, observed: error.observed },
        ),
      };
    }
    return { ok: false, error };
  }
  if (guard) {
    for (const binding of resolved.bindings) {
      const error = guard(binding);
      if (error) return {ok: false, error};
    }
  }
  if (activation.maxBindings !== undefined && resolved.bindings.length > activation.maxBindings) {
    return {
      ok: false,
      error: queryEvaluateError(
        'SANSA_QUERY_PATH_ACTIVATION_BINDING_LIMIT_EXCEEDED',
        `Activated address produced ${resolved.bindings.length} bindings, exceeding limit ${activation.maxBindings}`,
        {
          limit: activation.maxBindings,
          observed: resolved.bindings.length,
        },
      ),
    };
  }
  return {
    ok: true,
    value: {
      type: 'bindingSet',
      bindings: resolved.bindings,
    },
  };
}

const ADDRESS_ACTIVATION_SELECTOR_FEATURE = new Map([
  ['childIdentity', 'childIdentity'],
  ['member', 'member'],
  ['position', 'position'],
  ['positionRange', 'range'],
  ['directExpansion', 'wildcard'],
  ['descendantExpansion', 'recursive'],
  ['namePattern', 'pattern'],
  ['semanticTypeFilter', 'semanticFilter'],
  ['representationKindFilter', 'representationFilter'],
  ['attributeSpace', 'attribute'],
  ['localSpace', 'local'],
  ['parent', 'parent'],
]);

function authorizeAddressActivation(address, currentBinding, policy, parseOptions, namespace) {
  if (policy === 'trusted' || policy?.mode === 'trusted') {
    return { ok: true };
  }
  if (policy === undefined || policy === null) {
    return {
      ok: false,
      error: queryEvaluateError(
        'SANSA_QUERY_PATH_ACTIVATION_POLICY_REQUIRED',
        "Function 'path' requires an explicit address-activation policy",
      ),
    };
  }
  if (!policy || typeof policy !== 'object' || Array.isArray(policy)) {
    return invalidAddressActivationPolicy('Address-activation policy must be a constrained policy object or trusted mode');
  }
  if (policy.mode !== undefined && policy.mode !== 'constrained') {
    return invalidAddressActivationPolicy(`Unknown address-activation mode '${policy.mode}'`);
  }
  if (policy.allowContextualRoot !== undefined && typeof policy.allowContextualRoot !== 'boolean') {
    return invalidAddressActivationPolicy("Address-activation 'allowContextualRoot' must be Boolean");
  }

  const maxAddressDepth = normalizeAddressActivationLimit(policy.maxAddressDepth);
  if (!maxAddressDepth.ok) return maxAddressDepth;
  const maxBindings = normalizeAddressActivationLimit(policy.maxBindings);
  if (!maxBindings.ok) return maxBindings;
  if (maxAddressDepth.value !== undefined && address.selectors.length > maxAddressDepth.value) {
    return deniedAddressActivation(
      `Activated address depth ${address.selectors.length} exceeds limit ${maxAddressDepth.value}`,
      { limit: maxAddressDepth.value, observed: address.selectors.length },
    );
  }

  const allowedFeatures = normalizeAddressActivationFeatures(policy.allowedSelectors);
  if (!allowedFeatures.ok) return allowedFeatures;
  for (const selector of address.selectors) {
    const feature = ADDRESS_ACTIVATION_SELECTOR_FEATURE.get(selector.type);
    if (!feature || !allowedFeatures.features.has(feature)) {
      return deniedAddressActivation(`Activated address selector '${feature ?? selector.type}' is not permitted`, {
        selector: feature ?? selector.type,
      });
    }
  }

  if (address.root.kind === 'contextual' && policy.allowContextualRoot !== true) {
    return deniedAddressActivation('Contextual-root address activation is not permitted');
  }

  if (address.selectors.some(s => s.type === 'childIdentity')) {
    if (address.selectors.some(s => s.type === 'parent') || address.qualifierExpression) {
      return deniedAddressActivation('Identity activation does not admit parent traversal or qualifiers');
    }
    const roots = normalizeAddressActivationRoots(policy.allowedRoots, parseOptions);
    if (!roots.ok) return roots;
    const binding = address.root.kind === 'contextual' ? currentBinding
      : (typeof namespace.root === 'function' ? namespace.root() : namespace.root);
    const base = canonicalActivationPath(getBindingAddress(binding), parseOptions);
    if (!base) return deniedAddressActivation('Identity activation requires a canonical structural scope root');
    const firstIdentity = address.selectors.findIndex(s => s.type === 'childIdentity');
    const prefix = {...base, selectors: [...base.selectors, ...address.selectors.slice(0, firstIdentity)]};
    if (!roots.roots.some(root => addressHasStructuralPrefix(prefix, root))) {
      return deniedAddressActivation('Identity scan parent is outside every permitted root');
    }
    return {ok: true, maxBindings: maxBindings.value, identityRoots: roots.roots};
  }

  const effective = effectiveActivatedAddress(address, currentBinding, parseOptions);
  if (!effective.ok) return effective;
  const normalized = normalizeActivatedAddressForScope(effective.address);
  if (!normalized.ok) return normalized;

  const roots = normalizeAddressActivationRoots(policy.allowedRoots, parseOptions);
  if (!roots.ok) return roots;
  if (!roots.roots.some((root) => addressHasStructuralPrefix(normalized.address, root))) {
    return deniedAddressActivation('Activated address is outside every permitted root', {
      address: normalized.address.canonical,
    });
  }

  return {
    ok: true,
    maxBindings: maxBindings.value,
    allowParentFromEffectiveRoot: allowedFeatures.features.has('parent'),
  };
}

function normalizeAddressActivationLimit(value) {
  if (value === undefined) return { ok: true, value: undefined };
  if (!Number.isSafeInteger(value) || value < 0) {
    return invalidAddressActivationPolicy('Address-activation limits must be non-negative safe integers');
  }
  return { ok: true, value };
}

function normalizeAddressActivationFeatures(input) {
  const values = input === undefined ? ['member', 'position'] : input;
  if (!Array.isArray(values) || values.some((value) => typeof value !== 'string')) {
    return invalidAddressActivationPolicy("Address-activation 'allowedSelectors' must be a string list");
  }
  const known = new Set(ADDRESS_ACTIVATION_SELECTOR_FEATURE.values());
  for (const feature of values) {
    if (!known.has(feature)) {
      return invalidAddressActivationPolicy(`Unknown address-activation selector capability '${feature}'`);
    }
  }
  return { ok: true, features: new Set(values) };
}

function normalizeAddressActivationRoots(input, parseOptions) {
  if (!Array.isArray(input) || input.length === 0) {
    return invalidAddressActivationPolicy("Constrained address activation requires at least one 'allowedRoots' entry");
  }
  const roots = [];
  for (const root of input) {
    const address = typeof root === 'string' ? canonicalActivationPath(root, parseOptions) : normalizeActivationAst(root, parseOptions, true);
    const parsed = {ok: address !== undefined, address};
    if (!parsed.ok || !parsed.address || parsed.address.type !== 'SansaAddress') {
      return invalidAddressActivationPolicy('Address-activation roots must be valid SANSA addresses');
    }
    if (parsed.address.root.kind !== 'absolute' || !parsed.address.isExact || parsed.address.qualifierExpression) {
      return invalidAddressActivationPolicy('Address-activation roots must be unqualified exact absolute addresses');
    }
    roots.push(parsed.address);
  }
  return { ok: true, roots };
}

// Bounded scalar-only AST projection before policy decisions. Caller flags carry no authority.
function normalizeActivationAst(input, parseOptions, exactOnly) {
  if (input?.type !== 'SansaAddress' || input.root?.type !== 'root'
      || !['absolute', 'contextual'].includes(input.root.kind) || input.qualifierExpression
      || !Array.isArray(input.selectors) || input.selectors.length > 1024) return undefined;
  let characters = 0;
  for (const s of input.selectors) {
    if (!s || exactOnly && !isExactSelector(s)) return undefined;
    const text = ['member', 'localSpace', 'semanticTypeFilter', 'representationKindFilter'].includes(s.type) ? s.name
      : s.type === 'childIdentity' ? s.identity : s.type === 'namePattern' ? s.pattern : undefined;
    if (text !== undefined) {
      if (typeof text !== 'string') return undefined;
      characters += text.length;
    } else if (['member', 'localSpace', 'semanticTypeFilter', 'representationKindFilter', 'childIdentity', 'namePattern'].includes(s.type)) return undefined;
    if (characters > 65536) return undefined;
    if (s.type === 'position' && (!Number.isSafeInteger(s.index) || s.index < 0)) return undefined;
    if (s.type === 'positionRange' && ![s.start, s.end].every(v => v == null || Number.isSafeInteger(v) && v >= 0)) return undefined;
  }
  try {
    const source = renderAddress(input);
    if (source.length > 65536) return undefined;
    const parsed = parseAddress(source, parseOptions);
    return parsed.ok && (!exactOnly || parsed.address.root.kind === 'absolute' && parsed.address.isExact)
      ? parsed.address : undefined;
  } catch { return undefined; }
}

function canonicalActivationPath(source, parseOptions) {
  if (typeof source !== 'string' || source.length > 65536) return undefined;
  const parsed = parseAddress(source, parseOptions);
  return parsed.ok && parsed.address.root.kind === 'absolute' && parsed.address.isExact
    && !parsed.address.qualifierExpression && parsed.address.selectors.length <= 1024
    ? parsed.address : undefined;
}

function effectiveActivatedAddress(address, currentBinding, parseOptions) {
  if (address.root.kind === 'absolute') return { ok: true, address };
  const currentAddress = getBindingAddress(currentBinding);
  if (typeof currentAddress !== 'string') {
    return deniedAddressActivation('Cannot establish contextual address scope because the current binding has no canonical address');
  }
  const parsedCurrent = parseAddress(currentAddress, parseOptions);
  if (!parsedCurrent.ok || !parsedCurrent.address.isExact || parsedCurrent.address.root.kind !== 'absolute') {
    return deniedAddressActivation('Cannot establish contextual address scope from the current binding address');
  }
  return {
    ok: true,
    address: {
      type: 'SansaAddress',
      root: parsedCurrent.address.root,
      selectors: [...parsedCurrent.address.selectors, ...address.selectors],
      qualifierExpression: address.qualifierExpression,
      isExact: address.isExact,
      canonical: `${parsedCurrent.address.canonical}${address.canonical.slice(1)}`,
    },
  };
}

function normalizeActivatedAddressForScope(address) {
  const selectors = [];
  for (const selector of address.selectors) {
    if (selector.type !== 'parent') {
      selectors.push(selector);
      continue;
    }
    const previous = selectors.at(-1);
    if (!previous || !isExactSelector(previous)) {
      return deniedAddressActivation('Activated parent traversal cannot be proven to remain within scope');
    }
    selectors.pop();
  }
  const normalized = {
    ...address,
    selectors,
    isExact: selectors.every(isExactSelector),
  };
  normalized.canonical = renderAddress(normalized);
  return { ok: true, address: normalized };
}

function addressHasStructuralPrefix(address, root) {
  if (address.root.kind !== root.root.kind || root.selectors.length > address.selectors.length) return false;
  return root.selectors.every((selector, index) => exactAddressSelectorEquals(selector, address.selectors[index]));
}

function exactAddressSelectorEquals(left, right) {
  if (!left || !right || left.type !== right.type) return false;
  if (left.type === 'member' || left.type === 'localSpace') return left.name === right.name;
  if (left.type === 'position') return left.index === right.index;
  return left.type === 'attributeSpace';
}

function invalidAddressActivationPolicy(message) {
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_PATH_ACTIVATION_INVALID_POLICY', message),
  };
}

function deniedAddressActivation(message, details = {}) {
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_PATH_ACTIVATION_DENIED', message, details),
  };
}

function activateAddressLiteral(value, parseOptions) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL', "Function 'path' expects a SANSA Address Literal value"),
    };
  }

  if (value.type === 'SansaAddress' && value.root && Array.isArray(value.selectors)) {
    return { ok: true, address: value };
  }

  if (value.type !== 'SansaAddressLiteral') {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL', "Function 'path' expects a SANSA Address Literal value"),
    };
  }

  if (value.address && typeof value.address === 'object') {
    return { ok: true, address: value.address };
  }

  const source = typeof value.canonical === 'string'
    ? value.canonical
    : typeof value.source === 'string'
      ? value.source
      : typeof value.address === 'string'
        ? value.address
        : null;
  if (source === null) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL', "Function 'path' expects a structured address literal"),
    };
  }

  const parsed = parseAddress(source, parseOptions);
  if (!parsed.ok) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_PATH_LITERAL', "Function 'path' received an invalid SANSA Address Literal", {
        cause: parsed.errors[0],
      }),
    };
  }
  return { ok: true, address: parsed.address };
}

function evaluateFallbackExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length !== 2) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'fallback' expects 2 arguments"),
    };
  }

  const primary = evaluateQueryExpressionValue(expression.arguments[0], currentBinding, namespace, options);
  if (!primary.ok) {
    if (primary.error.code === 'SANSA_QUERY_EVALUATE_MISSING_SCALAR') {
      return evaluateFallbackReplacement(expression.arguments[1], currentBinding, namespace, options);
    }
    return primary;
  }

  const primaryValue = consumeFallbackOperand(primary.value, namespace);
  if (primaryValue.ok) return primaryValue;
  if (primaryValue.missing) {
    return evaluateFallbackReplacement(expression.arguments[1], currentBinding, namespace, options);
  }
  return primaryValue;
}

function evaluateFallbackReplacement(expression, currentBinding, namespace, options) {
  const replacement = evaluateQueryExpressionValue(expression, currentBinding, namespace, options);
  if (!replacement.ok) return replacement;
  const replacementValue = consumeFallbackOperand(replacement.value, namespace);
  if (replacementValue.ok) return replacementValue;
  if (replacementValue.missing) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', "Function 'fallback' replacement resolved no scalar value"),
    };
  }
  return replacementValue;
}

function consumeFallbackOperand(value, namespace) {
  if (value.type !== 'bindingSet') {
    return { ok: true, value };
  }
  if (value.bindings.length === 0) {
    return { ok: false, missing: true };
  }
  if (value.bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', "Function 'fallback' expected one binding but resolved multiple bindings"),
    };
  }
  const scalar = getBindingScalarValue(namespace, value.bindings[0]);
  if (!scalar.ok && scalar.error.code === 'SANSA_QUERY_EVALUATE_MISSING_SCALAR') {
    return { ok: false, missing: true };
  }
  if (!scalar.ok) return scalar;
  return scalarQueryValue(scalar.value, scalar.metadata);
}

function evaluateResolveChildExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length !== 2) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'resolveChild' expects 2 arguments"),
    };
  }

  const baseResolution = unwrapResolutionExpression(expression.arguments[0]);
  if (!baseResolution) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'resolveChild' expects a resolution expression base"),
    };
  }

  const base = evaluateResolutionExpression(baseResolution, currentBinding, namespace, options);
  if (!base.ok) return base;
  if (base.value.bindings.length === 0) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', "Function 'resolveChild' expected one base binding but resolved none"),
    };
  }
  if (base.value.bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', "Function 'resolveChild' expected one base binding but resolved multiple bindings"),
    };
  }

  const key = evaluateQueryExpressionValue(expression.arguments[1], currentBinding, namespace, options);
  if (!key.ok) return key;
  const keyScalar = expectScalarQueryValue(key.value, namespace);
  if (!keyScalar.ok) return keyScalar;

  let bindings;
  const numericPosition = queryScalarPosition(keyScalar);
  if (numericPosition !== null) {
    bindings = selectPosition(namespace, base.value.bindings[0], numericPosition);
  } else if (isStringQueryScalar(keyScalar)) {
    bindings = selectMember(namespace, base.value.bindings[0], keyScalar.value);
  } else {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'resolveChild' expects a string member key or non-negative integer position key"),
    };
  }

  if (bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', "Function 'resolveChild' target resolved multiple bindings"),
    };
  }

  return {
    ok: true,
    value: {
      type: 'bindingSet',
      bindings,
    },
  };
}

function evaluateFollowExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length !== 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'follow' expects 1 argument"),
    };
  }

  const evaluated = evaluateQueryExpressionValue(expression.arguments[0], currentBinding, namespace, options);
  if (!evaluated.ok) return evaluated;
  const scalar = expectScalarQueryValue(evaluated.value, namespace);
  if (!scalar.ok) return scalar;
  if (!isReferenceFormValue(scalar.value, scalar.metadata)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'follow' expects an AEON reference form"),
    };
  }

  const target = referenceTargetAddress(scalar.value, options.parse?.address);
  if (!target.ok) return target;
  if (!target.address.isExact) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_REFERENCE_TARGET', "Function 'follow' requires an exact reference target path"),
    };
  }

  const resolved = resolveConsumerAddress(target.address, namespace, options.resolve);
  if (!resolved.ok) return { ok: false, error: resolved.errors[0] };
  if (resolved.bindings.length === 0) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_REFERENCE_TARGET', "Function 'follow' target resolved no binding"),
    };
  }

  return {
    ok: true,
    value: {
      type: 'bindingSet',
      bindings: resolved.bindings,
    },
  };
}

function isReferenceFormValue(value, metadata) {
  if (metadata?.kind === 'referenceForm' || metadata?.category === 'referenceForm') return true;
  return value?.type === 'CloneReference' || value?.type === 'PointerReference';
}

function referenceTargetAddress(value, parseOptions) {
  const source = referenceTargetAddressSource(value);
  if (source === null) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_REFERENCE_TARGET', "Function 'follow' received a reference without a target path"),
    };
  }
  const parsed = parseAddress(source, parseOptions);
  if (!parsed.ok) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_REFERENCE_TARGET', "Function 'follow' received an invalid reference target path", {
        cause: parsed.errors[0],
      }),
    };
  }
  return { ok: true, address: parsed.address };
}

function referenceTargetAddressSource(value) {
  const pathSource = referencePathSource(value);
  if (pathSource === null) return null;
  if (pathSource.startsWith('$')) return pathSource;
  if (pathSource.startsWith('?')) return null;
  if (pathSource.startsWith('.') || pathSource.startsWith('[')) return `$${pathSource}`;
  return `$.${pathSource}`;
}

function referencePathSource(value) {
  if (Array.isArray(value?.path)) return renderReferencePathSegments(value.path);
  if (typeof value?.path === 'string') return value.path;
  if (typeof value?.target === 'string') return value.target;
  if (typeof value?.canonical === 'string') {
    if (value.canonical.startsWith('~>')) return value.canonical.slice(2);
    if (value.canonical.startsWith('~')) return value.canonical.slice(1);
  }
  return null;
}

function renderReferencePathSegments(path) {
  return path.map((segment, index) => {
    if (typeof segment === 'number') return `[${segment}]`;
    if (typeof segment === 'string' && IDENTIFIER_RE.test(segment)) {
      return index === 0 ? segment : `.${segment}`;
    }
    return `${index === 0 ? '' : '.'}[${quotePayload(String(segment))}]`;
  }).join('');
}

function evaluateObjectFromExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length !== 2) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'objectFrom' expects 2 arguments"),
    };
  }

  const keyResolution = unwrapResolutionExpression(expression.arguments[0]);
  const valueResolution = unwrapResolutionExpression(expression.arguments[1]);
  if (!keyResolution || !valueResolution) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'objectFrom' expects resolution expression arguments"),
    };
  }

  const keys = evaluateResolutionExpression(keyResolution, currentBinding, namespace, options);
  if (!keys.ok) return keys;
  const values = evaluateResolutionExpression(valueResolution, currentBinding, namespace, options);
  if (!values.ok) return values;

  return objectFromBindingSets(keys.value.bindings, values.value.bindings, namespace, 'objectFrom');
}

function evaluateFieldsFromExpression(expression, currentBinding, namespace, options) {
  if (expression.arguments.length < 3) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'fieldsFrom' expects headers, values, and at least one field name"),
    };
  }

  const keyResolution = unwrapResolutionExpression(expression.arguments[0]);
  const valueResolution = unwrapResolutionExpression(expression.arguments[1]);
  if (!keyResolution || !valueResolution) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'fieldsFrom' expects resolution expression header and value arguments"),
    };
  }

  const requested = [];
  for (const argument of expression.arguments.slice(2)) {
    const evaluated = evaluateQueryExpressionValue(argument, currentBinding, namespace, options);
    if (!evaluated.ok) return evaluated;
    const scalar = expectScalarQueryValue(evaluated.value, namespace);
    if (!scalar.ok) return scalar;
    if (!isStringQueryScalar(scalar)) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'fieldsFrom' expects string field names"),
      };
    }
    if (requested.includes(scalar.value)) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function 'fieldsFrom' received duplicate requested field '${scalar.value}'`),
      };
    }
    requested.push(scalar.value);
  }

  const keys = evaluateResolutionExpression(keyResolution, currentBinding, namespace, options);
  if (!keys.ok) return keys;
  const values = evaluateResolutionExpression(valueResolution, currentBinding, namespace, options);
  if (!values.ok) return values;

  return objectFromBindingSets(keys.value.bindings, values.value.bindings, namespace, 'fieldsFrom', new Set(requested));
}

function objectFromBindingSets(keyBindings, valueBindings, namespace, functionName, requestedFields = null) {
  if (keyBindings.length !== valueBindings.length) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', `Function '${functionName}' expected key and value binding sets with equal length`),
    };
  }

  const output = {};
  const fieldMetadata = {};
  const observedRequestedFields = new Set();
  for (let index = 0; index < keyBindings.length; index += 1) {
    const keyScalar = getBindingScalarValue(namespace, keyBindings[index]);
    if (!keyScalar.ok) return keyScalar;
    if (!isStringQueryScalar(keyScalar)) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${functionName}' expects string key bindings`),
      };
    }
    if (requestedFields && !requestedFields.has(keyScalar.value)) continue;
    if (Object.hasOwn(output, keyScalar.value)) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${functionName}' received duplicate key '${keyScalar.value}'`),
      };
    }

    const valueScalar = getBindingScalarValue(namespace, valueBindings[index]);
    if (!valueScalar.ok) return valueScalar;
    output[keyScalar.value] = valueScalar.value;
    observedRequestedFields.add(keyScalar.value);
    if (valueScalar.metadata) fieldMetadata[keyScalar.value] = valueScalar.metadata;
  }
  if (requestedFields) {
    for (const field of requestedFields) {
      if (!observedRequestedFields.has(field)) {
        return {
          ok: false,
          error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', `Function '${functionName}' could not find requested field '${field}'`),
        };
      }
    }
  }

  if (Object.keys(fieldMetadata).length > 0) {
    Object.defineProperty(output, QUERY_OBJECT_FIELD_METADATA_PROPERTY, {
      value: fieldMetadata,
      enumerable: false,
    });
  }
  return {
    ok: true,
    value: {
      type: 'object',
      value: output,
    },
  };
}

function isSpecialValuePredicateName(name) {
  return ['isValue', 'isNull', 'isNullReason', 'isNaN', 'isInfinity'].includes(name);
}

function evaluateSpecialValuePredicate(expression, currentBinding, namespace, options) {
  const arity = expression.name === 'isNullReason' ? 2 : 1;
  if (expression.arguments.length !== arity) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${expression.name}' expects ${arity} argument${arity === 1 ? '' : 's'}`),
    };
  }

  if (expression.name === 'isValue') {
    return evaluateIsValuePredicate(expression.arguments[0], currentBinding, namespace, options);
  }

  const bindingInfo = evaluateSingleBindingArgument(expression.name, expression.arguments[0], currentBinding, namespace, options);
  if (!bindingInfo.ok) return bindingInfo;

  switch (expression.name) {
    case 'isNull':
      return scalarBoolean(isExplicitNullScalar(bindingInfo));
    case 'isNullReason': {
      const reason = evaluateQueryExpressionValue(expression.arguments[1], currentBinding, namespace, options);
      if (!reason.ok) return reason;
      const scalarReason = expectScalarQueryValue(reason.value, namespace);
      if (!scalarReason.ok) return scalarReason;
      if (!isStringQueryScalar(scalarReason)) {
        return {
          ok: false,
          error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', "Function 'isNullReason' expects a string reason"),
        };
      }
      return scalarBoolean(isExplicitNullScalar(bindingInfo) && bindingInfo.nullReason === scalarReason.value);
    }
    case 'isNaN':
      return scalarBoolean(isNanScalar(bindingInfo));
    case 'isInfinity':
      return scalarBoolean(isInfinityScalar(bindingInfo));
    default:
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION', `Function '${expression.name}' is not supported by this evaluator slice`),
      };
  }
}

function evaluateIsValuePredicate(argument, currentBinding, namespace, options) {
  const evaluated = evaluateQueryExpressionValue(argument, currentBinding, namespace, options);
  if (!evaluated.ok) {
    if (evaluated.error.code === 'SANSA_QUERY_EVALUATE_MISSING_SCALAR') return scalarBoolean(false);
    return evaluated;
  }
  return evaluateIsValueQueryValue(evaluated.value, namespace);
}

function evaluateIsValueQueryValue(value, namespace) {
  if (value.type === 'scalar') {
    return scalarBoolean(isConcreteValueScalar({
      value: value.value,
      ...(value[QUERY_VALUE_METADATA_PROPERTY]?.kind === undefined ? {} : { kind: value[QUERY_VALUE_METADATA_PROPERTY].kind }),
    }));
  }
  if (value.type === 'object') return scalarBoolean(true);
  if (value.type !== 'bindingSet') {
    return scalarBoolean(false);
  }
  if (value.bindings.length === 0) return scalarBoolean(false);
  if (value.bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', "Function 'isValue' expected one binding but resolved multiple bindings"),
    };
  }

  const scalar = getBindingScalarInfo(namespace, value.bindings[0]);
  if (!scalar.ok) {
    if (scalar.error.code === 'SANSA_QUERY_EVALUATE_MISSING_SCALAR' && isContainerBinding(namespace, value.bindings[0])) {
      return scalarBoolean(true);
    }
    if (scalar.error.code === 'SANSA_QUERY_EVALUATE_MISSING_SCALAR') return scalarBoolean(false);
    return scalar;
  }
  return scalarBoolean(isConcreteValueScalar(scalar));
}

function evaluateSingleBindingArgument(name, argument, currentBinding, namespace, options) {
  const resolution = unwrapResolutionExpression(argument);
  if (!resolution) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${name}' expects a resolution expression`),
    };
  }
  const evaluated = evaluateResolutionExpression(resolution, currentBinding, namespace, options);
  if (!evaluated.ok) return evaluated;
  if (evaluated.value.bindings.length === 0) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', `Function '${name}' expected one binding but resolved none`),
    };
  }
  if (evaluated.value.bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', `Function '${name}' expected one binding but resolved multiple bindings`),
    };
  }
  const scalar = getBindingScalarInfo(namespace, evaluated.value.bindings[0]);
  if (!scalar.ok) return scalar;
  return scalar;
}

function isExplicitNullScalar(info) {
  return info.kind === 'null' || info.value === null;
}

function isNanScalar(info) {
  return info.kind === 'nan' || (typeof info.value === 'number' && Number.isNaN(info.value));
}

function isInfinityScalar(info) {
  return info.kind === 'infinity' || info.value === Infinity || info.value === -Infinity;
}

function isConcreteValueScalar(info) {
  if (isNanScalar(info) || isExplicitNullScalar(info) || isExplicitAbsenceScalar(info)) return false;
  if (info.kind === 'missing' || info.category === 'missing') return false;
  if (info.category === 'bindingSet' || info.kind === 'bindingSet') return false;
  if (info.value === undefined && !['container', 'referenceForm', 'sansaAddress', 'lexicalStructuredScalar', 'temporal', 'toggle'].includes(info.category)) {
    return false;
  }
  return true;
}

function scalarBoolean(value) {
  return scalarQueryValue(value);
}

function queryLiteralMetadata(expression) {
  switch (expression.kind) {
    case 'number':
      return { kind: 'number', category: 'finiteNumber', numericLexeme: expression.canonical };
    case 'toggle':
      return { kind: 'toggle', category: 'toggle' };
    case 'hex':
      return { kind: 'hex', category: 'hex' };
    case 'radix':
      return { kind: 'radix', category: 'radix' };
    case 'encoding':
      return { kind: 'encoding', category: 'encoding' };
    case 'separator':
      return { kind: 'separator', category: 'separator' };
    case 'symbol':
      return { kind: 'symbol', category: 'symbol' };
    case 'date':
    case 'time':
    case 'datetime':
    case 'wtc':
      return { kind: expression.kind, category: 'temporal', semanticType: expression.kind };
    case 'null':
      return { kind: 'null', category: 'explicitNull', nullReason: expression.nullReason };
    default:
      return undefined;
  }
}

function scalarQueryValue(value, metadata) {
  const output = {
    type: 'scalar',
    value,
  };
  if (metadata) {
    Object.defineProperty(output, QUERY_VALUE_METADATA_PROPERTY, {
      value: metadata,
      enumerable: false,
    });
  }
  return {
    ok: true,
    value: output,
  };
}

function evaluateStringFunction(name, args, arity, operation) {
  if (args.length !== arity) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${name}' expects ${arity} argument${arity === 1 ? '' : 's'}`),
    };
  }
  if (args.some((arg) => !isStringQueryScalar(arg))) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_FUNCTION_CALL', `Function '${name}' expects string arguments`),
    };
  }
  return {
    ok: true,
    value: {
      type: 'scalar',
      value: operation(args.map((arg) => arg.value)),
    },
  };
}

function isStringQueryScalar(scalar) {
  if (typeof scalar.value !== 'string' || scalar.metadata?.numericLexeme !== undefined) return false;
  const info = queryScalarToInfo(scalar);
  const category = normalizeValueSemanticsCategory(info.category ?? info.kind);
  return category === undefined || category === 'string' || category === 'stringLiteral';
}

function queryScalarPosition(scalar) {
  const numericLexeme = scalar.metadata?.numericLexeme;
  if (typeof numericLexeme === 'string') {
    const parsed = parseExactFiniteNumber(numericLexeme);
    if (parsed === null || parsed.sign < 0) return null;
    if (parsed.sign === 0) return 0;

    let integerDigits = parsed.digits;
    if (parsed.scale < 0n) {
      const fractionalWidth = -parsed.scale;
      if (fractionalWidth > BigInt(integerDigits.length)) return null;
      const split = integerDigits.length - Number(fractionalWidth);
      if (!/^0*$/u.test(integerDigits.slice(split))) return null;
      integerDigits = integerDigits.slice(0, split) || '0';
    } else {
      if (BigInt(integerDigits.length) + parsed.scale > 16n) return null;
      integerDigits += '0'.repeat(Number(parsed.scale));
    }

    const value = Number(integerDigits);
    return Number.isSafeInteger(value) ? value : null;
  }
  return Number.isSafeInteger(scalar.value) && scalar.value >= 0 ? scalar.value : null;
}

function evaluateExistenceExpression(expression, currentBinding, namespace, options) {
  const resolution = unwrapResolutionExpression(expression.argument);
  if (!resolution) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_EXISTENCE_ARGUMENT', 'Existence operators require a resolution expression'),
    };
  }

  const resolved = evaluateResolutionExpression(resolution, currentBinding, namespace, options);
  if (!resolved.ok) return resolved;
  const hasBindings = resolved.value.bindings.length > 0;
  return {
    ok: true,
    value: {
      type: 'scalar',
      value: expression.operator === 'exists' ? hasBindings : !hasBindings,
    },
  };
}

function unwrapResolutionExpression(expression) {
  if (expression.type === 'groupExpression') return unwrapResolutionExpression(expression.expression);
  return expression.type === 'resolutionExpression' ? expression : null;
}

function evaluateCardinalityExpression(expression, currentBinding, namespace, options) {
  const booleans = evaluateCardinalityBooleans(expression.argument, currentBinding, namespace, options);
  if (!booleans.ok) return booleans;
  const value = (() => {
    switch (expression.operator) {
      case 'any': return booleans.values.some(Boolean);
      case 'all': return booleans.values.every(Boolean);
      case 'none': return booleans.values.every((entry) => !entry);
      default: return false;
    }
  })();
  return {
    ok: true,
    value: {
      type: 'scalar',
      value,
    },
  };
}

function evaluateCardinalityBooleans(expression, currentBinding, namespace, options) {
  if (expression.type === 'groupExpression') {
    return evaluateCardinalityBooleans(expression.expression, currentBinding, namespace, options);
  }

  if (expression.type === 'resolutionExpression') {
    const resolved = evaluateResolutionExpression(expression, currentBinding, namespace, options);
    if (!resolved.ok) return resolved;
    const values = [];
    for (const binding of resolved.value.bindings) {
      const scalar = getBindingScalarValue(namespace, binding);
      if (!scalar.ok) return scalar;
      if (typeof scalar.value !== 'boolean') {
        return {
          ok: false,
          error: queryEvaluateError('SANSA_QUERY_EVALUATE_EXPECTED_BOOLEAN', 'Cardinality resolution operands must expose Boolean scalar values'),
        };
      }
      values.push(scalar.value);
    }
    return { ok: true, values };
  }

  if (expression.type === 'functionCallExpression') {
    return evaluateCardinalityFunctionBooleans(expression, currentBinding, namespace, options);
  }

  if (expression.type !== 'binaryExpression' || ['and', 'or'].includes(expression.operator)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_CARDINALITY_ARGUMENT', 'Cardinality operators require a resolution predicate in this evaluator slice'),
    };
  }

  const left = evaluateQueryExpressionValue(expression.left, currentBinding, namespace, options);
  if (!left.ok) return left;
  const right = evaluateQueryExpressionValue(expression.right, currentBinding, namespace, options);
  if (!right.ok) return right;

  const leftIsSet = left.value.type === 'bindingSet';
  const rightIsSet = right.value.type === 'bindingSet';

  if (leftIsSet === rightIsSet) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_CARDINALITY_ARGUMENT', 'Cardinality comparison predicates require exactly one binding-set side'),
    };
  }

  const setValue = leftIsSet ? left.value : right.value;
  const scalarValue = leftIsSet
    ? expectScalarQueryValue(right.value, namespace)
    : expectScalarQueryValue(left.value, namespace);
  if (!scalarValue.ok) return scalarValue;

  const values = [];
  for (const binding of setValue.bindings) {
    const bindingScalar = getBindingScalarValue(namespace, binding);
    if (!bindingScalar.ok) return bindingScalar;
    const compared = leftIsSet
      ? compareQueryScalars(expression.operator, bindingScalar, scalarValue, options)
      : compareQueryScalars(expression.operator, scalarValue, bindingScalar, options);
    if (!compared.ok) return compared;
    values.push(compared.value.value);
  }
  return { ok: true, values };
}

function evaluateCardinalityFunctionBooleans(expression, currentBinding, namespace, options) {
  if (!isOrdinaryFunctionName(expression.name)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_UNSUPPORTED_FUNCTION', `Function '${expression.name}' is not supported by this evaluator slice`),
    };
  }

  const evaluatedArgs = [];
  for (const argument of expression.arguments) {
    const evaluated = evaluateQueryExpressionValue(argument, currentBinding, namespace, options);
    if (!evaluated.ok) return evaluated;
    evaluatedArgs.push(evaluated.value);
  }

  const bindingSetArgs = evaluatedArgs
    .map((value, index) => ({ value, index }))
    .filter((entry) => entry.value.type === 'bindingSet');
  if (bindingSetArgs.length !== 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_CARDINALITY_ARGUMENT', 'Cardinality function predicates require exactly one binding-set argument'),
    };
  }

  const scalarArgs = [];
  for (let index = 0; index < evaluatedArgs.length; index += 1) {
    if (index === bindingSetArgs[0].index) {
      scalarArgs.push(null);
      continue;
    }
    const scalar = expectScalarQueryValue(evaluatedArgs[index], namespace);
    if (!scalar.ok) return scalar;
    scalarArgs.push(scalar);
  }

  const values = [];
  for (const binding of bindingSetArgs[0].value.bindings) {
    const bindingScalar = getBindingScalarValue(namespace, binding);
    if (!bindingScalar.ok) return bindingScalar;
    const args = scalarArgs.slice();
    args[bindingSetArgs[0].index] = bindingScalar;
    const evaluated = evaluateOrdinaryFunction(expression.name, args);
    if (!evaluated.ok) return evaluated;
    if (evaluated.value.type !== 'scalar' || typeof evaluated.value.value !== 'boolean') {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_EXPECTED_BOOLEAN', 'Cardinality function predicates must evaluate to Boolean scalar values'),
      };
    }
    values.push(evaluated.value.value);
  }
  return { ok: true, values };
}

function orderQueryBindings(orderBy, bindings, namespace, options) {
  const keyed = [];
  for (let index = 0; index < bindings.length; index += 1) {
    const binding = bindings[index];
    const keys = [];
    for (const key of orderBy.keys) {
      const evaluated = evaluateQueryExpressionValue(key.ast, binding, namespace, options);
      if (!evaluated.ok) {
        return {
          ok: false,
          error: annotateQueryDiagnostic(evaluated.error, { candidateAddress: getBindingAddress(binding) }),
        };
      }
      const scalar = expectScalarQueryValue(evaluated.value, namespace);
      if (!scalar.ok) {
        return {
          ok: false,
          error: annotateQueryDiagnostic(scalar.error, { candidateAddress: getBindingAddress(binding) }),
        };
      }
      if (!['number', 'string'].includes(typeof scalar.value)) {
        return {
          ok: false,
          error: queryEvaluateError(
            'SANSA_QUERY_EVALUATE_INVALID_COMPARISON',
            'Order keys must evaluate to string or number scalar values',
            { candidateAddress: getBindingAddress(binding) },
          ),
        };
      }
      if (typeof scalar.value === 'number' && Number.isNaN(scalar.value)) {
        return {
          ok: false,
          error: queryEvaluateError(
            'SANSA_QUERY_EVALUATE_INVALID_COMPARISON',
            'NaN is not a valid order key',
            { candidateAddress: getBindingAddress(binding) },
          ),
        };
      }
      const descriptor = scalarInfoToValueDescriptor(queryScalarToInfo({
        value: scalar.value,
        metadata: scalar.metadata,
      }));
      const orderable = evaluateValueSemanticsOperation('compare', {
        left: descriptor,
        right: descriptor,
      }, {
        valueSemantics: options.valueSemantics,
      });
      if (!orderable.ok) {
        return {
          ok: false,
          error: queryEvaluateError(
            'SANSA_QUERY_EVALUATE_INVALID_COMPARISON',
            queryComparisonMessage(orderable.reason, '<'),
            { candidateAddress: getBindingAddress(binding) },
          ),
        };
      }
      keys.push({ value: scalar.value, descriptor, direction: key.direction });
    }
    keyed.push({ binding, keys, index });
  }

  for (let keyIndex = 0; keyIndex < orderBy.keys.length; keyIndex += 1) {
    const expected = keyed[0]?.keys[keyIndex].descriptor;
    const mismatched = expected
      ? keyed.find((entry) => !evaluateValueSemanticsOperation('compare', {
        left: expected,
        right: entry.keys[keyIndex].descriptor,
      }, {
        valueSemantics: options.valueSemantics,
      }).ok)
      : undefined;
    if (mismatched) {
      return {
        ok: false,
        error: queryEvaluateError(
          'SANSA_QUERY_EVALUATE_INVALID_COMPARISON',
          'Order keys must evaluate to one scalar type per key position',
          { candidateAddress: getBindingAddress(mismatched.binding) },
        ),
      };
    }
  }

  keyed.sort((left, right) => {
    for (let index = 0; index < left.keys.length; index += 1) {
      const comparison = compareOrderKeyScalars(left.keys[index], right.keys[index], options.valueSemantics);
      if (comparison !== 0) {
        return left.keys[index].direction === 'desc' ? -comparison : comparison;
      }
    }
    return left.index - right.index;
  });

  return {
    ok: true,
    bindings: keyed.map((entry) => entry.binding),
  };
}

function compareOrderKeyScalars(left, right, valueSemantics) {
  const compared = evaluateValueSemanticsOperation('compare', {
    left: left.descriptor,
    right: right.descriptor,
  }, {
    valueSemantics,
  });
  if (!compared.ok) return 0;
  if (compared.relation === 'less') return -1;
  if (compared.relation === 'greater') return 1;
  return 0;
}

function comparePrimitiveOrderValues(left, right, valueSemantics) {
  if (typeof left === 'string') return getValueSemanticsProfile(valueSemantics).compareStrings(left, right);
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}

function getValueSemanticsProfile(valueSemantics) {
  if (!valueSemantics) return aeonValueSemanticsDefaultProfile;
  if (valueSemantics === 'default' || valueSemantics === DEFAULT_VALUE_SEMANTICS_PROFILE_ID) {
    return aeonValueSemanticsDefaultProfile;
  }
  if (valueSemantics === CODEPOINT_STRING_PROFILE_ID) {
    return aeonValueSemanticsDefaultProfile;
  }
  if (valueSemantics === FRENCH_STRING_PROFILE_ID) {
    return createFrenchValueSemanticsProfile();
  }
  if (valueSemantics === NATURAL_ASCII_STRING_PROFILE_ID || valueSemantics === 'natural-ascii') {
    return createNaturalAsciiValueSemanticsProfile();
  }
  if (valueSemantics === RADIX_NUMERIC_SAME_BASE_PROFILE_ID || valueSemantics === 'radix-numeric') {
    return createRadixNumericValueSemanticsProfile();
  }
  if (valueSemantics === RADIX_NUMERIC_CROSS_BASE_PROFILE_ID || valueSemantics === 'radix-numeric-cross-base') {
    return createCrossBaseRadixNumericValueSemanticsProfile();
  }
  if (valueSemantics === 'fr' || valueSemantics === 'fr-FR') {
    return createFrenchValueSemanticsProfile({ locale: valueSemantics });
  }
  if (typeof valueSemantics === 'string') {
    return createIntlValueSemanticsProfile({ locale: valueSemantics });
  }
  if (valueSemantics.profile) return getValueSemanticsProfile(valueSemantics.profile);
  const hasCompareStrings = typeof valueSemantics.compareStrings === 'function';
  const hasLowerString = typeof valueSemantics.lowerString === 'function';
  const hasUpperString = typeof valueSemantics.upperString === 'function';
  const hasCompareTemporal = typeof valueSemantics.compareTemporal === 'function';
  const hasCompareRadix = typeof valueSemantics.compareRadix === 'function';
  if (hasCompareStrings && hasLowerString && hasUpperString) {
    return {
      ...aeonValueSemanticsDefaultProfile,
      ...valueSemantics,
      compareStrings: (left, right) => normalizeComparison(valueSemantics.compareStrings(left, right)),
      compareTemporal: typeof valueSemantics.compareTemporal === 'function'
        ? (left, right) => normalizeComparison(valueSemantics.compareTemporal(left, right))
        : aeonValueSemanticsDefaultProfile.compareTemporal,
      ...(hasCompareRadix ? {
        compareRadix: (left, right) => normalizeOptionalComparison(valueSemantics.compareRadix(left, right)),
      } : {}),
    };
  }
  if (hasCompareStrings || hasLowerString || hasUpperString) {
    throw new Error('Custom value-semantics profiles must define compareStrings, lowerString, and upperString together.');
  }
  if (hasCompareTemporal || hasCompareRadix) {
    return {
      ...aeonValueSemanticsDefaultProfile,
      ...valueSemantics,
      compareTemporal: hasCompareTemporal
        ? (left, right) => normalizeComparison(valueSemantics.compareTemporal(left, right))
        : aeonValueSemanticsDefaultProfile.compareTemporal,
      ...(hasCompareRadix ? {
        compareRadix: (left, right) => normalizeOptionalComparison(valueSemantics.compareRadix(left, right)),
      } : {}),
    };
  }
  if (
    valueSemantics.locale
  ) {
    return createIntlValueSemanticsProfile(valueSemantics);
  }
  throw new Error('Unsupported value-semantics profile input.');
}

function normalizeComparison(value) {
  if (value < 0) return -1;
  if (value > 0) return 1;
  return 0;
}

function normalizeOptionalComparison(value) {
  return value === null || value === undefined ? null : normalizeComparison(value);
}

function compareStringsByUnicodeScalarValue(left, right) {
  const leftScalars = Array.from(left);
  const rightScalars = Array.from(right);
  const length = Math.min(leftScalars.length, rightScalars.length);
  for (let index = 0; index < length; index += 1) {
    const leftCodePoint = leftScalars[index].codePointAt(0);
    const rightCodePoint = rightScalars[index].codePointAt(0);
    if (leftCodePoint < rightCodePoint) return -1;
    if (leftCodePoint > rightCodePoint) return 1;
  }
  if (leftScalars.length < rightScalars.length) return -1;
  if (leftScalars.length > rightScalars.length) return 1;
  return 0;
}

function compareStringsByNaturalAsciiOrder(left, right) {
  let leftIndex = 0;
  let rightIndex = 0;

  while (leftIndex < left.length && rightIndex < right.length) {
    const leftCode = left.codePointAt(leftIndex);
    const rightCode = right.codePointAt(rightIndex);
    if (isAsciiDigitCodePoint(leftCode) && isAsciiDigitCodePoint(rightCode)) {
      const leftRun = readAsciiDigitRun(left, leftIndex);
      const rightRun = readAsciiDigitRun(right, rightIndex);
      const comparedNumber = compareAsciiDigitRuns(leftRun.text, rightRun.text);
      if (comparedNumber !== 0) return comparedNumber;
      leftIndex = leftRun.end;
      rightIndex = rightRun.end;
      continue;
    }
    if (leftCode < rightCode) return -1;
    if (leftCode > rightCode) return 1;
    leftIndex += codePointWidth(leftCode);
    rightIndex += codePointWidth(rightCode);
  }

  if (leftIndex < left.length) return 1;
  if (rightIndex < right.length) return -1;
  return 0;
}

function readAsciiDigitRun(value, start) {
  let end = start;
  while (end < value.length && isAsciiDigitCodePoint(value.codePointAt(end))) end += 1;
  return { text: value.slice(start, end), end };
}

function compareAsciiDigitRuns(left, right) {
  const leftTrimmed = left.replace(/^0+/, '') || '0';
  const rightTrimmed = right.replace(/^0+/, '') || '0';
  if (leftTrimmed.length < rightTrimmed.length) return -1;
  if (leftTrimmed.length > rightTrimmed.length) return 1;
  const lexical = compareStringsByUnicodeScalarValue(leftTrimmed, rightTrimmed);
  if (lexical !== 0) return lexical;
  if (left.length < right.length) return -1;
  if (left.length > right.length) return 1;
  return 0;
}

function compareTemporalByCanonicalValue(left, right) {
  return compareStringsByUnicodeScalarValue(String(left.payload ?? ''), String(right.payload ?? ''));
}

/**
 * Compare two temporal claims as completion sets without resolving external
 * timezone, leap-second, calendar, or clock authorities.
 *
 * @returns {'equal'|'before'|'after'|'contains'|'containedBy'|'overlaps'|'incomparable'}
 */
export function compareTemporalClaims(left, right) {
  const leftClaim = parseTemporalCompletionSet(left);
  const rightClaim = parseTemporalCompletionSet(right);
  if (leftClaim === null || rightClaim === null || leftClaim.domain !== rightClaim.domain) {
    return 'incomparable';
  }

  // UTC leap-second chronology requires a leap table. Preserve exact identity,
  // but do not manufacture an ordering around second 60 without that authority.
  if (leftClaim.leapSecond || rightClaim.leapSecond) {
    return leftClaim.leapSecond
      && rightClaim.leapSecond
      && compareTemporalDecimal(leftClaim.start, rightClaim.start) === 0
      ? 'equal'
      : 'incomparable';
  }

  const startOrder = compareTemporalDecimal(leftClaim.start, rightClaim.start);
  if (leftClaim.point && rightClaim.point) {
    return startOrder < 0 ? 'before' : startOrder > 0 ? 'after' : 'equal';
  }
  if (leftClaim.point) {
    if (startOrder < 0) return 'before';
    if (compareTemporalDecimal(leftClaim.start, rightClaim.end) >= 0) return 'after';
    return 'containedBy';
  }
  if (rightClaim.point) {
    if (compareTemporalDecimal(leftClaim.end, rightClaim.start) <= 0) return 'before';
    if (startOrder > 0) return 'after';
    return 'contains';
  }

  const endOrder = compareTemporalDecimal(leftClaim.end, rightClaim.end);
  if (startOrder === 0 && endOrder === 0) return 'equal';
  if (compareTemporalDecimal(leftClaim.end, rightClaim.start) <= 0) return 'before';
  if (compareTemporalDecimal(rightClaim.end, leftClaim.start) <= 0) return 'after';
  if (startOrder <= 0 && endOrder >= 0) return 'contains';
  if (startOrder >= 0 && endOrder <= 0) return 'containedBy';
  return 'overlaps';
}

function parseTemporalCompletionSet(input) {
  const semanticType = String(input?.semanticType ?? 'temporal');
  const payload = String(input?.payload ?? input?.value ?? '');
  if (!isQueryTemporalLiteral(payload, semanticType)) return null;
  if (semanticType === 'date') {
    const date = parseTemporalDate(payload);
    if (date === null) return null;
    const startMonth = date.month ?? 1;
    const startDay = date.day ?? 1;
    const start = temporalInteger(dateOrdinal(date.year, startMonth, startDay) * 86_400n);
    let endOrdinal;
    if (date.month === null) {
      endOrdinal = dateOrdinal(date.year + 1, 1, 1);
    } else if (date.day === null) {
      endOrdinal = date.month === 12
        ? dateOrdinal(date.year + 1, 1, 1)
        : dateOrdinal(date.year, date.month + 1, 1);
    } else {
      endOrdinal = dateOrdinal(date.year, date.month, date.day) + 1n;
    }
    const end = temporalInteger(endOrdinal * 86_400n);
    return { domain: 'date', start, end, point: false, leapSecond: false };
  }
  if (!['time', 'datetime', 'wtc'].includes(semanticType)) return null;

  let base = payload;
  let context = null;
  if (semanticType === 'wtc') {
    const ampersand = payload.indexOf('&');
    if (ampersand === -1) return null;
    base = payload.slice(0, ampersand);
    context = payload.slice(ampersand + 1);
    if (context.length === 0) return null;
  }

  let date = null;
  let clockText = base;
  if (semanticType !== 'time') {
    const marker = base.indexOf('T');
    if (marker === -1) return null;
    date = parseTemporalDate(base.slice(0, marker));
    // Clock-bearing year/month ticks have disjoint daily completion sets. This
    // conservative interval comparator must not invent a month/day or flatten
    // those sets into one interval. Rust returns incomparable for these too.
    if (date === null || date.month === null || date.day === null) return null;
    clockText = base.slice(marker + 1);
  }
  const clock = parseTemporalClock(clockText, semanticType === 'time');
  if (clock === null) return null;
  const domain = temporalCompletionDomain(semanticType, clock.anchor, context);
  if (domain === null) return null;

  let wholeSeconds = BigInt(clock.hour * 3_600 + (clock.minute ?? 0) * 60 + (clock.second ?? 0));
  if (date !== null) wholeSeconds += dateOrdinal(date.year, date.month, date.day) * 86_400n;
  if (clock.anchor === 'Z') {
    // already UTC-relative
  } else if (clock.anchor !== null && clock.anchor !== '-00:00') {
    const sign = clock.anchor[0] === '-' ? -1n : 1n;
    const offset = BigInt(Number(clock.anchor.slice(1, 3)) * 3_600 + Number(clock.anchor.slice(4, 6)) * 60);
    wholeSeconds -= sign * offset;
  }

  const start = clock.fraction === null
    ? temporalInteger(wholeSeconds)
    : { coefficient: wholeSeconds * (10n ** BigInt(clock.fraction.length)) + BigInt(clock.fraction), scale: clock.fraction.length };
  if (clock.second !== null) {
    return { domain, start, end: start, point: true, leapSecond: clock.second === 60 };
  }
  const width = clock.minute === null ? 3_600n : 60n;
  return { domain, start, end: addTemporalInteger(start, width), point: false, leapSecond: false };
}

function temporalCompletionDomain(semanticType, anchor, context) {
  const scope = semanticType === 'time' ? 'time' : 'datetime';
  const recognizedTimescales = new Set(['UTC', 'TAI', 'UT1', 'TT', 'GPS']);
  if (context !== null && recognizedTimescales.has(context) && anchor !== null) {
    if (context !== 'UTC') return null;
  }
  if (scope === 'time' && anchor !== null && anchor !== '-00:00') {
    return anchor === 'Z' || anchor === '+00:00' ? 'instant:time:UTC' : `offset-time:${anchor}`;
  }
  if (anchor === 'Z' || (anchor !== null && anchor !== '-00:00')) return 'instant:datetime';
  if (anchor === '-00:00') return `unknown-offset:${scope}:${context ?? ''}`;
  if (context === 'local') return `resolver-local:${scope}`;
  if (context !== null && recognizedTimescales.has(context)) return `timescale:${context}:${scope}`;
  if (context !== null) return `context:${context}:${scope}`;
  return `civil:${scope}`;
}

function parseTemporalDate(value) {
  if (value.trim() !== value) return null;
  const yearOnly = /^(\d{4})-$/.exec(value);
  if (yearOnly !== null) {
    const year = Number(yearOnly[1]);
    return year >= 1 && year <= 9999 ? { year, month: null, day: null } : null;
  }
  const yearMonth = /^(\d{4})-(\d{2})$/.exec(value);
  if (yearMonth !== null) {
    const year = Number(yearMonth[1]);
    const month = Number(yearMonth[2]);
    return year >= 1 && year <= 9999 && month >= 1 && month <= 12
      ? { year, month, day: null }
      : null;
  }
  const fullDate = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (fullDate === null || !isValidDateParts(fullDate[1], fullDate[2], fullDate[3])) return null;
  return { year: Number(fullDate[1]), month: Number(fullDate[2]), day: Number(fullDate[3]) };
}

function parseTemporalClock(value, requireColon) {
  if (value.trim() !== value) return null;
  const pattern = requireColon
    ? /^(\d{2}):(?:(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?(Z|[+-]\d{2}:\d{2})?$/
    : /^(\d{2})(?::(?:(\d{2})(?::(\d{2})(?:\.(\d+))?)?)?)?(Z|[+-]\d{2}:\d{2})?$/;
  const match = pattern.exec(value);
  if (match === null) return null;
  const hour = Number(match[1]);
  const minute = match[2] === undefined ? null : Number(match[2]);
  const second = match[3] === undefined ? null : Number(match[3]);
  const anchor = match[5] ?? null;
  if (hour > 23 || (minute !== null && minute > 59) || (second !== null && second > 60)) return null;
  if (anchor !== null && anchor !== 'Z') {
    if (Number(anchor.slice(1, 3)) > 23 || Number(anchor.slice(4, 6)) > 59) return null;
  }
  return { hour, minute, second, fraction: match[4] ?? null, anchor };
}

function dateOrdinal(year, month, day) {
  const priorYear = BigInt(year - 1);
  const daysBeforeYear = priorYear * 365n + priorYear / 4n - priorYear / 100n + priorYear / 400n;
  const monthDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const leapAdjustment = month > 2 && isLeapYear(year) ? 1 : 0;
  return daysBeforeYear + BigInt(monthDays[month - 1] + leapAdjustment + day - 1);
}

function temporalInteger(value) {
  return { coefficient: value, scale: 0 };
}

function addTemporalInteger(value, integer) {
  return { coefficient: value.coefficient + integer * (10n ** BigInt(value.scale)), scale: value.scale };
}

function compareTemporalDecimal(left, right) {
  const scale = Math.max(left.scale, right.scale);
  const leftCoefficient = left.coefficient * (10n ** BigInt(scale - left.scale));
  const rightCoefficient = right.coefficient * (10n ** BigInt(scale - right.scale));
  return leftCoefficient < rightCoefficient ? -1 : leftCoefficient > rightCoefficient ? 1 : 0;
}

function isAsciiDigitCodePoint(codePoint) {
  return codePoint >= 0x30 && codePoint <= 0x39;
}

function codePointWidth(codePoint) {
  return codePoint > 0xffff ? 2 : 1;
}

export function evaluateValueSemanticsOperation(operation, input = {}, options = {}) {
  try {
    if (operation === 'radixScale') return evaluateValueSemanticsRadixScale(input.value);
    if (operation === 'temporalRelation') return evaluateValueSemanticsTemporalRelation(input.left, input.right);
    const profile = getValueSemanticsProfile(options.valueSemantics ?? input.valueSemantics ?? input.profile);
    switch (operation) {
      case 'equal':
      case 'notEqual':
        return evaluateValueSemanticsEquality(operation, input.left, input.right, profile);
      case 'compare':
        return evaluateValueSemanticsOrdering(input.left, input.right, profile);
      case 'isValue':
        return {
          ok: true,
          outcome: 'value',
          value: isConcreteValueScalar(valueDescriptorToScalarInfo(input.value)),
        };
      default:
        return valueSemanticsDiagnostic(
          'unsupported_operation',
          `Unsupported value-semantics operation '${String(operation)}'`,
        );
    }
  } catch (error) {
    return valueSemanticsDiagnostic('invalid_value_descriptor', error.message);
  }
}

function evaluateValueSemanticsTemporalRelation(leftDescriptor, rightDescriptor) {
  const left = valueDescriptorToScalarInfo(leftDescriptor);
  const right = valueDescriptorToScalarInfo(rightDescriptor);
  if (left.category !== 'temporal' || right.category !== 'temporal') {
    return valueSemanticsDiagnostic('temporal_required', 'Temporal relation is defined only for temporal values');
  }
  return {
    ok: true,
    outcome: 'value',
    relation: compareTemporalClaims(left.value, right.value),
  };
}

function evaluateValueSemanticsRadixScale(descriptor) {
  const info = valueDescriptorToScalarInfo(descriptor);
  if (info.category !== 'radix') {
    return valueSemanticsDiagnostic('radix_required', 'Radix scale is defined only for radix-family values');
  }
  const scale = radixScaleOf(info.value.payload, info.value.radixBase);
  if (scale === null || scale === undefined) {
    return valueSemanticsDiagnostic('invalid_radix_value', 'Radix payload is invalid for its resolved base');
  }
  return { ok: true, outcome: 'value', value: scale };
}

function evaluateValueSemanticsEquality(operation, leftDescriptor, rightDescriptor, profile) {
  const left = valueDescriptorToScalarInfo(leftDescriptor);
  const right = valueDescriptorToScalarInfo(rightDescriptor);
  if (isNanScalar(left) || isNanScalar(right) || isExplicitNullScalar(left) || isExplicitNullScalar(right) || isExplicitAbsenceScalar(left) || isExplicitAbsenceScalar(right)) {
    return valueSemanticsDiagnostic('not_equality_comparable', 'Value category is not equality-comparable in the minimum profile');
  }
  if (left.category === 'missing' || right.category === 'missing' || left.category === 'bindingSet' || right.category === 'bindingSet') {
    return valueSemanticsDiagnostic('not_equality_comparable', 'Evaluation state or non-scalar value is not equality-comparable');
  }
  if (left.category === 'radix' && right.category === 'radix' && typeof profile.compareRadix === 'function') {
    const comparison = compareRadixWithProfile(left, right, profile);
    if (!comparison.ok) return comparison.diagnostic;
    const value = comparison.value === 0;
    return { ok: true, outcome: 'value', value: operation === 'equal' ? value : !value };
  }
  if (!sameMinimumEqualityDomain(left, right)) {
    return valueSemanticsDiagnostic('mixed_categories', 'Mixed categories do not compare by implicit coercion');
  }
  const value = compareMinimumEquality(operation, left, right, profile);
  return {
    ok: true,
    outcome: 'value',
    value,
  };
}

function evaluateValueSemanticsOrdering(leftDescriptor, rightDescriptor, profile) {
  const left = valueDescriptorToScalarInfo(leftDescriptor);
  const right = valueDescriptorToScalarInfo(rightDescriptor);
  if (isNanScalar(left) || isNanScalar(right) || isExplicitNullScalar(left) || isExplicitNullScalar(right) || isExplicitAbsenceScalar(left) || isExplicitAbsenceScalar(right)) {
    return valueSemanticsDiagnostic('not_orderable', 'Value category is not orderable in the minimum profile');
  }
  if (left.category === 'missing' || right.category === 'missing' || left.category === 'container' || right.category === 'container' || left.category === 'bindingSet' || right.category === 'bindingSet') {
    return valueSemanticsDiagnostic('not_orderable', 'Evaluation state or non-scalar value is not orderable');
  }
  if (typeof left.value === 'boolean' && typeof right.value === 'boolean') {
    return valueSemanticsDiagnostic('not_orderable', 'Boolean ordering is not part of the minimum profile');
  }
  if (left.category === 'radix' && right.category === 'radix' && typeof profile.compareRadix === 'function') {
    const comparison = compareRadixWithProfile(left, right, profile);
    if (!comparison.ok) return comparison.diagnostic;
    return {
      ok: true,
      outcome: 'value',
      relation: comparison.value < 0 ? 'less' : comparison.value > 0 ? 'greater' : 'equal',
    };
  }
  if (!sameMinimumOrderingDomain(left, right)) {
    if (left.category === right.category && left.category !== 'temporal') {
      return valueSemanticsDiagnostic('not_orderable', 'Value category is not orderable in the minimum profile');
    }
    return valueSemanticsDiagnostic('mixed_categories', 'Mixed categories do not order by implicit coercion');
  }
  const comparison = compareMinimumOrdering(left, right, profile);
  return {
    ok: true,
    outcome: 'value',
    relation: comparison < 0 ? 'less' : comparison > 0 ? 'greater' : 'equal',
  };
}

function valueDescriptorToScalarInfo(descriptor) {
  if (!descriptor || typeof descriptor !== 'object') {
    throw new Error('Value descriptor must be an object');
  }
  switch (descriptor.category) {
    case 'finiteNumber': {
      const value = String(descriptor.value);
      if (parseExactFiniteNumber(value) === null) {
        throw new Error('finiteNumber descriptor must contain a canonical finite numeric value');
      }
      return { category: 'finiteNumber', value };
    }
    case 'positiveInfinity':
      return { category: 'positiveInfinity', value: Infinity, kind: 'infinity' };
    case 'negativeInfinity':
      return { category: 'negativeInfinity', value: -Infinity, kind: 'infinity' };
    case 'nan':
      return { category: 'nan', value: Number.NaN, kind: 'nan' };
    case 'string':
      return { category: 'string', value: String(descriptor.value ?? '') };
    case 'boolean':
      return { category: 'boolean', value: Boolean(descriptor.value) };
    case 'toggle':
      return { category: 'toggle', value: String(descriptor.value ?? '') };
    case 'hex':
      return { category: 'hex', value: String(descriptor.value ?? '') };
    case 'radix':
      return {
        category: 'radix',
        value: {
          payload: String(descriptor.value ?? ''),
          semanticType: descriptor.semanticType ?? 'radix',
          radixBase: normalizeRadixBase(descriptor.radixBase ?? radixBaseFromSemanticType(descriptor.semanticType)),
        },
      };
    case 'encoding':
      return { category: 'encoding', value: String(descriptor.value ?? '') };
    case 'separator':
      return { category: 'separator', value: String(descriptor.value ?? '') };
    case 'symbol':
      return { category: 'symbol', value: String(descriptor.value ?? '') };
    case 'sansaAddress':
      return { category: 'sansaAddress', value: sansaAddressSemanticValue(descriptor.value) };
    case 'referenceForm':
      return { category: 'referenceForm', value: descriptor.value ?? descriptor };
    case 'temporal':
      return {
        category: 'temporal',
        value: {
          payload: String(descriptor.value ?? ''),
          semanticType: descriptor.semanticType ?? 'temporal',
        },
      };
    case 'lexicalStructuredScalar':
      return { category: 'lexicalStructuredScalar', value: String(descriptor.value ?? '') };
    case 'explicitNull':
      return { category: 'explicitNull', value: null, kind: 'null', nullReason: descriptor.reason };
    case 'explicitAbsence':
      return { category: 'explicitAbsence', value: undefined, kind: 'absence', nullReason: descriptor.reason };
    case 'missing':
      return { category: 'missing', value: undefined, kind: 'missing' };
    case 'container':
      return {
        category: 'container',
        containerKind: descriptor.containerKind ?? descriptor.value?.containerKind,
        value: descriptor.value,
        kind: 'container',
      };
    case 'bindingSet':
      return { category: 'bindingSet', value: descriptor, kind: 'bindingSet' };
    default:
      throw new Error(`Unsupported value category '${String(descriptor.category)}'`);
  }
}

function scalarInfoToValueDescriptor(info) {
  if (isExplicitNullScalar(info)) {
    return { category: 'explicitNull', reason: info.nullReason };
  }
  if (isExplicitAbsenceScalar(info)) {
    return { category: 'explicitAbsence', reason: info.nullReason };
  }
  if (isNanScalar(info)) {
    return { category: 'nan' };
  }
  if (isInfinityScalar(info)) {
    return info.value === -Infinity
      ? { category: 'negativeInfinity' }
      : { category: 'positiveInfinity' };
  }
  if (info.numericLexeme !== undefined) {
    return { category: 'finiteNumber', value: info.numericLexeme };
  }
  const semanticCategory = VALUE_SEMANTICS_METADATA_CATEGORIES.includes(info.category)
    ? info.category
    : VALUE_SEMANTICS_METADATA_CATEGORIES.includes(info.kind)
      ? info.kind
      : undefined;
  if (semanticCategory) {
    const category = normalizeValueSemanticsCategory(semanticCategory);
    return {
      category,
      value: info.value,
      ...(info.semanticType === undefined ? {} : { semanticType: info.semanticType }),
      ...(info.radixBase === undefined ? {} : { radixBase: info.radixBase }),
      ...(info.radixScale === undefined ? {} : { radixScale: info.radixScale }),
      ...(info.containerKind === undefined ? {} : { containerKind: info.containerKind }),
    };
  }
  if (typeof info.value === 'number') {
    return Number.isFinite(info.value)
      ? { category: 'finiteNumber', value: String(info.value) }
      : { category: 'nan' };
  }
  if (typeof info.value === 'string') {
    return { category: 'string', value: info.value };
  }
  if (typeof info.value === 'boolean') {
    return { category: 'boolean', value: info.value };
  }
  if (info.kind === 'missing' || info.category === 'missing') {
    return { category: 'missing' };
  }
  if (info.kind === 'bindingSet' || info.category === 'bindingSet') {
    return { category: 'bindingSet', count: info.count };
  }
  return { category: 'container', value: info.value };
}

function sameMinimumEqualityDomain(left, right) {
  if (isValueSemanticsNumeric(left) && isValueSemanticsNumeric(right)) return true;
  if (left.category === 'container' || right.category === 'container') {
    return left.category === 'container'
      && right.category === 'container'
      && (left.containerKind ?? 'container') === (right.containerKind ?? 'container');
  }
  if (left.category === 'temporal' || right.category === 'temporal') {
    return left.category === 'temporal'
      && right.category === 'temporal'
      && sameTemporalDomain(left, right);
  }
  return left.category === right.category && [
    'string',
    'boolean',
    'toggle',
    'hex',
    'radix',
    'encoding',
    'separator',
    'symbol',
    'sansaAddress',
    'referenceForm',
  ].includes(left.category);
}

function sameMinimumOrderingDomain(left, right) {
  if (isValueSemanticsNumeric(left) && isValueSemanticsNumeric(right)) return true;
  if (left.category === 'temporal' || right.category === 'temporal') {
    return left.category === 'temporal'
      && right.category === 'temporal'
      && sameTemporalDomain(left, right);
  }
  return left.category === right.category && ['string', 'encoding', 'separator', 'sansaAddress'].includes(left.category);
}

function isValueSemanticsNumeric(info) {
  return info.category === 'finiteNumber' || info.category === 'positiveInfinity' || info.category === 'negativeInfinity';
}

function sameTemporalDomain(left, right) {
  return temporalSemanticType(left) === temporalSemanticType(right);
}

function temporalSemanticType(info) {
  return String(info.value?.semanticType ?? info.semanticType ?? 'temporal');
}

function compareMinimumEquality(operation, left, right, profile) {
  if (isValueSemanticsNumeric(left) && isValueSemanticsNumeric(right)) {
    const equals = compareMinimumNumeric(left, right) === 0;
    return operation === 'equal' ? equals : !equals;
  }
  const equals = (() => {
    if (left.category === 'string' && right.category === 'string') return profile.compareStrings(left.value, right.value) === 0;
    if (left.category === 'temporal' && right.category === 'temporal') return profile.compareTemporal(left.value, right.value) === 0;
    if (left.category === 'container' && right.category === 'container') return structurallyEqualContainers(left, right, profile);
    return structurallyEqualValues(left.value, right.value, profile);
  })();
  return operation === 'equal' ? equals : !equals;
}

function compareMinimumOrdering(left, right, profile) {
  if (isValueSemanticsNumeric(left) && isValueSemanticsNumeric(right)) {
    return compareMinimumNumeric(left, right);
  }
  if (left.category === 'temporal' && right.category === 'temporal') {
    return profile.compareTemporal(left.value, right.value);
  }
  if (left.category !== 'string' && ['encoding', 'separator', 'sansaAddress'].includes(left.category)) {
    return compareStringsByUnicodeScalarValue(String(left.value), String(right.value));
  }
  return comparePrimitiveOrderValues(left.value, right.value, profile);
}

function compareMinimumNumeric(left, right) {
  if (left.category === right.category && left.category !== 'finiteNumber') return 0;
  if (left.category === 'negativeInfinity' || right.category === 'positiveInfinity') return -1;
  if (left.category === 'positiveInfinity' || right.category === 'negativeInfinity') return 1;
  const comparison = compareExactFiniteNumbers(left.value, right.value);
  if (comparison === null) throw new Error('Invalid finite numeric value reached comparison');
  return comparison;
}

function compareExactFiniteNumbers(left, right) {
  const leftValue = parseExactFiniteNumber(String(left));
  const rightValue = parseExactFiniteNumber(String(right));
  if (leftValue === null || rightValue === null) return null;
  if (leftValue.sign !== rightValue.sign) return leftValue.sign < rightValue.sign ? -1 : 1;
  if (leftValue.sign === 0) return 0;

  const leftOrder = BigInt(leftValue.digits.length) + leftValue.scale;
  const rightOrder = BigInt(rightValue.digits.length) + rightValue.scale;
  let comparison;
  if (leftOrder !== rightOrder) {
    comparison = leftOrder < rightOrder ? -1 : 1;
  } else {
    const width = Math.max(leftValue.digits.length, rightValue.digits.length);
    const leftDigits = leftValue.digits.padEnd(width, '0');
    const rightDigits = rightValue.digits.padEnd(width, '0');
    comparison = leftDigits === rightDigits ? 0 : leftDigits < rightDigits ? -1 : 1;
  }
  return leftValue.sign === -1 ? -comparison : comparison;
}

function parseExactFiniteNumber(value) {
  if (value.length === 0 || value.length > MAX_EXACT_NUMERIC_CHARACTERS) return null;
  const match = /^([+-]?)(?:(0|[1-9]\d*)(?:\.(\d+))?|\.(\d+))(?:[eE]([+-]?\d+))?$/u.exec(value);
  if (match === null) return null;
  const integer = match[2] ?? '';
  const fraction = match[3] ?? match[4] ?? '';
  const digits = `${integer}${fraction}`.replace(/^0+/u, '');
  if (digits.length === 0) return { sign: 0, digits: '0', scale: 0n };
  return {
    sign: match[1] === '-' ? -1 : 1,
    digits,
    scale: BigInt(match[5] ?? '0') - BigInt(fraction.length),
  };
}

function compareRadixWithProfile(left, right, profile) {
  const leftBase = left.value.radixBase;
  const rightBase = right.value.radixBase;
  const resolvedLeftBase = leftBase ?? rightBase;
  const resolvedRightBase = rightBase ?? leftBase;
  if (resolvedLeftBase === undefined || resolvedRightBase === undefined) {
    return {
      ok: false,
      diagnostic: valueSemanticsDiagnostic(
        'radix_base_required',
        'Radix numeric comparison requires at least one operand with a resolved base',
      ),
    };
  }
  if (resolvedLeftBase !== resolvedRightBase && profile.radixComparison !== 'cross-base-exact') {
    return {
      ok: false,
      diagnostic: valueSemanticsDiagnostic(
        'mixed_radix_bases',
        `Radix numeric comparison requires the same base (${leftBase} vs ${rightBase})`,
      ),
    };
  }

  const value = profile.compareRadix(
    { payload: left.value.payload, base: resolvedLeftBase, semanticType: left.value.semanticType },
    { payload: right.value.payload, base: resolvedRightBase, semanticType: right.value.semanticType },
  );
  if (value === null) {
    return {
      ok: false,
      diagnostic: valueSemanticsDiagnostic(
        'invalid_radix_value',
        `Radix payload is invalid for base ${resolvedLeftBase} or ${resolvedRightBase}`,
      ),
    };
  }
  return { ok: true, value: normalizeComparison(value) };
}

function compareExactRadixSemanticValues(left, right) {
  if (left.base !== right.base) return null;
  return compareExactRadixValues(left.payload, right.payload, left.base);
}

function compareExactCrossBaseRadixSemanticValues(left, right) {
  return compareExactCrossBaseRadixValues(left.payload, left.base, right.payload, right.base);
}

function parseExactRadixValue(value, base) {
  if (!Number.isInteger(base) || base < 2 || base > 64) return null;
  if (value.length === 0 || value.length > MAX_EXACT_NUMERIC_CHARACTERS) return null;

  let index = 0;
  let sign = 1;
  if (value[index] === '+' || value[index] === '-') {
    sign = value[index] === '-' ? -1 : 1;
    index += 1;
  }
  if (index >= value.length) return null;

  const integerDigits = [];
  const fractionalDigits = [];
  let target = integerDigits;
  let sawPoint = false;
  let sawDigit = false;
  for (; index < value.length; index += 1) {
    const character = value[index];
    if (character === '.') {
      if (sawPoint || index === value.length - 1) return null;
      sawPoint = true;
      target = fractionalDigits;
      continue;
    }
    if (character === '_') {
      const previous = value[index - 1];
      const next = value[index + 1];
      if (radixDigitValue(previous) === null || radixDigitValue(next) === null) return null;
      continue;
    }
    const digit = radixDigitValue(character);
    if (digit === null || digit >= base) return null;
    target.push(digit);
    sawDigit = true;
  }
  if (!sawDigit || fractionalDigits.length === 0 && sawPoint) return null;

  let leadingZeroes = 0;
  while (leadingZeroes < integerDigits.length && integerDigits[leadingZeroes] === 0) leadingZeroes += 1;
  if (leadingZeroes > 0) integerDigits.splice(0, leadingZeroes);
  while (fractionalDigits.length > 0 && fractionalDigits.at(-1) === 0) fractionalDigits.pop();
  if (integerDigits.length === 0 && fractionalDigits.length === 0) sign = 0;
  return { sign, integerDigits, fractionalDigits };
}

function compareParsedRadixValues(left, right) {
  if (left.sign !== right.sign) return left.sign < right.sign ? -1 : 1;
  if (left.sign === 0) return 0;

  let comparison = 0;
  if (left.integerDigits.length !== right.integerDigits.length) {
    comparison = left.integerDigits.length < right.integerDigits.length ? -1 : 1;
  } else {
    comparison = compareRadixDigitArrays(left.integerDigits, right.integerDigits);
    if (comparison === 0) {
      const width = Math.max(left.fractionalDigits.length, right.fractionalDigits.length);
      for (let index = 0; index < width; index += 1) {
        const leftDigit = left.fractionalDigits[index] ?? 0;
        const rightDigit = right.fractionalDigits[index] ?? 0;
        if (leftDigit !== rightDigit) {
          comparison = leftDigit < rightDigit ? -1 : 1;
          break;
        }
      }
    }
  }
  return left.sign === -1 ? -comparison : comparison;
}

function compareParsedCrossBaseRadixValues(left, leftBase, right, rightBase) {
  if (left.sign !== right.sign) return left.sign < right.sign ? -1 : 1;
  if (left.sign === 0) return 0;

  const leftNumerator = radixDigitsToBigInt(
    [...left.integerDigits, ...left.fractionalDigits],
    leftBase,
  );
  const rightNumerator = radixDigitsToBigInt(
    [...right.integerDigits, ...right.fractionalDigits],
    rightBase,
  );
  const leftDenominator = BigInt(leftBase) ** BigInt(left.fractionalDigits.length);
  const rightDenominator = BigInt(rightBase) ** BigInt(right.fractionalDigits.length);
  const leftScaled = leftNumerator * rightDenominator;
  const rightScaled = rightNumerator * leftDenominator;
  const comparison = leftScaled < rightScaled ? -1 : leftScaled > rightScaled ? 1 : 0;
  return left.sign === -1 ? -comparison : comparison;
}

function radixDigitsToBigInt(digits, base) {
  if (digits.length === 0) return 0n;
  let chunkSize = 1;
  let fullChunkMultiplier = base;
  while (fullChunkMultiplier <= Math.floor(Number.MAX_SAFE_INTEGER / base)) {
    fullChunkMultiplier *= base;
    chunkSize += 1;
  }

  let result = 0n;
  for (let offset = 0; offset < digits.length; offset += chunkSize) {
    const length = Math.min(chunkSize, digits.length - offset);
    let chunkValue = 0;
    let multiplier = 1;
    for (let index = 0; index < length; index += 1) {
      chunkValue = chunkValue * base + digits[offset + index];
      multiplier *= base;
    }
    result = result * BigInt(multiplier) + BigInt(chunkValue);
  }
  return result;
}

function compareRadixDigitArrays(left, right) {
  for (let index = 0; index < left.length; index += 1) {
    if (left[index] < right[index]) return -1;
    if (left[index] > right[index]) return 1;
  }
  return 0;
}

function radixDigitValue(character) {
  if (typeof character !== 'string') return null;
  const codePoint = character.codePointAt(0);
  if (codePoint >= 48 && codePoint <= 57) return codePoint - 48;
  if (codePoint >= 65 && codePoint <= 90) return codePoint - 55;
  if (codePoint >= 97 && codePoint <= 122) return codePoint - 61;
  if (character === '&') return 62;
  if (character === '!') return 63;
  return null;
}

function normalizeRadixBase(value) {
  if (value === undefined || value === null) return undefined;
  if (!Number.isInteger(value) || value < 2 || value > 64) {
    throw new Error('radixBase must be an integer from 2 through 64');
  }
  return value;
}

function radixBaseFromSemanticType(semanticType) {
  if (typeof semanticType !== 'string') return undefined;
  const normalized = semanticType.trim().toLowerCase();
  if (normalized === 'decimal') return 10;
  const alias = /^radix(2|6|8|12)$/u.exec(normalized);
  if (alias !== null) return Number(alias[1]);
  const clarified = /^radix\[(\d+)\]$/u.exec(normalized);
  if (clarified === null) return undefined;
  const base = Number(clarified[1]);
  return Number.isInteger(base) && base >= 2 && base <= 64 ? base : undefined;
}

function normalizeValueSemanticsCategory(category) {
  if (category === 'sansa') return 'sansaAddress';
  if (category === 'cloneReference' || category === 'pointerReference') return 'referenceForm';
  if (['date', 'time', 'datetime', 'wtc'].includes(category)) return 'temporal';
  return category;
}

function sansaAddressSemanticValue(value) {
  if (typeof value === 'string') return value;
  if (value?.canonical !== undefined) return String(value.canonical);
  if (value?.address?.canonical !== undefined) return String(value.address.canonical);
  if (typeof value?.address === 'string') return value.address;
  return String(value ?? '');
}

function structurallyEqualContainers(left, right, profile) {
  if ((left.containerKind ?? 'container') !== (right.containerKind ?? 'container')) return false;
  return structurallyEqualValues(left.value, right.value, profile);
}

function structurallyEqualValues(left, right, profile) {
  const leftDescriptor = comparableScalarDescriptor(left);
  const rightDescriptor = comparableScalarDescriptor(right);
  if (leftDescriptor !== undefined || rightDescriptor !== undefined) {
    if (leftDescriptor === undefined || rightDescriptor === undefined) return false;
    const equality = evaluateValueSemanticsEquality('equal', leftDescriptor, rightDescriptor, profile);
    return equality.ok && equality.value;
  }
  if (Object.is(left, right)) return true;
  if (typeof left === 'string' && typeof right === 'string') return profile.compareStrings(left, right) === 0;
  if (typeof left !== 'object' || left === null || typeof right !== 'object' || right === null) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length) return false;
    return left.every((value, index) => structurallyEqualValues(value, right[index], profile));
  }
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  if (leftKeys.length !== rightKeys.length) return false;
  for (let index = 0; index < leftKeys.length; index += 1) {
    if (leftKeys[index] !== rightKeys[index]) return false;
    if (!structurallyEqualValues(left[leftKeys[index]], right[rightKeys[index]], profile)) return false;
  }
  return true;
}

function comparableScalarDescriptor(value) {
  if (typeof value !== 'object' || value === null) return undefined;
  return value[COMPARABLE_SCALAR_DESCRIPTOR_PROPERTY];
}

function isConcreteValueDescriptor(descriptor) {
  const info = valueDescriptorToScalarInfo(descriptor);
  return isConcreteValueScalar(info);
}

function isExplicitAbsenceScalar(info) {
  return info.kind === 'absence' || info.category === 'explicitAbsence';
}

function valueSemanticsDiagnostic(reason, message) {
  return {
    ok: false,
    outcome: 'diagnostic',
    reason,
    error: {
      code: `AEON_VALUE_SEMANTICS_${reason.toUpperCase()}`,
      reason,
      message,
    },
  };
}

function compareQueryScalars(operator, left, right, options = {}) {
  const leftDescriptor = scalarInfoToValueDescriptor(queryScalarToInfo(left));
  const rightDescriptor = scalarInfoToValueDescriptor(queryScalarToInfo(right));
  const operation = ['==', '!='].includes(operator) ? (operator === '==' ? 'equal' : 'notEqual') : 'compare';
  const evaluated = evaluateValueSemanticsOperation(operation, {
    left: leftDescriptor,
    right: rightDescriptor,
  }, {
    valueSemantics: options.valueSemantics,
  });
  if (!evaluated.ok) {
    return {
      ok: false,
      error: queryEvaluateError(
        'SANSA_QUERY_EVALUATE_INVALID_COMPARISON',
        queryComparisonMessage(evaluated.reason, operator, leftDescriptor, rightDescriptor),
      ),
    };
  }
  const value = (() => {
    if (operator === '==') return evaluated.value;
    if (operator === '!=') return evaluated.value;
    if (operator === '<') return evaluated.relation === 'less';
    if (operator === '<=') return evaluated.relation === 'less' || evaluated.relation === 'equal';
    if (operator === '>') return evaluated.relation === 'greater';
    if (operator === '>=') return evaluated.relation === 'greater' || evaluated.relation === 'equal';
    return false;
  })();
  return { ok: true, value: { type: 'scalar', value } };
}

function queryScalarToInfo(scalar) {
  if (scalar && typeof scalar === 'object' && Object.hasOwn(scalar, 'value')) {
    const metadata = scalar.metadata ?? {};
    return {
      value: scalar.value,
      ...(metadata.kind === undefined ? {} : { kind: metadata.kind }),
      ...(metadata.category === undefined ? {} : { category: metadata.category }),
      ...(metadata.semanticType === undefined ? {} : { semanticType: metadata.semanticType }),
      ...(metadata.containerKind === undefined ? {} : { containerKind: metadata.containerKind }),
      ...(metadata.nullReason === undefined ? {} : { nullReason: metadata.nullReason }),
      ...(metadata.numericLexeme === undefined ? {} : { numericLexeme: metadata.numericLexeme }),
      ...(metadata.radixBase === undefined ? {} : { radixBase: metadata.radixBase }),
      ...(metadata.radixScale === undefined ? {} : { radixScale: metadata.radixScale }),
    };
  }
  return { value: scalar };
}

function queryComparisonMessage(reason, operator, leftDescriptor, rightDescriptor) {
  if (reason === 'mixed_categories') {
    const categories = leftDescriptor?.category && rightDescriptor?.category
      ? ` (${leftDescriptor.category} vs ${rightDescriptor.category})`
      : '';
    return `Cross-type comparison is not supported${categories}`;
  }
  if (reason === 'not_equality_comparable') return 'NaN, null, and absence values are not equality-comparable in this evaluator slice';
  if (reason === 'not_orderable' && ['<', '<=', '>', '>='].includes(operator)) return 'Ordering comparison is not defined for this value category';
  if (reason === 'radix_base_required') return 'Radix numeric comparison requires a resolved base from at least one operand';
  if (reason === 'mixed_radix_bases') return 'Cross-base radix comparison is not enabled by this value-semantics profile';
  if (reason === 'invalid_radix_value') return 'Radix payload is invalid for its resolved base';
  return 'Invalid scalar comparison';
}

function expectBooleanQueryValue(value, namespace) {
  if (value.type === 'scalar' && typeof value.value === 'boolean') {
    return { ok: true, value: value.value };
  }
  if (value.type === 'bindingSet') {
    const scalar = expectScalarQueryValue(value, namespace);
    if (!scalar.ok) return scalar;
    if (typeof scalar.value === 'boolean') return { ok: true, value: scalar.value };
  }
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_EVALUATE_EXPECTED_BOOLEAN', 'Expected Boolean query value'),
  };
}

function expectScalarQueryValue(value, namespace) {
  if (value.type === 'scalar') {
    return { ok: true, value: value.value, metadata: value[QUERY_VALUE_METADATA_PROPERTY] };
  }
  if (value.type === 'bindingSet') {
    if (value.bindings.length === 0) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', 'Expected one binding but resolved none'),
      };
    }
    if (value.bindings.length > 1) {
      return {
        ok: false,
        error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', 'Expected one binding but resolved multiple bindings'),
      };
    }
    const scalar = getBindingScalarValue(namespace, value.bindings[0]);
    if (!scalar.ok) return scalar;
    return { ok: true, value: scalar.value, metadata: scalar.metadata };
  }
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_EVALUATE_EXPECTED_SCALAR', 'Expected scalar query value'),
  };
}

function expectComparableQueryValue(value, namespace) {
  if (value.type === 'object') {
    return {
      ok: true,
      value: value.value,
      metadata: { kind: 'container', category: 'container', containerKind: 'object' },
    };
  }
  if (value.type !== 'bindingSet') return expectScalarQueryValue(value, namespace);
  if (value.bindings.length === 0) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', 'Expected one binding but resolved none'),
    };
  }
  if (value.bindings.length > 1) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_CARDINALITY', 'Expected one binding but resolved multiple bindings'),
    };
  }
  return getBindingComparableValue(namespace, value.bindings[0]);
}

function unwrapQueryValue(value, namespace) {
  if (value.type === 'scalar') return { ok: true, value: value.value };
  if (value.type === 'object') return { ok: true, value: value.value };
  return expectScalarQueryValue(value, namespace);
}

function getBindingScalarValue(namespace, binding) {
  const info = getBindingScalarInfo(namespace, binding);
  if (!info.ok) return info;
  return { ok: true, value: info.value, metadata: scalarMetadataFromInfo(info) };
}

function getBindingComparableValue(namespace, binding) {
  const scalar = getBindingScalarValue(namespace, binding);
  if (scalar.ok && !(scalar.value === undefined && isContainerBinding(namespace, binding))) return scalar;
  if (!isContainerBinding(namespace, binding)) return scalar;
  const container = materializeContainerComparableValue(namespace, binding);
  if (!container.ok) return container;
  return {
    ok: true,
    value: container.value,
    metadata: {
      kind: 'container',
      category: 'container',
      containerKind: container.containerKind,
    },
  };
}

function materializeContainerComparableValue(namespace, binding, seen = new Set()) {
  if (seen.has(binding)) {
    return {
      ok: false,
      error: queryEvaluateError('SANSA_QUERY_EVALUATE_INVALID_COMPARISON', 'Cyclic containers are not structurally comparable'),
    };
  }
  seen.add(binding);
  const containerKind = containerKindFromBinding(namespace, binding) ?? 'container';
  const children = getChildren(namespace, binding);
  const positional = ['list', 'tuple'].includes(containerKind);

  if (positional) {
    const values = [];
    for (const child of children) {
      const childValue = materializeBindingComparableValue(namespace, child, seen);
      if (!childValue.ok) {
        seen.delete(binding);
        return childValue;
      }
      values.push(childValue.value);
    }
    seen.delete(binding);
    return { ok: true, value: values, containerKind };
  }

  if (containerKind === 'node') {
    const values = [];
    for (const child of children) {
      const childValue = materializeBindingComparableValue(namespace, child, seen);
      if (!childValue.ok) {
        seen.delete(binding);
        return childValue;
      }
      values.push(childValue.value);
    }
    const attributes = materializeAttributeComparableValue(namespace, binding, seen);
    if (!attributes.ok) {
      seen.delete(binding);
      return attributes;
    }
    const tag = getBindingNodeTag(namespace, binding);
    seen.delete(binding);
    return {
      ok: true,
      value: {
        ...(tag === undefined ? {} : { tag }),
        ...(attributes.value === undefined ? {} : { attributes: attributes.value }),
        children: values,
      },
      containerKind,
    };
  }

  const object = {};
  for (const child of children) {
    const name = getBindingName(namespace, child);
    if (typeof name !== 'string') continue;
    const childValue = materializeBindingComparableValue(namespace, child, seen);
    if (!childValue.ok) {
      seen.delete(binding);
      return childValue;
    }
    object[name] = childValue.value;
  }
  seen.delete(binding);
  return { ok: true, value: object, containerKind };
}

function materializeAttributeComparableValue(namespace, binding, seen) {
  const attributeSpace = getBindingAttributeSpace(namespace, binding);
  if (!attributeSpace) return { ok: true, value: undefined };
  const attributes = {};
  for (const attribute of getChildren(namespace, attributeSpace)) {
    const name = getBindingName(namespace, attribute);
    if (typeof name !== 'string') continue;
    const attributeValue = materializeBindingComparableValue(namespace, attribute, seen);
    if (!attributeValue.ok) return attributeValue;
    attributes[name] = attributeValue.value;
  }
  return { ok: true, value: attributes };
}

function materializeBindingComparableValue(namespace, binding, seen) {
  const scalar = getBindingScalarValue(namespace, binding);
  if (scalar.ok && !(scalar.value === undefined && isContainerBinding(namespace, binding))) {
    return {
      ok: true,
      value: {
        [COMPARABLE_SCALAR_DESCRIPTOR_PROPERTY]: scalarInfoToValueDescriptor(queryScalarToInfo(scalar)),
      },
    };
  }
  if (!isContainerBinding(namespace, binding)) return scalar;
  return materializeContainerComparableValue(namespace, binding, seen);
}

function getBindingScalarInfo(namespace, binding) {
  const kind = getBindingScalarKind(namespace, binding);
  const semanticType = getBindingSemanticType(namespace, binding);
  const nullReason = getBindingNullReason(namespace, binding);
  const numericLexeme = getBindingNumericLexeme(namespace, binding);
  const radixBase = getBindingRadixBase(namespace, binding);
  const radixScale = getBindingRadixScale(namespace, binding);
  if (typeof namespace.value === 'function') {
    const value = namespace.value(binding);
    if (value !== undefined) {
      return { ok: true, value, kind, semanticType, nullReason, numericLexeme, radixBase, radixScale };
    }
  }
  if (Object.hasOwn(binding, 'value') && binding.value !== undefined) {
    return { ok: true, value: binding.value, kind, semanticType, nullReason, numericLexeme, radixBase, radixScale };
  }
  if (Object.hasOwn(binding, 'scalar') && binding.scalar !== undefined) {
    return { ok: true, value: binding.scalar, kind, semanticType, nullReason, numericLexeme, radixBase, radixScale };
  }
  return {
    ok: false,
    error: queryEvaluateError('SANSA_QUERY_EVALUATE_MISSING_SCALAR', 'Binding does not expose a scalar value'),
  };
}

function containerKindFromBinding(namespace, binding) {
  const explicitKind = explicitContainerKindFromBinding(namespace, binding);
  if (explicitKind !== undefined) return explicitKind;
  if (Array.isArray(binding.children)) return 'container';
  return undefined;
}

function explicitContainerKindFromBinding(namespace, binding) {
  const rawKind = typeof namespace.representationKind === 'function'
    ? namespace.representationKind(binding)
    : binding.representationKind ?? binding.kind ?? binding.type ?? binding.literalKind ?? binding.valueKind;
  const kind = typeof rawKind === 'string' ? lowerFirst(rawKind) : undefined;
  if (['object', 'obj', 'o', 'envelope', 'objectNode'].includes(kind)) return 'object';
  if (['list', 'listNode'].includes(kind)) return 'list';
  if (['tuple', 'tupleLiteral'].includes(kind)) return 'tuple';
  if (['node', 'nodeLiteral'].includes(kind)) return 'node';
  return undefined;
}

function isContainerBinding(namespace, binding) {
  return containerKindFromBinding(namespace, binding) !== undefined;
}

const PORTABLE_SCALAR_QUERY_KINDS = new Map([
  ['StringLiteral', 'string'],
  ['NumberLiteral', 'number'],
  ['BooleanLiteral', 'boolean'],
  ['ToggleLiteral', 'toggle'],
  ['HexLiteral', 'hex'],
  ['RadixLiteral', 'radix'],
  ['EncodingLiteral', 'encoding'],
  ['SeparatorLiteral', 'separator'],
  ['SymbolicLiteral', 'symbol'],
  ['SansaAddressLiteral', 'sansaAddress'],
  ['DateLiteral', 'date'],
  ['TimeLiteral', 'time'],
  ['DateTimeLiteral', 'datetime'],
  ['WTCDateTimeLiteral', 'wtc'],
  ['NullLiteral', 'null'],
  ['NaNLiteral', 'nan'],
  ['InfinityLiteral', 'infinity'],
]);

function getBindingScalarKind(namespace, binding) {
  const actual = typeof namespace.representationKind === 'function'
    ? namespace.representationKind(binding)
    : binding.scalarKind ?? binding.valueKind ?? binding.literalKind ?? binding.representationKind ?? binding.kind ?? binding.type;
  return typeof actual === 'string'
    ? PORTABLE_SCALAR_QUERY_KINDS.get(actual) ?? lowerFirst(actual)
    : undefined;
}

function getBindingSemanticType(namespace, binding) {
  const actual = typeof namespace.semanticType === 'function'
    ? namespace.semanticType(binding)
    : binding.semanticType ?? binding.datatype;
  return typeof actual === 'string' ? actual : undefined;
}

function getBindingNullReason(namespace, binding) {
  if (typeof namespace.nullReason === 'function') return namespace.nullReason(binding);
  return binding.nullReason;
}

function getBindingNumericLexeme(namespace, binding) {
  if (typeof namespace.numericLexeme === 'function') return namespace.numericLexeme(binding);
  return typeof binding.numericLexeme === 'string' ? binding.numericLexeme : undefined;
}

function getBindingRadixBase(namespace, binding) {
  if (typeof namespace.radixBase === 'function') return namespace.radixBase(binding);
  if (Number.isInteger(binding.radixBase)) return binding.radixBase;
  return radixBaseFromSemanticType(getBindingSemanticType(namespace, binding));
}

function getBindingRadixScale(namespace, binding) {
  if (typeof namespace.radixScale === 'function') return namespace.radixScale(binding);
  if (Number.isInteger(binding.radixScale) && binding.radixScale >= 0) return binding.radixScale;
  const kind = getBindingScalarKind(namespace, binding);
  if (kind !== 'radix') return undefined;
  const value = typeof namespace.value === 'function'
    ? namespace.value(binding)
    : Object.hasOwn(binding, 'value') ? binding.value : binding.scalar;
  if (typeof value !== 'string') return undefined;
  return radixScaleOf(value, getBindingRadixBase(namespace, binding)) ?? undefined;
}

function getBindingNodeTag(namespace, binding) {
  if (typeof namespace.nodeTag === 'function') return namespace.nodeTag(binding);
  if (typeof namespace.tag === 'function') return namespace.tag(binding);
  return binding.nodeTag ?? binding.tag;
}

function getBindingAttributeSpace(namespace, binding) {
  if (typeof namespace.attributeSpace === 'function') return namespace.attributeSpace(binding);
  return binding.attributeSpace ?? binding.attributes;
}

function queryValueMetadata(value, namespace) {
  if (value.type === 'scalar') return value[QUERY_VALUE_METADATA_PROPERTY];
  if (value.type !== 'bindingSet' || value.bindings.length !== 1) return undefined;
  const info = getBindingScalarInfo(namespace, value.bindings[0]);
  return info.ok ? scalarMetadataFromInfo(info) : undefined;
}

function queryValueAddress(value) {
  if (value.type !== 'bindingSet' || value.bindings.length !== 1) return undefined;
  return getBindingAddress(value.bindings[0]);
}

function scalarMetadataFromInfo(info) {
  const metadata = {};
  if (info.kind !== undefined) metadata.kind = info.kind;
  if (info.semanticType !== undefined) metadata.semanticType = info.semanticType;
  if (info.nullReason !== undefined) metadata.nullReason = info.nullReason;
  if (info.numericLexeme !== undefined) metadata.numericLexeme = info.numericLexeme;
  if (info.radixBase !== undefined) metadata.radixBase = info.radixBase;
  if (info.radixScale !== undefined) metadata.radixScale = info.radixScale;
  return Object.keys(metadata).length > 0 ? metadata : undefined;
}

function applyResolveSelector(selector, bindings, namespace, selectorIndex, policy = {}) {
  switch (selector.type) {
    case 'childIdentity':
      return selectChildIdentity(namespace, bindings, selector, selectorIndex, policy);
    case 'member':
      return { ok: true, bindings: collectSelectedBindings(bindings, (binding) => iterateMembers(namespace, binding, selector.name), policy.maxBindings) };
    case 'position':
      return { ok: true, bindings: bindings.flatMap((binding) => selectPosition(namespace, binding, selector.index)) };
    case 'positionRange':
      return { ok: true, bindings: collectSelectedBindings(bindings, (binding) => iteratePositionRange(namespace, binding, selector.start, selector.end), policy.maxBindings) };
    case 'parent':
      return selectParents(namespace, bindings, selectorIndex, policy);
    case 'directExpansion':
      return { ok: true, bindings: collectSelectedBindings(bindings, (binding) => getChildren(namespace, binding), policy.maxBindings) };
    case 'descendantExpansion':
      return { ok: true, bindings: collectSelectedBindings(bindings, (binding) => iterateDescendants(namespace, binding), policy.maxBindings) };
    case 'namePattern': {
      const pattern = globPatternToRegExp(selector.pattern);
      return {
        ok: true,
        bindings: collectSelectedBindings(
          bindings,
          (binding) => iterateNamePatternMatches(namespace, binding, pattern),
          policy.maxBindings,
        ),
      };
    }
    case 'semanticTypeFilter':
      return { ok: true, bindings: bindings.filter((binding) => matchesSemanticType(namespace, binding, selector.name)) };
    case 'representationKindFilter':
      return { ok: true, bindings: bindings.filter((binding) => matchesRepresentationKind(namespace, binding, selector.name)) };
    case 'attributeSpace':
      return selectAttributeSpaces(namespace, bindings, selectorIndex);
    case 'localSpace':
      return selectLocalSpaces(namespace, bindings, selector.name, selectorIndex);
    default:
      return {
        ok: false,
        error: resolveError(
          'SANSA_RESOLVE_UNSUPPORTED_SELECTOR',
          `Unsupported SANSA selector type: ${selector.type}`,
          selectorIndex,
        ),
      };
  }
}

function selectChildIdentity(namespace, bindings, selector, selectorIndex, policy) {
  const output = [];
  for (const binding of bindings) {
    let match;
    const guard = policy.identityActivationGuard;
    if (guard) {
      const error = guard(binding);
      if (error) return {ok: false, error};
    }
    const children = typeof namespace.children === 'function' ? namespace.children(binding) ?? [] : binding.children ?? [];
    for (const child of children) {
      const budget = policy.identityBudget;
      if (budget.inspected >= policy.maxIdentityInspections) return { ok: false, error: resolveError('SANSA_RESOLVE_IDENTITY_LIMIT_EXCEEDED', 'Identity inspection limit exceeded', selectorIndex, { limit: policy.maxIdentityInspections, observed: budget.inspected + 1 }) };
      if (guard) {
        const error = guard(child);
        if (error) return {ok: false, error};
      }
      budget.inspected += 1;
      const identity = namespace.identity(child);
      if (identity !== undefined && (typeof identity !== 'string' || !CHILD_IDENTITY_RE.test(identity))) return { ok: false, error: resolveError('SANSA_RESOLVE_INVALID_IDENTITY', 'Adapter returned an invalid structural identity', selectorIndex) };
      if (identity === selector.identity) {
        if (match !== undefined) return { ok: false, error: resolveError('SANSA_RESOLVE_AMBIGUOUS_IDENTITY', 'Multiple children have the selected identity', selectorIndex, { identity }) };
        match = child;
      }
    }
    if (match !== undefined) {
      if (policy.maxBindings !== undefined && output.length >= policy.maxBindings) return { ok: false, error: resolveBindingLimitError(policy.maxBindings, output.length + 1, selectorIndex) };
      output.push(match);
    }
  }
  return { ok: true, bindings: output };
}

function selectMember(namespace, binding, name) {
  if (typeof namespace.member === 'function') {
    const selected = namespace.member(binding, name);
    return selected ? [selected] : [];
  }
  return getChildren(namespace, binding).filter((child) => getBindingName(namespace, child) === name);
}

function* iterateMembers(namespace, binding, name) {
  if (typeof namespace.member === 'function') {
    const selected = namespace.member(binding, name);
    if (selected) yield selected;
    return;
  }
  for (const child of getChildren(namespace, binding)) {
    if (getBindingName(namespace, child) === name) yield child;
  }
}

function selectPosition(namespace, binding, index) {
  if (typeof namespace.position === 'function') {
    const selected = namespace.position(binding, index);
    return selected ? [selected] : [];
  }
  const children = getChildren(namespace, binding);
  const indexed = children.find((child) => getBindingIndex(namespace, child) === index);
  if (indexed) return [indexed];
  return children[index] ? [children[index]] : [];
}

function* iteratePositionRange(namespace, binding, start, end) {
  const lower = start ?? 0;
  const upper = end ?? Number.POSITIVE_INFINITY;
  if (lower > upper) return;

  const children = getChildren(namespace, binding);
  for (let ordinal = 0; ordinal < children.length; ordinal += 1) {
    const child = children[ordinal];
    const explicitIndex = getBindingIndex(namespace, child);
    const position = Number.isInteger(explicitIndex) ? explicitIndex : ordinal;
    if (position >= lower && position <= upper) yield child;
  }
}

function selectParents(namespace, bindings, selectorIndex, policy) {
  if (policy.parentTraversal === 'forbid') {
    return {
      ok: false,
      error: resolveError(
        'SANSA_RESOLVE_PARENT_TRAVERSAL_FORBIDDEN',
        'Parent traversal is forbidden by resolver policy',
        selectorIndex,
      ),
    };
  }

  const rootBindings = bindings.filter((binding) => binding === policy.effectiveRoot);
  if (rootBindings.length > 0 && policy.failOnParentFromEffectiveRoot) {
    return {
      ok: false,
      error: resolveError(
        'SANSA_RESOLVE_BOUNDARY_ESCAPE_FORBIDDEN',
        'Parent traversal would escape the effective resolution root',
        selectorIndex,
      ),
    };
  }

  const traversable = bindings.filter((binding) => binding !== policy.effectiveRoot);
  if (traversable.length === 0) return { ok: true, bindings: [] };
  if (typeof namespace.parent === 'function') {
    return { ok: true, bindings: traversable.map((binding) => namespace.parent(binding)).filter(Boolean) };
  }
  if (traversable.some((binding) => Object.prototype.hasOwnProperty.call(binding, 'parent'))) {
    return { ok: true, bindings: traversable.map((binding) => binding.parent).filter(Boolean) };
  }
  if (traversable.length === 0) return { ok: true, bindings: [] };
  return {
    ok: false,
    error: resolveError(
      'SANSA_RESOLVE_UNSUPPORTED_PARENT',
      'The namespace does not expose parent traversal',
      selectorIndex,
    ),
  };
}

function selectAttributeSpaces(namespace, bindings, selectorIndex) {
  if (typeof namespace.attributeSpace !== 'function') {
    const selected = bindings
      .map((binding) => binding.attributeSpace ?? binding.attributes)
      .filter(Boolean);
    if (selected.length > 0 || bindings.length === 0) return { ok: true, bindings: selected };
    return {
      ok: false,
      error: resolveError(
        'SANSA_RESOLVE_UNSUPPORTED_ATTRIBUTE_SPACE',
        'The namespace does not expose attribute address-space traversal',
        selectorIndex,
      ),
    };
  }
  return {
    ok: true,
    bindings: bindings.map((binding) => namespace.attributeSpace(binding)).filter(Boolean),
  };
}

function selectLocalSpaces(namespace, bindings, name, selectorIndex) {
  if (typeof namespace.localSpace !== 'function') {
    return {
      ok: false,
      error: resolveError(
        'SANSA_RESOLVE_UNSUPPORTED_LOCAL_SPACE',
        `The namespace does not expose local address space '${name}'`,
        selectorIndex,
      ),
    };
  }
  return {
    ok: true,
    bindings: bindings.map((binding) => namespace.localSpace(binding, name)).filter(Boolean),
  };
}

function getChildren(namespace, binding) {
  if (typeof namespace.children === 'function') return Array.from(namespace.children(binding) ?? []);
  if (Array.isArray(binding.children)) return binding.children;
  return [];
}

function getDescendants(namespace, binding) {
  return Array.from(iterateDescendants(namespace, binding));
}

function* iterateDescendants(namespace, binding) {
  const stack = [...getChildren(namespace, binding)].reverse();
  while (stack.length > 0) {
    const child = stack.pop();
    yield child;
    const children = getChildren(namespace, child);
    for (let index = children.length - 1; index >= 0; index -= 1) stack.push(children[index]);
  }
}

function* iterateNamePatternMatches(namespace, binding, pattern) {
  for (const child of getChildren(namespace, binding)) {
    const name = getBindingName(namespace, child);
    if (typeof name === 'string' && pattern.test(name)) yield child;
  }
}

function collectSelectedBindings(bindings, select, maxBindings) {
  const output = [];
  const stopAt = maxBindings === undefined ? Number.POSITIVE_INFINITY : maxBindings + 1;
  for (const binding of bindings) {
    for (const selected of select(binding)) {
      output.push(selected);
      if (output.length >= stopAt) return output;
    }
  }
  return output;
}

function getBindingName(namespace, binding) {
  if (typeof namespace.name === 'function') return namespace.name(binding);
  return binding.name ?? binding.key ?? undefined;
}

function getBindingIndex(namespace, binding) {
  if (typeof namespace.index === 'function') return namespace.index(binding);
  return Number.isInteger(binding.index) ? binding.index : undefined;
}

function matchesSemanticType(namespace, binding, expected) {
  if (typeof namespace.semanticTypeMatches === 'function') return namespace.semanticTypeMatches(binding, expected) === true;
  const actual = typeof namespace.semanticType === 'function'
    ? namespace.semanticType(binding)
    : binding.semanticType ?? binding.datatype;
  if (actual === expected) return true;
  return typeof actual === 'string' && datatypeBaseName(actual) === expected;
}

function matchesRepresentationKind(namespace, binding, expected) {
  if (typeof namespace.representationKindMatches === 'function') return namespace.representationKindMatches(binding, expected) === true;
  const actual = typeof namespace.representationKind === 'function'
    ? namespace.representationKind(binding)
    : binding.representationKind ?? binding.kind ?? binding.type;
  return typeof actual === 'string' && (actual === expected || lowerFirst(actual) === expected);
}

function resolveBindingLimitError(limit, observed, selectorIndex) {
  return resolveError(
    'SANSA_RESOLVE_BINDING_LIMIT_EXCEEDED',
    `Resolve produced more than ${limit} bindings`,
    selectorIndex,
    { limit, observed },
  );
}

function resolveError(code, message, selectorIndex, details = {}) {
  return {
    code,
    message,
    ...(selectorIndex === undefined ? {} : { selectorIndex }),
    ...details,
  };
}

function queryEvaluateError(code, message, details = {}) {
  return { code, message, ...details };
}

function annotateQueryDiagnostic(error, details) {
  return {
    ...error,
    ...(details.phase === undefined ? {} : { phase: details.phase }),
    ...(details.candidateAddress === undefined ? {} : { candidateAddress: details.candidateAddress }),
  };
}

function getBindingAddress(binding) {
  return typeof binding.address === 'string' ? binding.address : undefined;
}

export function renderQualifierExpression(expression) {
  return expression.terms.map(renderQualifierTerm).join('|');
}

export function renderQualifierTerm(term) {
  let output = term.name;
  const parameterGroups = term.parameterGroups ?? (term.parameters.length > 0 ? [term.parameters] : []);
  for (const group of parameterGroups) {
    output += `<${group.map(renderQualifierTerm).join(',')}>`;
  }
  if (term.arguments.length > 0) {
    output += `[${term.arguments.map(renderQualifierArgument).join(',')}]`;
  }
  return output;
}

function renderQualifierArgument(argument) {
  if (argument.kind === 'token') return argument.value;
  if (argument.kind === 'number') return String(argument.value);
  return quotePayload(argument.value);
}

class AddressParser {
  constructor(input, options = {}) {
    this.input = input;
    this.options = options;
    this.index = 0;
    this.warnings = [];
    this.maxPositionIndex = normalizeMaxPositionIndex(options.maxPositionIndex);
  }

  parse() {
    if (this.input.length === 0) this.fail('Expected SANSA address root', 'SANSA_EMPTY_ADDRESS');
    const rootChar = this.peek();
    if (rootChar !== '$' && rootChar !== '?') {
      this.fail("Expected SANSA address root '$' or '?'", 'SANSA_EXPECTED_ROOT');
    }
    this.index += 1;

    const root = { type: 'root', kind: rootChar === '$' ? 'absolute' : 'contextual' };
    const selectors = [];
    let qualifierExpression = null;

    while (!this.atEnd()) {
      const char = this.peek();
      if (char === ':') {
        this.index += 1;
        if (this.atEnd()) this.fail('Expected qualifier expression', 'SANSA_EXPECTED_QUALIFIER');
        qualifierExpression = this.parseQualifierExpression();
        break;
      }
      if (char === '.') {
        selectors.push(this.parseDotSelector());
        continue;
      }
      if (char === '[') {
        selectors.push(this.parsePositionSelector());
        continue;
      }
      if (char === '#') {
        this.index += 1;
        selectors.push({ type: 'semanticTypeFilter', name: this.parseIdentifier('semantic type filter') });
        continue;
      }
      if (char === '%') {
        this.index += 1;
        selectors.push({ type: 'representationKindFilter', name: this.parseIdentifier('representation kind filter') });
        continue;
      }
      if (isLayout(char)) this.fail('Whitespace is not allowed inside a SANSA address', 'SANSA_UNEXPECTED_WHITESPACE');
      this.fail(`Unexpected character '${char}'`, 'SANSA_UNEXPECTED_CHARACTER');
    }

    this.expectEnd();
    const address = {
      type: 'SansaAddress',
      root,
      selectors,
      qualifierExpression,
      isExact: selectors.every(isExactSelector),
    };
    address.canonical = renderAddress(address);
    return address;
  }

  peekSyntax() { return this.peek(); }
  parseDotSelector() { return parseDotSelectorFromCursor(this); }
  parseChildIdentity() {
    this.index += 1;
    const start = this.index;
    while (!this.atEnd() && this.peek() !== '\\') {
      if (!/^[A-Za-z0-9_-]$/.test(this.peek())) this.fail('Expected structural identity name', 'SANSA_EXPECTED_IDENTITY');
      this.index += 1;
    }
    if (this.atEnd()) this.fail('Unterminated structural identity selector', 'SANSA_UNTERMINATED_IDENTITY');
    if (this.index === start) this.fail('Expected structural identity name', 'SANSA_EXPECTED_IDENTITY');
    const identity = this.input.slice(start, this.index++);
    return { type: 'childIdentity', identity };
  }
  parsePositionSelector() { return parsePositionSelectorFromCursor(this); }
  matchRangeSeparator() {
    if (!this.input.startsWith('..', this.index)) return false;
    this.index += 2;
    return true;
  }

  parseOptionalPositionIndex() {
    const start = this.index;
    while (isDigit(this.peek())) this.index += 1;
    if (this.index === start) return null;
    const raw = this.input.slice(start, this.index);
    const value = validatePositionIndex(raw, this.maxPositionIndex,
      (message, code) => this.fail(message, code, start));
    if (value > SANSA_MAX_POSITION_INDEX) {
      this.warn(
        `Position index ${value} exceeds the SANSA v1 portable index ceiling ${SANSA_MAX_POSITION_INDEX}`,
        'SANSA_NON_PORTABLE_POSITION_INDEX',
        start,
        { observed: value, portableFloor: SANSA_MAX_POSITION_INDEX },
      );
    }
    return value;
  }

  parseQualifierExpression(stopChar = '') {
    const terms = [this.parseQualifierTerm(stopChar)];
    while (!this.atEnd() && this.peek() === '|') {
      this.index += 1;
      terms.push(this.parseQualifierTerm(stopChar));
    }
    return { type: 'QualifierExpression', terms };
  }

  parseQualifierTerm(stopChar = '') {
    const name = this.parseIdentifier('qualifier type name');
    const parameters = [];
    const parameterGroups = [];
    const args = [];

    while (this.match('<')) {
      const group = [];
      group.push(this.parseQualifierTerm('>'));
      if (this.peek() === '|') {
        this.fail('Nested qualifier unions are not supported', 'SANSA_INVALID_QUALIFIER');
      }
      while (this.match(',')) {
        group.push(this.parseQualifierTerm('>'));
        if (this.peek() === '|') {
          this.fail('Nested qualifier unions are not supported', 'SANSA_INVALID_QUALIFIER');
        }
      }
      this.consume('>');
      parameterGroups.push(group);
      parameters.push(...group);
    }

    if (this.match('[')) {
      args.push(this.parseQualifierArgument());
      while (this.match(',')) {
        args.push(this.parseQualifierArgument());
      }
      this.consume(']');
      if (this.peek() === '[') {
        this.fail('Qualifier clarifiers must use a single bracketed list', 'SANSA_INVALID_QUALIFIER');
      }
    }

    const next = this.peek();
    if (next && !['|', ',', '>', stopChar].includes(next)) {
      this.fail(`Unexpected character '${next}' in qualifier expression`, 'SANSA_INVALID_QUALIFIER');
    }

    return { type: 'QualifierTerm', name, parameters, parameterGroups, arguments: args };
  }

  parseQualifierArgument() {
    if (this.peek() === '"') {
      return { kind: 'quoted', value: this.parseQuotedPayload() };
    }

    const start = this.index;
    while (!this.atEnd() && this.peek() !== ']' && this.peek() !== ',') {
      this.index += 1;
    }
    if (this.index === start) this.fail('Expected qualifier argument', 'SANSA_EXPECTED_QUALIFIER_ARGUMENT');
    const value = this.input.slice(start, this.index);
    if (!QUALIFIER_NUMBER_RE.test(value)) this.fail('Invalid qualifier argument', 'SANSA_INVALID_QUALIFIER_ARGUMENT');
    return { kind: 'number', value: Number(value) };
  }

  parseIdentifier(context) {
    const start = this.index;
    const first = this.peek();
    if (!isIdentifierStart(first)) this.fail(`Expected ${context}`, 'SANSA_EXPECTED_IDENTIFIER');
    this.index += 1;
    while (isIdentifierContinue(this.peek())) this.index += 1;
    return this.input.slice(start, this.index);
  }

  parseQuotedPayload() {
    this.consume('"');
    let output = '';
    while (!this.atEnd()) {
      const char = this.peek();
      if (char === '"') {
        this.index += 1;
        return output;
      }
      if (char === '\n' || char === '\r') {
        this.fail('Quoted payloads must not contain raw newlines', 'SANSA_RAW_NEWLINE_IN_QUOTED_PAYLOAD');
      }
      if (char === '\\') {
        output += this.parseEscape();
        continue;
      }
      output += char;
      this.index += 1;
    }
    this.fail('Unterminated quoted payload', 'SANSA_UNTERMINATED_QUOTED_PAYLOAD');
  }

  parseEscape() {
    this.consume('\\');
    const escape = this.peek();
    if (!escape) this.fail('Unterminated escape sequence', 'SANSA_UNTERMINATED_ESCAPE');
    this.index += 1;
    switch (escape) {
      case '\\': return '\\';
      case '"': return '"';
      case "'": return "'";
      case '`': return '`';
      case 'n': return '\n';
      case 'r': return '\r';
      case 't': return '\t';
      case 'b': return '\b';
      case 'f': return '\f';
      case 'u':
        return this.parseUnicodeEscape();
      default:
        this.fail(`Invalid escape sequence \\${escape}`, 'SANSA_INVALID_ESCAPE', this.index - 2);
    }
  }

  parseUnicodeEscape() {
    if (this.match('{')) {
      const start = this.index;
      while (!this.atEnd() && this.peek() !== '}') this.index += 1;
      if (this.atEnd()) this.fail('Unterminated Unicode escape', 'SANSA_UNTERMINATED_UNICODE_ESCAPE');
      const raw = this.input.slice(start, this.index);
      this.consume('}');
      if (!/^[0-9A-Fa-f]{1,6}$/.test(raw)) this.fail('Invalid Unicode escape', 'SANSA_INVALID_UNICODE_ESCAPE', start);
      return codePointToString(Number.parseInt(raw, 16), start);
    }

    const raw = this.input.slice(this.index, this.index + 4);
    if (!/^[0-9A-Fa-f]{4}$/.test(raw)) this.fail('Invalid Unicode escape', 'SANSA_INVALID_UNICODE_ESCAPE');
    this.index += 4;
    return codePointToString(Number.parseInt(raw, 16), this.index - 4);
  }

  expectEnd() {
    if (!this.atEnd()) this.fail(`Unexpected trailing character '${this.peek()}'`, 'SANSA_TRAILING_INPUT');
  }

  consume(char) {
    if (this.peek() !== char) this.fail(`Expected '${char}'`, 'SANSA_EXPECTED_TOKEN');
    this.index += 1;
  }

  match(char) {
    if (this.peek() !== char) return false;
    this.index += 1;
    return true;
  }

  peek() {
    return this.input[this.index] ?? '';
  }

  atEnd() {
    return this.index >= this.input.length;
  }

  fail(message, code, index = this.index) {
    throw new SansaParseError(message, index, code);
  }

  warn(message, code, index = this.index, extra = {}) {
    this.warnings.push({ code, message, index, ...extra });
  }
}

class InstructionParser {
  constructor(input, options = {}) {
    this.input = String(input);
    this.options = options;
    this.warnings = [];
  }

  parse() {
    const source = stripInstructionComments(this.input);
    if (source.trim().length === 0) {
      this.fail('Expected SANSA instruction', 'SANSA_INSTRUCTION_EMPTY', 0);
    }

    const clauses = scanInstructionClauses(source);
    const first = clauses[0];
    if (!first || source.slice(0, first.start).trim().length > 0) {
      this.fail('Expected SANSA instruction mutation verb', 'SANSA_INSTRUCTION_EXPECTED_MUTATION', 0);
    }

    const unsupported = clauses.find((clause) => clause.category === 'unsupportedQuery');
    if (unsupported) {
      this.fail(
        `Unsupported SANSA instruction clause '${unsupported.label}'`,
        'SANSA_INSTRUCTION_UNSUPPORTED_QUERY_CLAUSE',
        unsupported.start,
      );
    }

    const deferred = clauses.find((clause) => clause.category === 'deferredVerb');
    if (deferred) {
      this.fail(
        `Unsupported or deferred SANSA instruction verb '${deferred.label}'`,
        'SANSA_INSTRUCTION_UNSUPPORTED_VERB',
        deferred.start,
      );
    }

    const mutationClauses = clauses.filter((clause) => clause.category === 'mutation');
    if (mutationClauses.length === 0) {
      this.fail('Expected SANSA instruction mutation verb', 'SANSA_INSTRUCTION_EXPECTED_MUTATION', source.length);
    }
    if (mutationClauses.length > 1) {
      this.fail('SANSA instruction must contain exactly one mutation verb', 'SANSA_INSTRUCTION_MULTIPLE_MUTATION_VERBS', mutationClauses[1].start);
    }

    const seen = new Set();
    for (const clause of clauses) {
      if (clause.category !== 'query' && clause.category !== 'metadata') continue;
      if (clause.name === 'require') continue;
      if (seen.has(clause.name)) {
        this.fail(`Duplicate SANSA instruction clause '${clause.label}'`, 'SANSA_INSTRUCTION_DUPLICATE_CLAUSE', clause.start);
      }
      seen.add(clause.name);
    }

    const mutationClause = mutationClauses[0];
    const order = new Map([['because', 0], ['by', 1], ['from', 2], ['where', 3], ['require', 4], [mutationClause.name, 5]]);
    let previousOrder = -1;
    for (const clause of clauses) {
      const currentOrder = order.get(clause.name);
      if (currentOrder === undefined) continue;
      if (currentOrder < previousOrder) {
        this.fail(`SANSA instruction clause '${clause.label}' is out of order`, 'SANSA_INSTRUCTION_INVALID_CLAUSE_ORDER', clause.start);
      }
      previousOrder = currentOrder;
    }

    const clauseByName = new Map(clauses.map((clause) => [clause.name, clause]));
    const provenance = this.parseProvenanceClauses(clauseByName);
    const from = clauseByName.has('from') ? this.parseFromClause(clauseByName.get('from')) : null;
    const where = clauseByName.has('where') ? this.parseWhereClause(clauseByName.get('where')) : null;
    const requires = clauses
      .filter((clause) => clause.name === 'require')
      .map((clause) => this.parseRequireClause(clause));
    const mutation = this.parseMutationClause(mutationClause);
    const instruction = {
      type: 'SansaInstruction',
      provenance,
      from,
      where,
      requires,
      mutation,
      clauses: clauses.filter((clause) => clause.category !== 'unsupportedQuery').map((clause) => clause.name),
    };
    instruction.canonical = renderInstruction(instruction);
    return instruction;
  }

  parseFromClause(clause) {
    const body = clause.body.trim();
    if (body.length === 0) {
      this.fail("Expected SANSA address after 'from'", 'SANSA_INSTRUCTION_EXPECTED_FROM_ADDRESS', clause.bodyStart);
    }
    const address = this.parseAddress(body, clause.bodyStart + clause.body.indexOf(body));
    return { type: 'fromClause', source: 'address', address: address.address };
  }

  parseProvenanceClauses(clauseByName) {
    return {
      ...(clauseByName.has('because') ? { reason: this.parseMetadataTextClause(clauseByName.get('because'), 'because', 'SANSA_INSTRUCTION_EXPECTED_BECAUSE_TEXT') } : {}),
      ...(clauseByName.has('by') ? { claimedAuthor: this.parseMetadataTextClause(clauseByName.get('by'), 'by', 'SANSA_INSTRUCTION_EXPECTED_BY_TEXT') } : {}),
    };
  }

  parseMetadataTextClause(clause, label, code) {
    const body = clause.body.trim();
    if (body.length === 0) {
      this.fail(`Expected quoted text after '${label}'`, code, clause.bodyStart);
    }
    const parser = new AddressParser(body, this.options.address ?? this.options);
    try {
      const value = parser.parseQuotedPayload();
      parser.expectEnd();
      return value;
    } catch (error) {
      if (error instanceof SansaParseError) {
        this.fail(`Expected quoted text after '${label}'`, code, clause.bodyStart + clause.body.indexOf(body) + error.index);
      }
      throw error;
    }
  }

  parseWhereClause(clause) {
    return this.parseQueryExpressionClause(clause, 'whereClause', 'where');
  }

  parseRequireClause(clause) {
    return this.parseQueryExpressionClause(clause, 'requireClause', 'require');
  }

  parseQueryExpressionClause(clause, type, label) {
    const expression = normalizeQueryExpression(clause.body);
    if (expression.length === 0) {
      this.fail(
        `Expected expression after '${label}'`,
        label === 'require' ? 'SANSA_INSTRUCTION_EXPECTED_REQUIRE_EXPRESSION' : 'SANSA_INSTRUCTION_EXPECTED_WHERE_EXPRESSION',
        clause.bodyStart,
      );
    }
    const result = parseQueryExpression(expression, this.expressionOptions());
    if (!result.ok) {
      const first = result.errors[0];
      this.fail(first.message, first.code, clause.bodyStart + clause.body.indexOf(expression) + first.index);
    }
    this.warnings.push(...result.warnings);
    return { type, expression: renderQueryExpression(result.expression), ast: result.expression };
  }

  parseMutationClause(clause) {
    switch (clause.name) {
      case 'create':
        return this.parseCreateClause(clause);
      case 'replace':
        return this.parseReplaceClause(clause);
      case 'remove':
        return this.parseRemoveClause(clause);
      case 'insert':
        return this.parseInsertClause(clause);
      case 'append':
        return this.parseAppendClause(clause);
      case 'move':
        return this.parseMoveClause(clause);
      default:
        this.fail(`Unsupported SANSA instruction verb '${clause.label}'`, 'SANSA_INSTRUCTION_UNSUPPORTED_VERB', clause.start);
    }
  }

  parseCreateClause(clause) {
    const withIndex = findTopLevelInstructionKeyword(clause.body, 'with');
    if (withIndex < 0) {
      this.fail("Expected 'with' in create instruction", 'SANSA_INSTRUCTION_EXPECTED_WITH', clause.bodyStart);
    }
    const destinationSource = clause.body.slice(0, withIndex).trim();
    const valueSource = clause.body.slice(withIndex + 'with'.length);
    const destination = this.parseCreateDestination(destinationSource, clause.bodyStart + clause.body.indexOf(destinationSource));
    const value = this.parseInstructionValue(valueSource, clause.bodyStart + withIndex + 'with'.length);
    return { type: 'mutationClause', verb: 'create', destination, value };
  }

  parseReplaceClause(clause) {
    const withIndex = findTopLevelInstructionKeyword(clause.body, 'with');
    if (withIndex < 0) {
      this.fail("Expected 'with' in replace instruction", 'SANSA_INSTRUCTION_EXPECTED_WITH', clause.bodyStart);
    }
    const targetSource = clause.body.slice(0, withIndex).trim();
    const valueSource = clause.body.slice(withIndex + 'with'.length);
    const target = this.parseAddress(targetSource, clause.bodyStart + clause.body.indexOf(targetSource));
    const value = this.parseInstructionValue(valueSource, clause.bodyStart + withIndex + 'with'.length);
    return { type: 'mutationClause', verb: 'replace', target, value };
  }

  parseRemoveClause(clause) {
    const targetSource = clause.body.trim();
    if (targetSource.length === 0) {
      this.fail("Expected address after 'remove'", 'SANSA_INSTRUCTION_EXPECTED_ADDRESS', clause.bodyStart);
    }
    return {
      type: 'mutationClause',
      verb: 'remove',
      target: this.parseAddress(targetSource, clause.bodyStart + clause.body.indexOf(targetSource)),
    };
  }

  parseInsertClause(clause) {
    const withIndex = findTopLevelInstructionKeyword(clause.body, 'with');
    if (withIndex < 0) {
      this.fail("Expected 'with' in insert instruction", 'SANSA_INSTRUCTION_EXPECTED_WITH', clause.bodyStart);
    }
    const beforeValue = clause.body.slice(0, withIndex);
    const inIndex = findTopLevelInstructionKeyword(beforeValue, 'in');
    if (inIndex < 0) {
      this.fail("Expected 'in' in insert instruction", 'SANSA_INSTRUCTION_EXPECTED_IN', clause.bodyStart);
    }
    const placementSource = beforeValue.slice(0, inIndex).trim();
    const containerSource = beforeValue.slice(inIndex + 'in'.length).trim();
    const valueSource = clause.body.slice(withIndex + 'with'.length);
    return {
      type: 'mutationClause',
      verb: 'insert',
      placement: this.parsePlacement(placementSource, clause.bodyStart + beforeValue.indexOf(placementSource)),
      container: this.parseAddress(containerSource, clause.bodyStart + inIndex + 'in'.length + beforeValue.slice(inIndex + 'in'.length).indexOf(containerSource)),
      value: this.parseInstructionValue(valueSource, clause.bodyStart + withIndex + 'with'.length),
    };
  }

  parseAppendClause(clause) {
    const withIndex = findTopLevelInstructionKeyword(clause.body, 'with');
    if (withIndex < 0) {
      this.fail("Expected 'with' in append instruction", 'SANSA_INSTRUCTION_EXPECTED_WITH', clause.bodyStart);
    }
    let containerSource = clause.body.slice(0, withIndex).trim();
    if (containerSource.startsWith('in') && isInstructionClauseBoundaryAfter(containerSource, 'in'.length)) {
      containerSource = containerSource.slice('in'.length).trim();
    }
    if (containerSource.length === 0) {
      this.fail("Expected container address after 'append'", 'SANSA_INSTRUCTION_EXPECTED_ADDRESS', clause.bodyStart);
    }
    const valueSource = clause.body.slice(withIndex + 'with'.length);
    return {
      type: 'mutationClause',
      verb: 'insert',
      placement: { type: 'placement', kind: 'last' },
      container: this.parseAddress(containerSource, clause.bodyStart + clause.body.indexOf(containerSource)),
      value: this.parseInstructionValue(valueSource, clause.bodyStart + withIndex + 'with'.length),
    };
  }

  parseMoveClause(clause) {
    const body = clause.body;
    const first = readInstructionToken(body, 0);
    if (!first.token) {
      this.fail("Expected source address after 'move'", 'SANSA_INSTRUCTION_EXPECTED_ADDRESS', clause.bodyStart);
    }
    const source = this.parseAddress(first.token, clause.bodyStart + first.start);
    const rest = body.slice(first.end);
    const inIndex = findTopLevelInstructionKeyword(rest, 'in');
    if (inIndex < 0) {
      this.fail("Expected 'in' in move instruction", 'SANSA_INSTRUCTION_EXPECTED_IN', clause.bodyStart + first.end);
    }
    const placementSource = rest.slice(0, inIndex).trim();
    const containerSource = rest.slice(inIndex + 'in'.length).trim();
    return {
      type: 'mutationClause',
      verb: 'move',
      source,
      placement: this.parsePlacement(placementSource, clause.bodyStart + first.end + rest.indexOf(placementSource)),
      container: this.parseAddress(containerSource, clause.bodyStart + first.end + inIndex + 'in'.length + rest.slice(inIndex + 'in'.length).indexOf(containerSource)),
    };
  }

  parsePlacement(source, offset) {
    if (source === 'first' || source === 'last') {
      return { type: 'placement', kind: source };
    }
    const first = readInstructionToken(source, 0);
    if (first.token !== 'before' && first.token !== 'after') {
      this.fail("Expected placement 'first', 'last', 'before <address>', or 'after <address>'", 'SANSA_INSTRUCTION_INVALID_PLACEMENT', offset);
    }
    const anchorSource = source.slice(first.end).trim();
    if (anchorSource.length === 0) {
      this.fail(`Expected anchor address after '${first.token}'`, 'SANSA_INSTRUCTION_EXPECTED_ADDRESS', offset + first.end);
    }
    return {
      type: 'placement',
      kind: first.token,
      anchor: this.parseAddress(anchorSource, offset + source.indexOf(anchorSource)),
    };
  }

  parseCreateDestination(source, offset) {
    if (source.length === 0) {
      this.fail("Expected create destination before 'with'", 'SANSA_INSTRUCTION_EXPECTED_CREATE_DESTINATION', offset);
    }
    if (IDENTIFIER_RE.test(source)) {
      return { type: 'createDestination', kind: 'member', name: source, canonical: source };
    }
    if (source.startsWith('"')) {
      const parser = new AddressParser(source, this.addressOptions());
      const name = parser.parseQuotedPayload();
      while (isLayout(source[parser.index] ?? '')) parser.index += 1;
      if (!parser.atEnd()) {
        this.fail('Unexpected token after quoted create member name', 'SANSA_INSTRUCTION_INVALID_CREATE_DESTINATION', offset + parser.index);
      }
      this.warnings.push(...parser.warnings);
      if (name.length === 0) {
        this.fail('Create member name must not be empty', 'SANSA_INSTRUCTION_INVALID_CREATE_DESTINATION', offset);
      }
      return { type: 'createDestination', kind: 'member', name, canonical: quotePayload(name) };
    }
    const address = this.parseAddress(source, offset);
    return { type: 'createDestination', kind: 'address', address: address.address, canonical: renderInstructionAddress(address.address) };
  }

  parseInstructionValue(source, offset, context = {}) {
    const trimmedStart = firstNonLayoutOffset(source);
    const trimmed = source.trim();
    const valueOffset = offset + trimmedStart;
    if (trimmed.length === 0) {
      this.fail('Expected instruction value', 'SANSA_INSTRUCTION_EXPECTED_VALUE', offset);
    }

    let datatype;
    let payload = trimmed;
    let payloadOffset = valueOffset;
    if (trimmed.startsWith(':')) {
      const datatypeToken = readInstructionDatatypeToken(trimmed, 1);
      if (!datatypeToken.token) {
        this.fail('Expected datatype annotation after colon', 'SANSA_INSTRUCTION_INVALID_DATATYPE', valueOffset + 1);
      }
      datatype = this.parseDatatypeIntent(datatypeToken.token, valueOffset + 1);
      let cursor = datatypeToken.end;
      while (isLayout(trimmed[cursor] ?? '')) cursor += 1;
      if (trimmed[cursor] === ',') {
        cursor += 1;
        while (isLayout(trimmed[cursor] ?? '')) cursor += 1;
      }
      payload = trimmed.slice(cursor).trim();
      payloadOffset = valueOffset + cursor + firstNonLayoutOffset(trimmed.slice(cursor));
      if (payload.length === 0) {
        this.fail('Expected instruction value after datatype annotation', 'SANSA_INSTRUCTION_EXPECTED_VALUE', valueOffset + cursor);
      }
      if (payload.startsWith(',') || payload.endsWith(',')) {
        this.fail(
          'Comma delimiter may appear only once between datatype annotation and instruction value',
          'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL',
          payload.startsWith(',') ? payloadOffset : valueOffset + cursor + trimmed.slice(cursor).lastIndexOf(','),
        );
      }
    }
    const literal = this.parseValueLiteral(payload, payloadOffset);
    if (datatype !== undefined) {
      this.validateInstructionValueIntent(datatype, literal.kind, valueOffset, { nested: context.nested === true });
    }
    if (datatype !== undefined && context.nested === true) {
      this.warnings.push({
        code: 'SANSA_INSTRUCTION_NESTED_VALUE_INTENT_FLATTENED',
        message: 'Nested datatype intent is preserved in Instruction source but flattened out of conservative Mutate plans',
        index: valueOffset,
        datatype,
      });
    } else if (context.nested === true && nestedInstructionLiteralKindFlattens(literal.kind)) {
      this.warnings.push({
        code: 'SANSA_INSTRUCTION_NESTED_VALUE_REPRESENTATION_FLATTENED',
        message: 'Nested literal representation family is preserved in Instruction source but flattened out of conservative Mutate plans',
        index: valueOffset,
        kind: literal.kind,
      });
    }

    return {
      type: 'InstructionValue',
      datatype,
      kind: literal.kind,
      value: literal.value,
      literal,
      canonical: `${datatype === undefined ? '' : `:${datatype}, `}${literal.canonical}`,
    };
  }

  validateInstructionValueIntent(datatype, literalKind, index, context = {}) {
    const datatypeRepresentation = representationKindFromMutationName(datatype, { allowUnknown: false });
    const literalRepresentation = representationKindFromMutationName(literalKind, { allowUnknown: false });
    if (datatypeRepresentation === undefined || literalRepresentation === undefined) return;
    if (['cloneReference', 'pointerReference', 'referenceForm'].includes(literalRepresentation)) return;
    if (datatypeRepresentation === literalRepresentation) return;
    this.fail(
      `${context.nested === true ? 'Nested datatype' : 'Datatype'} '${datatype}' is not compatible with ${literalRepresentation} literal representation`,
      context.nested === true ? 'SANSA_INSTRUCTION_NESTED_VALUE_INTENT_MISMATCH' : 'SANSA_INSTRUCTION_VALUE_INTENT_MISMATCH',
      index,
    );
  }

  parseValueLiteral(source, offset) {
    if (source.startsWith('{')) return this.parseObjectValueLiteral(source, offset);
    if (source.startsWith('[')) return this.parseListValueLiteral(source, offset);
    if (source.startsWith('(')) return this.parseTupleValueLiteral(source, offset);
    if (source.startsWith('<')) return this.parseNodeValueLiteral(source, offset);
    if (source.startsWith('~')) return this.parseReferenceValueLiteral(source, offset);
    if (source.startsWith('$') || source.startsWith('?')) {
      const address = this.parseAddress(source, offset).address;
      return {
        type: 'instructionValueLiteral',
        kind: 'sansa',
        value: renderAddress(address),
        address,
        canonical: renderAddress(address),
      };
    }
    const result = parseQueryExpression(source, this.expressionOptions());
    if (!result.ok) {
      const first = result.errors[0];
      this.fail(first.message, first.code, offset + first.index);
    }
    if (result.expression.type !== 'literalExpression') {
      this.fail('Instruction value must be a literal payload', 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL', offset);
    }
    this.warnings.push(...result.warnings);
    return {
      type: 'instructionValueLiteral',
      kind: result.expression.kind,
      value: result.expression.kind === 'null'
        ? result.expression.nullReason
        : result.expression.value,
      expression: result.expression,
      canonical: renderQueryExpression(result.expression),
    };
  }

  parseObjectValueLiteral(source, offset) {
    const body = unwrapInstructionDelimitedLiteral(source, '{', '}', offset);
    const seen = new Set();
    const fields = splitInstructionObjectFields(body).map((field) => {
      if (seen.has(field.name)) {
        this.fail(
          `Duplicate object field '${field.name}' in instruction value`,
          'SANSA_INSTRUCTION_DUPLICATE_OBJECT_FIELD',
          offset + 1 + field.nameOffset,
        );
      }
      seen.add(field.name);
      const value = this.parseInstructionValue(field.expression, offset + 1 + field.expressionOffset, { nested: true });
      return { name: field.name, canonicalName: field.canonicalName, value };
    });
    return {
      type: 'instructionValueLiteral',
      kind: 'object',
      value: Object.fromEntries(fields.map((field) => [field.name, field.value.value])),
      fields,
      canonical: `{ ${fields.map((field) => `${field.canonicalName} = ${field.value.canonical}`).join(' ')} }`,
    };
  }

  parseListValueLiteral(source, offset) {
    const body = unwrapInstructionDelimitedLiteral(source, '[', ']', offset);
    const items = parseInstructionValueItems(body, offset + 1, this);
    return {
      type: 'instructionValueLiteral',
      kind: 'list',
      value: items.map((item) => item.value),
      items,
      canonical: `[${items.map((item) => item.canonical).join(', ')}]`,
    };
  }

  parseTupleValueLiteral(source, offset) {
    const body = unwrapInstructionDelimitedLiteral(source, '(', ')', offset);
    const items = parseInstructionValueItems(body, offset + 1, this);
    return {
      type: 'instructionValueLiteral',
      kind: 'tuple',
      value: items.map((item) => item.value),
      items,
      canonical: `(${items.map((item) => item.canonical).join(', ')})`,
    };
  }

  parseNodeValueLiteral(source, offset) {
    const body = unwrapInstructionDelimitedLiteral(source, '<', '>', offset).trim();
    if (body.length === 0) {
      this.fail('Expected node tag in instruction node value', 'SANSA_INSTRUCTION_INVALID_NODE_LITERAL', offset + 1);
    }
    let cursor = 0;
    if (!isIdentifierStart(body[cursor])) {
      this.fail('Expected node tag in instruction node value', 'SANSA_INSTRUCTION_INVALID_NODE_LITERAL', offset + 1);
    }
    cursor += 1;
    while (isIdentifierContinue(body[cursor] ?? '')) cursor += 1;
    const tag = body.slice(0, cursor);
    while (isLayout(body[cursor] ?? '')) cursor += 1;
    let children = [];
    if (cursor < body.length) {
      if (body[cursor] !== '(') {
        this.fail('Expected node children after instruction node tag', 'SANSA_INSTRUCTION_INVALID_NODE_LITERAL', offset + 1 + cursor);
      }
      const childSource = body.slice(cursor);
      const childBody = unwrapInstructionDelimitedLiteral(childSource, '(', ')', offset + 1 + cursor);
      children = parseInstructionValueItems(childBody, offset + 1 + cursor + 1, this);
    }
    return {
      type: 'instructionValueLiteral',
      kind: 'node',
      value: { tag, children: children.map((child) => child.value) },
      tag,
      children,
      canonical: `<${tag}${children.length === 0 ? '' : `(${children.map((child) => child.canonical).join(', ')})`}>`,
    };
  }

  parseReferenceValueLiteral(source, offset) {
    const pointer = source.startsWith('~>');
    const target = pointer ? source.slice(2) : source.slice(1);
    if (target.length === 0 || target.trim() !== target || /\s/.test(target)) {
      this.fail('Invalid reference literal', 'SANSA_INSTRUCTION_INVALID_REFERENCE_LITERAL', offset);
    }
    return {
      type: 'instructionValueLiteral',
      kind: pointer ? 'pointerReference' : 'cloneReference',
      value: target,
      canonical: `${pointer ? '~>' : '~'}${target}`,
    };
  }

  parseDatatypeIntent(source, offset) {
    try {
      const parser = new AddressParser(source, this.addressOptions());
      const expression = parser.parseQualifierExpression();
      if (!parser.atEnd()) {
        this.fail('Unexpected token in datatype annotation', 'SANSA_INSTRUCTION_INVALID_DATATYPE', offset + parser.index);
      }
      this.warnings.push(...parser.warnings);
      return renderQualifierExpression(expression);
    } catch (error) {
      if (error instanceof SansaParseError) {
        this.fail(error.message, 'SANSA_INSTRUCTION_INVALID_DATATYPE', offset + error.index);
      }
      throw error;
    }
  }

  parseAddress(source, offset) {
    const normalized = normalizeInstructionAddressSource(source);
    if (!normalized.ok) {
      this.fail(normalized.message, normalized.code, offset);
    }
    const result = parseAddress(normalized.source, this.addressOptions());
    if (!result.ok) {
      const first = result.errors[0];
      const adjustment = normalized.adjustment ?? 0;
      this.fail(first.message, first.code, offset + first.index + adjustment);
    }
    this.warnings.push(...result.warnings);
    return {
      type: 'instructionAddress',
      source,
      address: result.address,
      canonical: renderInstructionAddress(result.address),
    };
  }

  addressOptions() {
    return this.options.address ?? {};
  }

  expressionOptions() {
    if (this.options.expression) return this.options.expression;
    return { address: this.addressOptions() };
  }

  fail(message, code, index) {
    throw new SansaParseError(message, index, code);
  }
}

class QueryParser {
  constructor(input, options = {}) {
    this.input = input;
    this.options = options;
    this.warnings = [];
  }

  parse() {
    const source = stripQueryComments(this.input);
    if (source.trim().length === 0) {
      this.fail('Expected SANSA query', 'SANSA_QUERY_EMPTY', 0);
    }

    const clauses = scanQueryClauses(source);
    const first = clauses[0];
    if (!first || first.name !== 'from' || source.slice(0, first.start).trim().length > 0) {
      this.fail("Expected 'from' clause", 'SANSA_QUERY_EXPECTED_FROM', first?.start ?? 0);
    }

    let previousOrder = -1;
    let sawSelect = false;
    const seen = new Set();
    const order = new Map([
      ['from', 0],
      ['where', 1],
      ['order', 2],
      ['offset', 3],
      ['limit', 4],
      ['select', 5],
    ]);

    for (const clause of clauses) {
      if (sawSelect) {
        this.fail("'select' must be the terminal SANSA query clause", 'SANSA_QUERY_SELECT_MUST_BE_TERMINAL', clause.start);
      }
      if (seen.has(clause.name)) {
        this.fail(`Duplicate SANSA query clause '${clause.label}'`, 'SANSA_QUERY_DUPLICATE_CLAUSE', clause.start);
      }
      seen.add(clause.name);
      const currentOrder = order.get(clause.name);
      if (currentOrder < previousOrder) {
        this.fail(`SANSA query clause '${clause.label}' is out of order`, 'SANSA_QUERY_INVALID_CLAUSE_ORDER', clause.start);
      }
      previousOrder = currentOrder;
      if (clause.name === 'select') sawSelect = true;
    }

    if (!seen.has('select')) {
      const end = source.length;
      this.fail("Expected 'select' clause", 'SANSA_QUERY_EXPECTED_SELECT', end);
    }

    const clauseByName = new Map(clauses.map((clause) => [clause.name, clause]));
    const from = this.parseFromClause(clauseByName.get('from'));
    const where = clauseByName.has('where') ? this.parseExpressionClause(clauseByName.get('where'), 'where') : null;
    const orderBy = clauseByName.has('order') ? this.parseOrderByClause(clauseByName.get('order')) : null;
    const offset = clauseByName.has('offset') ? this.parseIntegerClause(clauseByName.get('offset'), 'offset') : null;
    const limit = clauseByName.has('limit') ? this.parseIntegerClause(clauseByName.get('limit'), 'limit') : null;
    const select = this.parseExpressionClause(clauseByName.get('select'), 'select');

    const query = {
      type: 'SansaQuery',
      from,
      where,
      orderBy,
      offset,
      limit,
      select,
      clauses: clauses.map((clause) => clause.name),
    };
    query.canonical = renderQuery(query);
    return query;
  }

  parseFromClause(clause) {
    const expression = normalizeQueryExpression(clause.body);
    if (expression.length === 0) {
      this.fail("Expected SANSA address after 'from'", 'SANSA_QUERY_EXPECTED_FROM_ADDRESS', clause.bodyStart);
    }
    if (expression.startsWith('$') || expression.startsWith('?')) {
      if (/\s/.test(expression)) {
        this.fail("Expected a single SANSA address after 'from'", 'SANSA_QUERY_INVALID_FROM_ADDRESS', clause.bodyStart);
      }
      const result = parseAddress(expression, this.options.address);
      if (!result.ok) {
        const first = result.errors[0];
        this.fail(first.message, first.code, clause.bodyStart + first.index);
      }
      this.warnings.push(...result.warnings);
      return { type: 'fromClause', source: 'address', address: result.address };
    }

    const ast = this.parseClauseExpression(expression, clause.bodyStart);
    if (ast.type !== 'functionCallExpression' || ast.name !== 'path') {
      this.fail("Expected SANSA address or path(...) after 'from'", 'SANSA_QUERY_INVALID_FROM_SOURCE', clause.bodyStart);
    }
    return { type: 'fromClause', source: 'expression', expression: renderQueryExpression(ast), ast };
  }

  parseExpressionClause(clause, name) {
    const expression = normalizeQueryExpression(clause.body);
    if (expression.length === 0) {
      this.fail(`Expected expression after '${clause.label}'`, `SANSA_QUERY_EXPECTED_${name.toUpperCase()}_EXPRESSION`, clause.bodyStart);
    }
    const ast = this.parseClauseExpression(expression, clause.bodyStart);
    return { type: `${name}Clause`, expression: renderQueryExpression(ast), ast };
  }

  parseOrderByClause(clause) {
    const expression = normalizeQueryExpression(clause.body);
    if (expression.length === 0) {
      this.fail("Expected expression after 'order by'", 'SANSA_QUERY_EXPECTED_ORDER_EXPRESSION', clause.bodyStart);
    }
    const keys = splitTopLevelQueryList(expression).map((part) => {
      const normalized = normalizeQueryExpression(part);
      const directionMatch = /^(.*)\s+(asc|desc)$/u.exec(normalized);
      const keyExpression = directionMatch ? directionMatch[1].trim() : normalized;
      const direction = directionMatch ? directionMatch[2] : 'asc';
      if (keyExpression.length === 0) {
        this.fail("Expected order key expression", 'SANSA_QUERY_EXPECTED_ORDER_EXPRESSION', clause.bodyStart);
      }
      const ast = this.parseClauseExpression(keyExpression, clause.bodyStart + part.indexOf(keyExpression));
      return { type: 'orderKey', expression: renderQueryExpression(ast), ast, direction };
    });
    return { type: 'orderByClause', keys };
  }

  parseIntegerClause(clause, name) {
    const value = normalizeQueryExpression(clause.body);
    const code = name === 'limit' ? 'SANSA_QUERY_INVALID_LIMIT' : 'SANSA_QUERY_INVALID_OFFSET';
    if (!/^(0|[1-9][0-9]*)$/.test(value)) {
      this.fail(`Expected non-negative integer after '${name}'`, code, clause.bodyStart);
    }
    if (exceedsUnsignedDecimal(value, SANSA_MAX_QUERY_INTEGER)) {
      this.fail(`Query '${name}' must be less than or equal to ${SANSA_MAX_QUERY_INTEGER}`, code, clause.bodyStart);
    }
    return { type: `${name}Clause`, value: Number(value) };
  }

  parseClauseExpression(expression, offset) {
    const result = parseQueryExpression(expression, this.options.expression);
    if (!result.ok) {
      const first = result.errors[0];
      this.fail(first.message, first.code, offset + first.index);
    }
    this.warnings.push(...result.warnings);
    return result.expression;
  }

  fail(message, code, index) {
    throw new SansaParseError(message, index, code);
  }
}

class QueryExpressionParser {
  constructor(input, options = {}) {
    this.input = normalizeQueryExpression(stripQueryComments(String(input)));
    this.options = options;
    this.index = 0;
    this.warnings = [];
  }

  parse() {
    if (this.input.length === 0) {
      this.fail('Expected SANSA query expression', 'SANSA_QUERY_EXPECTED_EXPRESSION');
    }
    const expression = this.parseOr();
    this.skipLayout();
    if (!this.atEnd()) {
      this.fail(`Unexpected query expression token '${this.peek()}'`, 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
    }
    expression.canonical = renderQueryExpression(expression);
    return expression;
  }

  parseOr() {
    let left = this.parseAnd();
    while (this.matchKeyword('or')) {
      const right = this.parseAnd();
      left = this.binary('or', left, right);
    }
    return left;
  }

  parseAnd() {
    let left = this.parseNot();
    while (this.matchKeyword('and')) {
      const right = this.parseNot();
      left = this.binary('and', left, right);
    }
    return left;
  }

  parseNot() {
    if (this.matchKeyword('not')) {
      const argument = this.parseNot();
      return {
        type: 'unaryExpression',
        operator: 'not',
        argument,
        canonical: '',
      };
    }
    return this.parseComparison();
  }

  parseComparison() {
    let left = this.parsePrimary();
    this.skipLayout();
    const operator = this.matchComparisonOperator();
    if (!operator) return left;
    const right = this.parsePrimary();
    left = this.binary(operator, left, right);
    this.skipLayout();
    if (this.matchComparisonOperator()) {
      this.fail('Chained comparison expressions are not supported', 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
    }
    return left;
  }

  parsePrimary() {
    this.skipLayout();
    const char = this.peek();
    if (!char) this.fail('Expected SANSA query expression', 'SANSA_QUERY_EXPECTED_EXPRESSION');
    if (char === '"') return this.parseString();
    if (char === '|') return this.parseSymbol();
    if (char === '#') return this.parseHex();
    if (char === '%') return this.parseRadix();
    if (char === '&') return this.parseEncoding();
    if (char === '^') return this.parseSeparator();
    if (char === '!') return this.parseNull();
    if (isDigit(char) && this.startsTemporalLiteral()) return this.parseTemporal();
    if (char === '-' || isDigit(char)) return this.parseNumber();
    if (char === '$' || char === '?' || char === '.') return this.parseResolution();
    if (char === '(') return this.parseGroup();
    if (char === '{') return this.parseProjection();
    if (isIdentifierStart(char)) return this.parseIdentifierExpression();
    this.fail(`Unexpected query expression token '${char}'`, 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
  }

  parseIdentifierExpression() {
    const name = this.readIdentifier();
    if (name === 'true' || name === 'false') {
      return {
        type: 'literalExpression',
        kind: 'boolean',
        value: name === 'true',
        canonical: name,
      };
    }
    if (['yes', 'no', 'on', 'off'].includes(name)) {
      return {
        type: 'literalExpression',
        kind: 'toggle',
        value: name,
        canonical: name,
      };
    }
    this.skipLayout();
    if (!this.match('(')) {
      this.fail(`Unexpected query expression identifier '${name}'`, 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
    }
    const argumentSource = this.readBalancedBody('(', ')');
    const argumentParts = argumentSource.trim().length === 0 ? [] : splitTopLevelQueryList(argumentSource);
    const args = argumentParts.map((part) => parseQueryExpressionOrThrow(part, this.options));
    if (['any', 'all', 'none'].includes(name)) {
      if (args.length !== 1) {
        this.fail(`Cardinality operator '${name}' expects exactly one expression`, 'SANSA_QUERY_INVALID_FUNCTION_CALL');
      }
      return {
        type: 'cardinalityExpression',
        operator: name,
        argument: args[0],
        canonical: '',
      };
    }
    if (['exists', 'absent'].includes(name)) {
      if (args.length !== 1) {
        this.fail(`Existence operator '${name}' expects exactly one resolution expression`, 'SANSA_QUERY_INVALID_FUNCTION_CALL');
      }
      if (!unwrapResolutionExpression(args[0])) {
        this.fail(`Existence operator '${name}' expects a resolution expression`, 'SANSA_QUERY_INVALID_FUNCTION_CALL');
      }
      return {
        type: 'existenceExpression',
        operator: name,
        argument: args[0],
        canonical: '',
      };
    }
    return {
      type: 'functionCallExpression',
      name,
      arguments: args,
      canonical: '',
    };
  }

  parseString() {
    const value = this.parseQuotedPayload();
    return {
      type: 'literalExpression',
      kind: 'string',
      value,
      canonical: quotePayload(value),
    };
  }

  parseSymbol() {
    const start = this.index;
    this.index += 1;
    let value = '';
    while (!this.atEnd()) {
      const char = this.peek();
      if (char === '|') {
        this.index += 1;
        if (value.length === 0) {
          this.fail('Symbol literals must not be empty', 'SANSA_QUERY_INVALID_SYMBOL_LITERAL', start);
        }
        return {
          type: 'literalExpression',
          kind: 'symbol',
          value,
          canonical: symbolPayload(value),
        };
      }
      if (char === '\n' || char === '\r') {
        this.fail('Symbol literals must not contain raw newlines', 'SANSA_QUERY_INVALID_SYMBOL_LITERAL', this.index);
      }
      if (char === '\\') {
        const escape = readSymbolPayloadEscape(this.input, this.index);
        value += escape.value;
        this.index = escape.end;
        continue;
      }
      value += char;
      this.index += 1;
    }
    this.fail('Unterminated symbol literal', 'SANSA_QUERY_INVALID_SYMBOL_LITERAL', start);
  }

  parseNumber() {
    const start = this.index;
    if (this.peek() === '-') this.index += 1;
    if (this.peek() === '0') {
      this.index += 1;
      if (isDigit(this.peek())) {
        this.fail('Number literals must not contain leading zeroes', 'SANSA_QUERY_INVALID_NUMBER_LITERAL', start);
      }
    } else if (isDigit(this.peek())) {
      while (isDigit(this.peek())) this.index += 1;
    } else {
      this.fail('Expected number literal', 'SANSA_QUERY_INVALID_NUMBER_LITERAL', start);
    }
    if (this.peek() === '.') {
      this.index += 1;
      if (!isDigit(this.peek())) {
        this.fail('Expected decimal digits after number literal decimal point', 'SANSA_QUERY_INVALID_NUMBER_LITERAL', start);
      }
      while (isDigit(this.peek())) this.index += 1;
    }
    const source = this.input.slice(start, this.index);
    return {
      type: 'literalExpression',
      kind: 'number',
      value: Number(source),
      canonical: source,
    };
  }

  parseHex() {
    const start = this.index;
    this.index += 1;
    const payload = this.readSimpleLiteralPayload();
    if (!/^[0-9A-Fa-f](?:_?[0-9A-Fa-f])*$/.test(payload)) {
      this.fail('Invalid hex literal', 'SANSA_QUERY_INVALID_HEX_LITERAL', start);
    }
    const value = payload.replaceAll('_', '').toLowerCase();
    return {
      type: 'literalExpression',
      kind: 'hex',
      value,
      canonical: `#${value}`,
    };
  }

  parseRadix() {
    const start = this.index;
    this.index += 1;
    const payload = this.readSimpleLiteralPayload();
    if (!isAeonRadixPayload(payload)) {
      this.fail('Invalid radix literal', 'SANSA_QUERY_INVALID_RADIX_LITERAL', start);
    }
    const value = payload.replaceAll('_', '');
    return {
      type: 'literalExpression',
      kind: 'radix',
      value,
      canonical: `%${value}`,
    };
  }

  parseEncoding() {
    const start = this.index;
    this.index += 1;
    const payload = this.readSimpleLiteralPayload();
    if (!isAeonEncodingPayload(payload)) {
      this.fail('Invalid encoding literal', 'SANSA_QUERY_INVALID_ENCODING_LITERAL', start);
    }
    return {
      type: 'literalExpression',
      kind: 'encoding',
      value: payload,
      canonical: `&${payload}`,
    };
  }

  parseSeparator() {
    const start = this.index;
    this.index += 1;
    const payload = this.readStructuredLiteralPayload();
    if (!isAeonSeparatorPayload(payload)) {
      this.fail('Invalid separator literal', 'SANSA_QUERY_INVALID_SEPARATOR_LITERAL', start);
    }
    return {
      type: 'literalExpression',
      kind: 'separator',
      value: payload,
      canonical: `^${payload}`,
    };
  }

  parseNull() {
    const start = this.index;
    this.index += 1;
    const reason = this.peek() === '"'
      ? this.parseQuotedPayload()
      : this.readIdentifier();
    if (reason.length === 0) {
      this.fail('Invalid null literal', 'SANSA_QUERY_INVALID_NULL_LITERAL', start);
    }
    return {
      type: 'literalExpression',
      kind: 'null',
      value: null,
      nullReason: reason,
      canonical: IDENTIFIER_RE.test(reason) ? `!${reason}` : `!${quotePayload(reason)}`,
    };
  }

  parseTemporal() {
    const start = this.index;
    const source = this.readSimpleLiteralPayload();
    const kind = source.includes('T')
      ? source.includes('&')
        ? 'wtc'
        : 'datetime'
      : source.includes(':')
        ? 'time'
        : 'date';
    if (!isQueryTemporalLiteral(source, kind)) {
      this.fail('Invalid temporal literal', 'SANSA_QUERY_INVALID_TEMPORAL_LITERAL', start);
    }
    return {
      type: 'literalExpression',
      kind,
      value: source,
      canonical: source,
    };
  }

  parseResolution() {
    const start = this.index;
    const source = this.readResolutionSource();
    if (source === '.') {
      return {
        type: 'currentBindingExpression',
        canonical: '.',
      };
    }
    const positionalCurrentShorthand = isQueryCurrentPositionalShorthand(source);
    const parseSource = positionalCurrentShorthand
      ? `?${source.slice(1)}`
      : source.startsWith('.')
        ? `?${source}`
        : source;
    const result = parseAddress(parseSource, this.options.address);
    if (!result.ok) {
      const first = result.errors[0];
      this.fail(first.message, first.code, start + first.index - (source.startsWith('.') ? 1 : 0));
    }
    this.warnings.push(...result.warnings);
    const scope = source.startsWith('.')
      ? 'current'
      : result.address.root.kind;
    const canonical = positionalCurrentShorthand
      ? `.${renderAddress(result.address).slice(1)}`
      : source.startsWith('.')
      ? renderAddress(result.address).slice(1)
      : renderAddress(result.address);
    return {
      type: 'resolutionExpression',
      scope,
      address: result.address,
      canonical,
    };
  }

  parseGroup() {
    this.consume('(');
    const source = this.readBalancedBody('(', ')');
    const expression = parseQueryExpressionOrThrow(source, this.options);
    return {
      type: 'groupExpression',
      expression,
      canonical: '',
    };
  }

  parseProjection() {
    this.consume('{');
    const source = this.readBalancedBody('{', '}');
    const fields = splitProjectionFields(source).map((field) => ({
      type: 'projectionField',
      name: field.name,
      expression: parseQueryExpressionOrThrow(field.expression, this.options),
    }));
    if (fields.length === 0) {
      this.fail('Expected at least one projection field', 'SANSA_QUERY_INVALID_PROJECTION');
    }
    return {
      type: 'projectionExpression',
      fields,
      canonical: '',
    };
  }

  startsTemporalLiteral() {
    const rest = this.input.slice(this.index);
    return /^\d{4}-/.test(rest)
      || /^\d{2}:/.test(rest);
  }

  readSimpleLiteralPayload() {
    const start = this.index;
    while (!this.atEnd()) {
      const char = this.peek();
      if (isLayout(char) || char === ',' || char === ')' || char === '}' || char === ']') break;
      this.index += 1;
    }
    const payload = this.input.slice(start, this.index);
    if (payload.length === 0) {
      this.fail('Expected literal payload', 'SANSA_QUERY_EXPECTED_LITERAL_PAYLOAD', start);
    }
    return payload;
  }

  readStructuredLiteralPayload() {
    const start = this.index;
    let quote = null;
    while (!this.atEnd()) {
      const char = this.peek();
      if (quote) {
        if (char === '\\') {
          this.index += 2;
          continue;
        }
        if (char === quote) quote = null;
        this.index += 1;
        continue;
      }
      if (char === '"' || char === "'") {
        quote = char;
        this.index += 1;
        continue;
      }
      if (isLayout(char) || char === ',' || char === ')' || char === '}' || char === ']') break;
      this.index += 1;
    }
    const payload = this.input.slice(start, this.index);
    if (quote) {
      this.fail('Unterminated structured scalar literal', 'SANSA_QUERY_UNTERMINATED_EXPRESSION', start);
    }
    return payload;
  }

  readResolutionSource() {
    const start = this.index;
    let quote = null;
    let parenDepth = 0;
    let bracketDepth = 0;
    let angleDepth = 0;
    let qualifierDepth = 0;
    let sawColon = false;
    for (; this.index < this.input.length; this.index += 1) {
      const char = this.input[this.index];
      if (quote) {
        if (char === '\\') this.index += 1;
        else if (char === quote) quote = null;
        continue;
      }
      if (char === '"') {
        quote = char;
        continue;
      }
      if (char === ':') sawColon = true;
      if (char === '(') parenDepth += 1;
      else if (char === ')' && parenDepth > 0) parenDepth -= 1;
      else if (char === '[') bracketDepth += 1;
      else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
      else if (char === '<' && (sawColon || this.input[this.index - 1] === '.')) {
        angleDepth += 1;
        if (sawColon) qualifierDepth += 1;
      } else if (char === '>' && angleDepth > 0) {
        angleDepth -= 1;
        if (qualifierDepth > 0) qualifierDepth -= 1;
      } else if (
        parenDepth === 0
        && bracketDepth === 0
        && angleDepth === 0
        && (isLayout(char) || char === ',' || char === ')' || char === '}' || isComparisonStart(char))
      ) {
        break;
      }
    }
    const source = this.input.slice(start, this.index);
    if (source.length === 0) {
      this.fail('Expected SANSA resolution expression', 'SANSA_QUERY_INVALID_RESOLUTION_EXPRESSION', start);
    }
    return source;
  }

  readBalancedBody(open, close) {
    const start = this.index;
    let quote = null;
    let depth = 1;
    while (!this.atEnd()) {
      const char = this.input[this.index];
      if (quote) {
        if (char === '\\') this.index += 2;
        else {
          if (char === quote) quote = null;
          this.index += 1;
        }
        continue;
      }
      if (char === '"' || isSymbolLiteralStart(this.input, this.index)) {
        quote = char;
        this.index += 1;
        continue;
      }
      if (char === open) depth += 1;
      else if (char === close) depth -= 1;
      if (depth === 0) {
        const body = this.input.slice(start, this.index);
        this.index += 1;
        return body;
      }
      this.index += 1;
    }
    this.fail(`Unterminated '${open}' expression`, 'SANSA_QUERY_UNTERMINATED_EXPRESSION', start - 1);
  }

  parseQuotedPayload() {
    const parser = new AddressParser(this.input.slice(this.index), this.options.address);
    const value = parser.parseQuotedPayload();
    this.warnings.push(...parser.warnings);
    this.index += parser.index;
    return value;
  }

  binary(operator, left, right) {
    return {
      type: 'binaryExpression',
      operator,
      left,
      right,
      canonical: '',
    };
  }

  matchComparisonOperator() {
    this.skipLayout();
    if (this.matchKeyword('in')) return 'in';
    for (const operator of ['==', '!=', '<=', '>=', '<', '>']) {
      if (this.input.startsWith(operator, this.index)) {
        this.index += operator.length;
        return operator;
      }
    }
    return null;
  }

  matchKeyword(keyword) {
    this.skipLayout();
    if (!this.input.startsWith(keyword, this.index)) return false;
    const before = this.index === 0 ? '' : this.input[this.index - 1];
    const after = this.input[this.index + keyword.length] ?? '';
    if (isIdentifierContinue(before) || isIdentifierContinue(after)) return false;
    this.index += keyword.length;
    return true;
  }

  readIdentifier() {
    const start = this.index;
    if (!isIdentifierStart(this.peek())) {
      this.fail('Expected identifier', 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
    }
    this.index += 1;
    while (isIdentifierContinue(this.peek())) this.index += 1;
    return this.input.slice(start, this.index);
  }

  skipLayout() {
    while (isLayout(this.peek())) this.index += 1;
  }

  consume(char) {
    if (this.peek() !== char) this.fail(`Expected '${char}'`, 'SANSA_QUERY_UNEXPECTED_EXPRESSION_TOKEN');
    this.index += 1;
  }

  match(char) {
    if (this.peek() !== char) return false;
    this.index += 1;
    return true;
  }

  peek() {
    return this.input[this.index] ?? '';
  }

  atEnd() {
    return this.index >= this.input.length;
  }

  fail(message, code, index = this.index) {
    throw new SansaParseError(message, index, code);
  }
}

function stripQueryComments(input) {
  let output = '';
  let quote = null;
  for (let index = 0; index < input.length; index += 1) {
    const char = input[index];
    const next = input[index + 1] ?? '';
    if (quote) {
      output += char;
      if (char === '\\') {
        index += 1;
        output += input[index] ?? '';
      } else if (char === quote) {
        quote = null;
      }
      continue;
    }
    if (char === '"' || char === "'" || isSymbolLiteralStart(input, index)) {
      quote = char;
      output += char;
      continue;
    }
    if (char === '/' && (next === '/' || next === '*') && isTemporalZoneCommentContext(input, index)) {
      // Preserve the rest of this invalid zone token once, avoiding repeated
      // backwards scans for a long run of comment-looking slashes.
      while (index < input.length && !isLayout(input[index]) && ![',', ')', '}', ']'].includes(input[index])) {
        output += input[index];
        index += 1;
      }
      index -= 1;
      continue;
    }
    if (char === '/' && next === '/') {
      output += '  ';
      index += 1;
      while (index + 1 < input.length && input[index + 1] !== '\n' && input[index + 1] !== '\r') {
        index += 1;
        output += ' ';
      }
      continue;
    }
    if (char === '/' && next === '*') {
      const start = index;
      output += '  ';
      index += 1;
      let closed = false;
      while (index + 1 < input.length) {
        index += 1;
        const current = input[index];
        const following = input[index + 1] ?? '';
        output += current === '\n' || current === '\r' ? current : ' ';
        if (current === '*' && following === '/') {
          index += 1;
          output += ' ';
          closed = true;
          break;
        }
      }
      if (!closed) {
        throw new SansaParseError('Unterminated SANSA query block comment', start, 'SANSA_QUERY_UNTERMINATED_BLOCK_COMMENT');
      }
      continue;
    }
    output += char;
  }
  return output;
}

function isTemporalZoneCommentContext(input, index) {
  let cursor = index - 1;
  while (cursor >= 0 && !isLayout(input[cursor]) && ![',', '(', ')', '{', '}', '[', ']', '=', '<', '>', '!'].includes(input[cursor])) {
    cursor -= 1;
  }
  const tokenPrefix = input.slice(cursor + 1, index);
  return /^\d{4}-/.test(tokenPrefix) && tokenPrefix.includes('T') && tokenPrefix.includes('&');
}

function renderInstruction(instruction) {
  const lines = [];
  if (instruction.provenance?.reason !== undefined) lines.push(`because ${quotePayload(instruction.provenance.reason)}`);
  if (instruction.provenance?.claimedAuthor !== undefined) lines.push(`by ${quotePayload(instruction.provenance.claimedAuthor)}`);
  if (instruction.from) lines.push(`from ${renderInstructionAddress(instruction.from.address)}`);
  if (instruction.where) lines.push(`where ${renderQueryExpression(instruction.where.ast)}`);
  for (const requirement of instruction.requires ?? []) {
    lines.push(`require ${renderQueryExpression(requirement.ast)}`);
  }
  lines.push(renderInstructionMutation(instruction.mutation));
  return lines.join('\n');
}

function renderInstructionMutation(mutation) {
  switch (mutation.verb) {
    case 'create':
      return `create ${mutation.destination.canonical} with ${renderInstructionValue(mutation.value)}`;
    case 'replace':
      return `replace ${renderInstructionAddress(mutation.target.address)} with ${renderInstructionValue(mutation.value)}`;
    case 'remove':
      return `remove ${renderInstructionAddress(mutation.target.address)}`;
    case 'insert':
      return `insert ${renderInstructionPlacement(mutation.placement)} in ${renderInstructionAddress(mutation.container.address)} with ${renderInstructionValue(mutation.value)}`;
    case 'move':
      return `move ${renderInstructionAddress(mutation.source.address)} ${renderInstructionPlacement(mutation.placement)} in ${renderInstructionAddress(mutation.container.address)}`;
    default:
      throw new Error(`Unknown instruction mutation verb: ${mutation.verb}`);
  }
}

function renderInstructionPlacement(placement) {
  if (placement.kind === 'first' || placement.kind === 'last') return placement.kind;
  return `${placement.kind} ${renderInstructionAddress(placement.anchor.address)}`;
}

function renderInstructionValue(value) {
  return value.canonical;
}

function renderInstructionAddress(address) {
  const canonical = renderAddress(address);
  if (address.root.kind !== 'contextual') return canonical;
  return address.selectors.length === 0 ? '.' : canonical.slice(1);
}

function stripInstructionComments(input) {
  try {
    return stripQueryComments(input);
  } catch (error) {
    if (error instanceof SansaParseError && error.code === 'SANSA_QUERY_UNTERMINATED_BLOCK_COMMENT') {
      throw new SansaParseError('Unterminated SANSA instruction block comment', error.index, 'SANSA_INSTRUCTION_UNTERMINATED_BLOCK_COMMENT');
    }
    throw error;
  }
}

function scanInstructionClauses(source) {
  const clauses = [];
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<' && !isLayout(source[index - 1] ?? '')) angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;

    if (parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0 || angleDepth !== 0) {
      continue;
    }

    const match = matchInstructionClauseKeyword(source, index);
    if (match) {
      clauses.push({
        name: match.name,
        label: match.label,
        category: match.category,
        start: index,
        bodyStart: match.end,
        body: '',
      });
      index = match.end - 1;
    }
  }

  for (let index = 0; index < clauses.length; index += 1) {
    const clause = clauses[index];
    const next = clauses[index + 1];
    const bodyEnd = next ? next.start : source.length;
    clause.body = source.slice(clause.bodyStart, bodyEnd);
  }
  return clauses;
}

function matchInstructionClauseKeyword(source, index) {
  if (!isInstructionClauseBoundaryBefore(source, index)) return null;
  if (source.startsWith('order', index) && isInstructionClauseBoundaryAfter(source, index + 'order'.length)) {
    let cursor = index + 'order'.length;
    const gapStart = cursor;
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (cursor > gapStart && source.startsWith('by', cursor) && isInstructionClauseBoundaryAfter(source, cursor + 2)) {
      return { name: 'order', label: 'order by', category: 'unsupportedQuery', end: cursor + 2 };
    }
  }
  for (const name of ['from', 'where', 'require']) {
    if (source.startsWith(name, index) && isInstructionClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, category: 'query', end: index + name.length };
    }
  }
  for (const name of ['because', 'by']) {
    if (source.startsWith(name, index) && isInstructionClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, category: 'metadata', end: index + name.length };
    }
  }
  for (const name of ['select', 'offset', 'limit']) {
    if (source.startsWith(name, index) && isInstructionClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, category: 'unsupportedQuery', end: index + name.length };
    }
  }
  for (const name of ['create', 'replace', 'remove', 'insert', 'append', 'move']) {
    if (source.startsWith(name, index) && isInstructionClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, category: 'mutation', end: index + name.length };
    }
  }
  for (const name of ['rename', 'copy', 'clone', 'merge', 'patch', 'upsert', 'clear']) {
    if (source.startsWith(name, index) && isInstructionClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, category: 'deferredVerb', end: index + name.length };
    }
  }
  return null;
}

function isInstructionClauseBoundaryBefore(source, index) {
  if (index === 0) return true;
  return isLayout(source[index - 1]);
}

function isInstructionClauseBoundaryAfter(source, index) {
  const char = source[index] ?? '';
  return char === '' || isLayout(char);
}

function findTopLevelInstructionKeyword(source, keyword, start = 0) {
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (let index = start; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;
    if (parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0 || angleDepth !== 0) continue;
    if (
      source.startsWith(keyword, index)
      && isInstructionClauseBoundaryBefore(source, index)
      && isInstructionClauseBoundaryAfter(source, index + keyword.length)
    ) {
      return index;
    }
  }
  return -1;
}

function readInstructionToken(source, start) {
  let cursor = start;
  while (isLayout(source[cursor] ?? '')) cursor += 1;
  const tokenStart = cursor;
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (; cursor < source.length; cursor += 1) {
    const char = source[cursor];
    if (quote) {
      if (char === '\\') cursor += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, cursor)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;
    if (parenDepth === 0 && bracketDepth === 0 && braceDepth === 0 && angleDepth === 0 && isLayout(char)) break;
  }
  return { token: source.slice(tokenStart, cursor), start: tokenStart, end: cursor };
}

function readInstructionDatatypeToken(source, start) {
  let cursor = start;
  const tokenStart = cursor;
  let quote = null;
  let bracketDepth = 0;
  let angleDepth = 0;
  for (; cursor < source.length; cursor += 1) {
    const char = source[cursor];
    if (quote) {
      if (char === '\\') cursor += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"') {
      quote = char;
      continue;
    }
    if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;
    if (bracketDepth === 0 && angleDepth === 0 && (isLayout(char) || char === ',')) break;
  }
  return { token: source.slice(tokenStart, cursor), start: tokenStart, end: cursor };
}

function unwrapInstructionDelimitedLiteral(source, open, close, offset) {
  if (!source.startsWith(open)) {
    throw new SansaParseError(`Expected '${open}'`, offset, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
  }
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;

    if (
      char === close
      && parenDepth === (open === '(' ? 0 : 0)
      && bracketDepth === (open === '[' ? 0 : 0)
      && braceDepth === (open === '{' ? 0 : 0)
      && angleDepth === (open === '<' ? 0 : 0)
    ) {
      if (source.slice(index + 1).trim().length !== 0) {
        throw new SansaParseError('Unexpected token after instruction value literal', offset + index + 1, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
      }
      return source.slice(1, index);
    }
  }
  throw new SansaParseError(`Unterminated instruction value literal '${open}'`, offset, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
}

function parseInstructionValueItems(source, offset, parser) {
  const parts = splitTopLevelInstructionValueList(source, offset);
  return parts.map((part) => parser.parseInstructionValue(part.source, part.offset, { nested: true }));
}

function splitTopLevelInstructionValueList(source, offset) {
  const trimmed = source.trim();
  if (trimmed.length === 0) return [];
  const parts = [];
  let start = 0;
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;
    if (char !== ',' || parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0 || angleDepth !== 0) {
      continue;
    }
    parts.push(instructionValueListPart(source, start, index, offset));
    start = index + 1;
  }
  parts.push(instructionValueListPart(source, start, source.length, offset));
  return parts;
}

function instructionValueListPart(source, start, end, offset) {
  let itemStart = start;
  let itemEnd = end;
  while (isLayout(source[itemStart] ?? '')) itemStart += 1;
  while (itemEnd > itemStart && isLayout(source[itemEnd - 1] ?? '')) itemEnd -= 1;
  if (itemStart >= itemEnd) {
    throw new SansaParseError('Expected instruction value item', offset + start, 'SANSA_INSTRUCTION_EXPECTED_VALUE');
  }
  return { source: source.slice(itemStart, itemEnd), offset: offset + itemStart };
}

function normalizeInstructionAddressSource(source) {
  const value = source.trim();
  if (value.length === 0) {
    return { ok: false, code: 'SANSA_INSTRUCTION_EXPECTED_ADDRESS', message: 'Expected SANSA address' };
  }
  if (value === '.') return { ok: true, source: '?', adjustment: 0 };
  if (value.startsWith('.')) return { ok: true, source: `?${value}`, adjustment: -1 };
  if (value.startsWith('$') || value.startsWith('?')) return { ok: true, source: value, adjustment: 0 };
  return {
    ok: false,
    code: 'SANSA_INSTRUCTION_EXPECTED_ADDRESS',
    message: "Expected SANSA address root '$', '?', or contextual '.'",
  };
}

function firstNonLayoutOffset(source) {
  for (let index = 0; index < source.length; index += 1) {
    if (!isLayout(source[index])) return index;
  }
  return source.length;
}

function scanQueryClauses(source) {
  const clauses = [];
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') {
        index += 1;
      } else if (char === quote) {
        quote = null;
      }
      continue;
    }
    if (char === '"' || char === "'" || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;

    if (parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0) {
      continue;
    }

    const match = matchQueryClauseKeyword(source, index);
    if (match) {
      clauses.push({
        name: match.name,
        label: match.label,
        start: index,
        bodyStart: match.end,
        body: '',
      });
      index = match.end - 1;
    }
  }

  for (let index = 0; index < clauses.length; index += 1) {
    const clause = clauses[index];
    const next = clauses[index + 1];
    const bodyEnd = next ? next.start : source.length;
    clause.body = source.slice(clause.bodyStart, bodyEnd);
  }
  return clauses;
}

function matchQueryClauseKeyword(source, index) {
  if (!isQueryClauseBoundaryBefore(source, index)) return null;
  if (source.startsWith('order', index) && isQueryClauseBoundaryAfter(source, index + 'order'.length)) {
    let cursor = index + 'order'.length;
    const gapStart = cursor;
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (cursor > gapStart && source.startsWith('by', cursor) && isQueryClauseBoundaryAfter(source, cursor + 2)) {
      return { name: 'order', label: 'order by', end: cursor + 2 };
    }
  }
  for (const name of ['from', 'where', 'offset', 'limit', 'select']) {
    if (source.startsWith(name, index) && isQueryClauseBoundaryAfter(source, index + name.length)) {
      return { name, label: name, end: index + name.length };
    }
  }
  return null;
}

function exceedsUnsignedDecimal(raw, max) {
  const maxRaw = String(max);
  return raw.length > maxRaw.length || (raw.length === maxRaw.length && raw > maxRaw);
}

function normalizeMaxPositionIndex(value) {
  if (value === undefined) return SANSA_MAX_POSITION_INDEX;
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    return SANSA_MAX_POSITION_INDEX;
  }
  return value;
}

function isQueryClauseBoundaryBefore(source, index) {
  if (index === 0) return true;
  return isLayout(source[index - 1]);
}

function isQueryClauseBoundaryAfter(source, index) {
  const char = source[index] ?? '';
  return char === '' || isLayout(char);
}

function normalizeQueryExpression(source) {
  let output = '';
  let quote = null;
  let pendingSpace = false;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      output += char;
      if (char === '\\') {
        index += 1;
        output += source[index] ?? '';
      } else if (char === quote) {
        quote = null;
      }
      continue;
    }
    if (char === '"' || char === "'" || isSymbolLiteralStart(source, index)) {
      if (pendingSpace && output.length > 0) output += ' ';
      pendingSpace = false;
      quote = char;
      output += char;
      continue;
    }
    if (isLayout(char)) {
      pendingSpace = output.length > 0;
      continue;
    }
    if (pendingSpace && output.length > 0) output += ' ';
    pendingSpace = false;
    output += char;
  }
  return output.trim();
}

function isQueryCurrentPositionalShorthand(source) {
  return source.startsWith('.[') && source[2] !== '"';
}

function isQueryTemporalLiteral(source, kind) {
  if (kind === 'date') return parseTemporalDate(source) !== null;
  if (kind === 'time') return parseTemporalClock(source, true) !== null;
  let datetime = source;
  if (kind === 'wtc') {
    const marker = source.indexOf('&');
    if (marker === -1) return false;
    datetime = source.slice(0, marker);
    const zone = source.slice(marker + 1);
    if (!zone || zone.trim() !== zone
        || (zone.toLowerCase() === 'local' && zone !== 'local')
        || !/^[A-Za-z0-9_+.\-]+(?:\/[A-Za-z0-9_+.\-]+)*$/.test(zone)) return false;
  } else if (kind !== 'datetime') {
    return false;
  }
  const marker = datetime.indexOf('T');
  return marker !== -1
    && parseTemporalDate(datetime.slice(0, marker)) !== null
    && parseTemporalClock(datetime.slice(marker + 1), false) !== null;
}

function isValidDateParts(yearText, monthText, dayText) {
  const year = Number(yearText);
  const month = Number(monthText);
  const day = Number(dayText);
  if (year < 1 || month < 1 || month > 12) return false;
  const days = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day >= 1 && day <= days[month - 1];
}

function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

function isAeonRadixPayload(payload) {
  return payload.trim() === payload
    && /^[+-]?(?:[0-9A-Za-z&!](?:_?[0-9A-Za-z&!])*)(?:\.(?:[0-9A-Za-z&!](?:_?[0-9A-Za-z&!])*))?$|^[+-]?\.(?:[0-9A-Za-z&!](?:_?[0-9A-Za-z&!])*)$/.test(payload);
}

function isAeonEncodingPayload(payload) {
  return payload.trim() === payload && /^[A-Za-z0-9_-]+={0,2}$/.test(payload);
}

function isRepresentableTrimtickPayload(payload) {
  return !payload.includes('\n') || (!payload.endsWith('\n')
    && payload.split('\n').every((line) => line.length === 0 || !/^[ \t]+$/.test(line)));
}

function isDecodableBase64UrlPayload(payload) {
  if (!isAeonEncodingPayload(payload)) return false;
  const body = payload.replace(/=+$/, '');
  const padding = payload.length - body.length;
  const remainder = body.length % 4;
  if (remainder === 1 || (padding !== 0 && payload.length % 4 !== 0)
      || (padding === 1 && remainder !== 3) || (padding === 2 && remainder !== 2)) return false;
  const last = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'.indexOf(body.at(-1));
  return remainder === 2 ? (last & 15) === 0 : remainder === 3 ? (last & 3) === 0 : true;
}

function isAeonSeparatorPayload(payload) {
  if (typeof payload !== 'string' || payload.length === 0) return false;
  let index = 0;
  while (index < payload.length) {
    const char = payload[index];
    if (char === '"' || char === "'") {
      const quote = char;
      index += 1;
      let terminated = false;
      while (index < payload.length) {
        const inner = payload[index];
        if (inner === '\n' || inner === '\r') return false;
        if (inner === '\\') {
          index += 2;
          continue;
        }
        index += 1;
        if (inner === quote) {
          terminated = true;
          break;
        }
      }
      if (!terminated) return false;
      continue;
    }
    if (!isAeonSeparatorRawChar(char)) return false;
    index += 1;
  }
  return true;
}

function isAeonSeparatorRawChar(char) {
  return /^[A-Za-z0-9!#$%&*+\-.:;=?@^_|~<>]$/.test(char ?? '');
}

function splitTopLevelQueryList(source) {
  const parts = [];
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let start = 0;
  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'" || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === ',' && parenDepth === 0 && bracketDepth === 0 && braceDepth === 0) {
      parts.push(source.slice(start, index));
      start = index + 1;
    }
  }
  parts.push(source.slice(start));
  return parts;
}

function splitProjectionFields(source) {
  const fields = [];
  let cursor = 0;
  while (cursor < source.length) {
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (cursor >= source.length) break;
    const nameStart = cursor;
    if (!isIdentifierStart(source[cursor] ?? '')) {
      throw new SansaParseError('Expected projection field name', cursor, 'SANSA_QUERY_INVALID_PROJECTION');
    }
    cursor += 1;
    while (isIdentifierContinue(source[cursor] ?? '')) cursor += 1;
    const name = source.slice(nameStart, cursor);
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (source[cursor] === ':') {
      throw new SansaParseError(
        "Projection fields use AEON assignment syntax ('name = expression'); ':' is reserved for datatype annotations",
        cursor,
        'SANSA_QUERY_INVALID_PROJECTION',
      );
    }
    if (source[cursor] !== '=') {
      throw new SansaParseError("Expected '=' after projection field name", cursor, 'SANSA_QUERY_INVALID_PROJECTION');
    }
    cursor += 1;
    const expressionStart = cursor;
    const nextField = findNextProjectionField(source, cursor);
    const expressionEnd = nextField < 0 ? source.length : nextField;
    const expression = source.slice(expressionStart, expressionEnd).trim();
    if (expression.length === 0) {
      throw new SansaParseError('Expected projection field expression', expressionStart, 'SANSA_QUERY_INVALID_PROJECTION');
    }
    fields.push({ name, expression });
    cursor = expressionEnd;
  }
  return fields;
}

function splitInstructionObjectFields(source) {
  const fields = [];
  let cursor = 0;
  while (cursor < source.length) {
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (cursor >= source.length) break;
    if (source[cursor] === ',') {
      throw new SansaParseError('Expected object field name', cursor, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
    }
    const nameStart = cursor;
    const nameToken = readInstructionObjectFieldName(source, cursor);
    if (!nameToken) {
      throw new SansaParseError('Expected object field name', cursor, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
    }
    cursor = nameToken.end;
    const name = nameToken.name;
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (source[cursor] !== '=') {
      throw new SansaParseError("Expected '=' after object field name", cursor, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
    }
    cursor += 1;
    const expressionStart = cursor;
    const nextField = findNextInstructionObjectField(source, cursor);
    const expressionEnd = nextField < 0 ? source.length : nextField;
    const expressionSource = source.slice(expressionStart, expressionEnd);
    const expressionOffset = expressionStart + firstNonLayoutOffset(expressionSource);
    const expression = expressionSource.trim();
    if (expression.length === 0) {
      throw new SansaParseError('Expected object field value', expressionStart, 'SANSA_INSTRUCTION_INVALID_VALUE_LITERAL');
    }
    fields.push({ name, canonicalName: nameToken.canonicalName, nameOffset: nameStart, expression, expressionOffset });
    cursor = expressionEnd;
    if (source[cursor] === ',') cursor += 1;
  }
  return fields;
}

function readInstructionObjectFieldName(source, start) {
  const char = source[start] ?? '';
  if (isIdentifierStart(char)) {
    let cursor = start + 1;
    while (isIdentifierContinue(source[cursor] ?? '')) cursor += 1;
    const name = source.slice(start, cursor);
    return { name, canonicalName: name, end: cursor };
  }
  if (char !== '"') return null;
  let cursor = start + 1;
  let name = '';
  while (cursor < source.length) {
    const current = source[cursor];
    if (current === '"') {
      cursor += 1;
      return { name, canonicalName: quotePayload(name), end: cursor };
    }
    if (current === '\n' || current === '\r') {
      throw new SansaParseError('Quoted payloads must not contain raw newlines', cursor, 'SANSA_RAW_NEWLINE_IN_QUOTED_PAYLOAD');
    }
    if (current === '\\') {
      const escape = readQuotedPayloadEscape(source, cursor);
      name += escape.value;
      cursor = escape.end;
      continue;
    }
    name += current;
    cursor += 1;
  }
  throw new SansaParseError('Unterminated quoted payload', start + 1, 'SANSA_UNTERMINATED_QUOTED_PAYLOAD');
}

function findNextProjectionField(source, start) {
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  for (let index = start; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;

    if (parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0 || !isLayout(char)) {
      continue;
    }

    let cursor = index;
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (!isIdentifierStart(source[cursor] ?? '')) continue;
    cursor += 1;
    while (isIdentifierContinue(source[cursor] ?? '')) cursor += 1;
    const afterName = cursor;
    while (isLayout(source[cursor] ?? '')) cursor += 1;
    if (source[cursor] === '=' && source[cursor + 1] !== '=') {
      return index;
    }
    index = afterName - 1;
  }
  return -1;
}

function findNextInstructionObjectField(source, start) {
  let quote = null;
  let parenDepth = 0;
  let bracketDepth = 0;
  let braceDepth = 0;
  let angleDepth = 0;
  for (let index = start; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (char === '\\') index += 1;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || isSymbolLiteralStart(source, index)) {
      quote = char;
      continue;
    }
    if (char === '(') parenDepth += 1;
    else if (char === ')' && parenDepth > 0) parenDepth -= 1;
    else if (char === '[') bracketDepth += 1;
    else if (char === ']' && bracketDepth > 0) bracketDepth -= 1;
    else if (char === '{') braceDepth += 1;
    else if (char === '}' && braceDepth > 0) braceDepth -= 1;
    else if (char === '<') angleDepth += 1;
    else if (char === '>' && angleDepth > 0) angleDepth -= 1;

    if (parenDepth !== 0 || bracketDepth !== 0 || braceDepth !== 0 || angleDepth !== 0) {
      continue;
    }
    if (char === ',' && isInstructionObjectFieldStart(source, index + 1)) return index;
    if (isLayout(char) && isInstructionObjectFieldStart(source, index)) return index;
  }
  return -1;
}

function isInstructionObjectFieldStart(source, start) {
  let cursor = start;
  while (isLayout(source[cursor] ?? '')) cursor += 1;
  const name = readInstructionObjectFieldName(source, cursor);
  if (!name) return false;
  cursor = name.end;
  while (isLayout(source[cursor] ?? '')) cursor += 1;
  return source[cursor] === '=' && source[cursor + 1] !== '=';
}

function isComparisonStart(char) {
  return char === '=' || char === '!' || char === '<' || char === '>';
}

function isSymbolLiteralStart(source, index) {
  if (source[index] !== '|') return false;
  if (index === 0 || isLayout(source[index - 1])) return true;
  if ('([{,=<>!'.includes(source[index - 1])) return true;
  return /(?:^|[^A-Za-z0-9_])(?:and|or|not|in)$/u.test(source.slice(0, index));
}

function readQuotedPayloadEscape(source, start) {
  const escape = source[start + 1];
  if (!escape) throw new SansaParseError('Unterminated escape sequence', start, 'SANSA_UNTERMINATED_ESCAPE');
  switch (escape) {
    case '\\': return { value: '\\', end: start + 2 };
    case '"': return { value: '"', end: start + 2 };
    case "'": return { value: "'", end: start + 2 };
    case '`': return { value: '`', end: start + 2 };
    case 'n': return { value: '\n', end: start + 2 };
    case 'r': return { value: '\r', end: start + 2 };
    case 't': return { value: '\t', end: start + 2 };
    case 'b': return { value: '\b', end: start + 2 };
    case 'f': return { value: '\f', end: start + 2 };
    case 'u':
      return readUnicodePayloadEscape(source, start);
    default:
      throw new SansaParseError(`Invalid escape sequence \\${escape}`, start, 'SANSA_INVALID_ESCAPE');
  }
}

function readSymbolPayloadEscape(source, start) {
  if (source[start + 1] === '|') return { value: '|', end: start + 2 };
  return readQuotedPayloadEscape(source, start);
}

function readUnicodePayloadEscape(source, start) {
  let cursor = start + 2;
  if (source[cursor] === '{') {
    cursor += 1;
    const rawStart = cursor;
    while (cursor < source.length && source[cursor] !== '}') cursor += 1;
    if (cursor >= source.length) throw new SansaParseError('Unterminated Unicode escape', start, 'SANSA_UNTERMINATED_UNICODE_ESCAPE');
    const raw = source.slice(rawStart, cursor);
    if (!/^[0-9A-Fa-f]{1,6}$/.test(raw)) throw new SansaParseError('Invalid Unicode escape', rawStart, 'SANSA_INVALID_UNICODE_ESCAPE');
    return { value: codePointToString(Number.parseInt(raw, 16), rawStart), end: cursor + 1 };
  }
  const raw = source.slice(cursor, cursor + 4);
  if (!/^[0-9A-Fa-f]{4}$/.test(raw)) throw new SansaParseError('Invalid Unicode escape', cursor, 'SANSA_INVALID_UNICODE_ESCAPE');
  return { value: codePointToString(Number.parseInt(raw, 16), cursor), end: cursor + 4 };
}

function isExactSelector(selector) {
  return ['member', 'position', 'attributeSpace', 'localSpace'].includes(selector.type);
}

function isIdentifierStart(char) {
  return /^[A-Za-z_]$/.test(char ?? '');
}

function isIdentifierContinue(char) {
  return /^[A-Za-z0-9_]$/.test(char ?? '');
}

function isDigit(char) {
  return /^[0-9]$/.test(char ?? '');
}

function isLayout(char) {
  return char === ' ' || char === '\t' || char === '\n' || char === '\r';
}

function isQualifierArgumentChar(char) {
  return /^[A-Za-z0-9!#$%&*+\-.:;=?@^_|~<>]$/.test(char ?? '');
}

function datatypeBaseName(datatype) {
  const genericCut = datatype.indexOf('<');
  const argumentCut = datatype.indexOf('[');
  const cut = [genericCut, argumentCut].filter((index) => index >= 0).sort((a, b) => a - b)[0];
  return (cut === undefined ? datatype : datatype.slice(0, cut)).trim();
}

function lowerFirst(value) {
  return `${value.charAt(0).toLowerCase()}${value.slice(1)}`;
}

function globPatternToRegExp(pattern) {
  let source = '^';
  const chars = Array.from(pattern);
  for (let index = 0; index < chars.length; index += 1) {
    const char = chars[index];
    if (char === '\\' && ['*', '?', '\\'].includes(chars[index + 1])) {
      source += escapeRegExp(chars[index + 1]);
      index += 1;
      continue;
    }
    if (char === '*') {
      source += '.*';
    } else if (char === '?') {
      source += '.';
    } else {
      source += escapeRegExp(char);
    }
  }
  return new RegExp(`${source}$`, 'u');
}

function escapeRegExp(value) {
  return value.replace(/[\\^$.*+?()[\]{}|]/g, '\\$&');
}

function codePointToString(codePoint, index) {
  if (codePoint > 0x10FFFF || (codePoint >= 0xD800 && codePoint <= 0xDFFF)) {
    throw new SansaParseError('Unicode escape must decode to a scalar value', index, 'SANSA_INVALID_UNICODE_SCALAR');
  }
  return String.fromCodePoint(codePoint);
}

function quotePayload(value) {
  let output = '"';
  for (const char of value) {
    switch (char) {
      case '\\':
        output += '\\\\';
        break;
      case '"':
        output += '\\"';
        break;
      case '\n':
        output += '\\n';
        break;
      case '\r':
        output += '\\r';
        break;
      case '\t':
        output += '\\t';
        break;
      case '\b':
        output += '\\b';
        break;
      case '\f':
        output += '\\f';
        break;
      default:
        output += char;
        break;
    }
  }
  output += '"';
  return output;
}

function symbolPayload(value) {
  let output = '|';
  for (const char of value) {
    switch (char) {
      case '\\':
        output += '\\\\';
        break;
      case '|':
        output += '\\|';
        break;
      case '\n':
        output += '\\n';
        break;
      case '\r':
        output += '\\r';
        break;
      case '\t':
        output += '\\t';
        break;
      case '\b':
        output += '\\b';
        break;
      case '\f':
        output += '\\f';
        break;
      default:
        output += char;
        break;
    }
  }
  output += '|';
  return output;
}
